package com.waultimate.scanner;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.List;

/** User-started, sequential scanner. Only reads text; never presses Join or sends messages. */
public final class ScannerAccessibility extends AccessibilityService {
  public static ScannerAccessibility current;
  private final Handler h=new Handler(Looper.getMainLooper());
  private ScanStore store;
  private ScannerConfig config;
  private boolean running=false, paused=false;
  private int idx=-1, attempt=0;
  private long launchedAt=0,lastRead=0;
  private String candidate="";
  private int stable=0;
  private String activePackage="", preLaunchFingerprint="";
  private boolean observedNewScreen=false;
  private long lastWhatsAppEvent=0;
  public String diagnostics(){return "الخدمة متصلة: "+(current==this?"نعم":"لا")+"\nآخر حدث واتساب: "+(lastWhatsAppEvent==0?"لم يُرصد":"منذ "+((System.currentTimeMillis()-lastWhatsAppEvent)/1000)+" ثانية")+"\nالحزمة: "+(activePackage.isEmpty()?"لم تُحدد":activePackage)+"\nانتقال الشاشة للرابط الحالي: "+(observedNewScreen?"رُصد":"لم يُرصد");}
  private static String fingerprint(List<String> words){StringBuilder b=new StringBuilder();for(String w:words)b.append(w).append('\u001f');return b.toString();}
  private long gap(){return config==null?5000L:config.gapSeconds()*1000L;}
  private long previewTimeout(){return config==null?20000L:config.timeoutSeconds()*1000L;}
  private static final long[] BACKOFF={120000,300000,900000,1800000,3600000};
  @Override public void onServiceConnected(){super.onServiceConnected();current=this;store=new ScanStore(this);config=new ScannerConfig(this);if("RUNNING".equals(store.state()))store.state("PAUSED","الخدمة جاهزة؛ اضغط استئناف لإعادة فتح الرابط الحالي");}
  @Override public void onDestroy(){stop();current=null;super.onDestroy();}
  public void begin(){if(store==null)store=new ScanStore(this);if(config==null)config=new ScannerConfig(this);if(running)return;running=true;paused=false;store.state("RUNNING","بدأ الفحص؛ أبقِ شاشة الهاتف مفتوحة");next();}
  public void stop(){running=false;paused=true;h.removeCallbacksAndMessages(null);if(store!=null)store.state("PAUSED","تم الإيقاف؛ النتائج محفوظة");}
  public void clear(){running=false;paused=true;h.removeCallbacksAndMessages(null);if(store!=null)store.clear();}
  private void next(){
    if(!running)return;
    idx=store.next();attempt=0;candidate="";stable=0;
    if(idx<0){running=false;store.state("DONE","انتهى الفحص؛ يمكنك إعادة محاولة غير المحسوم");return;}
    long wait=store.cooldownUntil()-System.currentTimeMillis();if(wait>0){store.state("COOLDOWN","وقت الانتظار المتبقي: "+(wait/1000)+" ثانية");h.postDelayed(this::next,Math.max(1000,wait));return;}
    open();
  }
  private void open(){
    if(!running||idx<0)return;
    JSONObjectSafe old=new JSONObjectSafe(store.at(idx));
    attempt=old.attempts()+1;
    candidate="";stable=0;observedNewScreen=false;preLaunchFingerprint="";launchedAt=System.currentTimeMillis();lastRead=0;
    AccessibilityNodeInfo before=getRootInActiveWindow();if(before!=null){List<String> oldWords=new ArrayList<>();walk(before,oldWords,0);preLaunchFingerprint=fingerprint(oldWords);before.recycle();}
    store.update(idx,"RETRY",old.name(),old.members(),"جار فتح معاينة الرابط — المحاولة "+attempt,true);
    store.state("RUNNING","جار فحص "+(idx+1)+" / "+store.size());
    try{
      activePackage=availableWhatsAppPackage();
      if(activePackage.isEmpty()){finish("UNRESOLVED","","","لا يوجد تطبيق WhatsApp رسمي أو Business مثبت");return;}
      Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(old.url()));i.setPackage(activePackage);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
      if(i.resolveActivity(getPackageManager())==null){finish("UNRESOLVED","","","تطبيق واتساب مثبت لكنه لا يستقبل هذا النوع من الروابط مباشرة");return;}
      startActivity(i);
    }catch(Exception ex){
      // Do not fall back to an arbitrary browser: this scanner reads WhatsApp's view only.
      finish("UNRESOLVED","","","تعذر فتح الرابط في تطبيق WhatsApp الرسمي: "+ex.getClass().getSimpleName());return;
    }
    final int expected=idx,number=attempt;
    h.postDelayed(()->{if(running&&idx==expected&&attempt==number)timeout();},previewTimeout());
  }
  private String availableWhatsAppPackage(){
    for(String pkg:new String[]{"com.whatsapp","com.whatsapp.w4b"}){try{getPackageManager().getPackageInfo(pkg,0);return pkg;}catch(PackageManager.NameNotFoundException ignored){}}
    return "";
  }
  @Override public void onAccessibilityEvent(AccessibilityEvent e){
    if(e.getPackageName()==null)return;
    String pkg=e.getPackageName().toString();
    if(!"com.whatsapp".equals(pkg)&&!"com.whatsapp.w4b".equals(pkg))return;
    lastWhatsAppEvent=System.currentTimeMillis();
    if(!running||idx<0||!pkg.equals(activePackage))return;
    long now=System.currentTimeMillis();if(now-launchedAt<1700||now-lastRead<450)return;
    lastRead=now;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    List<String> words=new ArrayList<>();walk(root,words,0);root.recycle();
    String currentFingerprint=fingerprint(words);
    if(!observedNewScreen){
      if(words.isEmpty()||currentFingerprint.equals(preLaunchFingerprint))return;
      observedNewScreen=true;candidate="";stable=0;
    }
    PreviewParser.Result r=PreviewParser.parse(words);
    if(r.rateLimited){onLimit();return;}
    if("UNRESOLVED".equals(r.status))return;
    String fingerprint=r.status+"|"+r.name+"|"+r.members;
    if(!fingerprint.equals(candidate)){candidate=fingerprint;stable=1;return;}
    stable++;
    if(stable>=2)finish(r.status,r.name,r.members,r.note);
  }
  private void walk(AccessibilityNodeInfo node,List<String> out,int depth){
    if(node==null||depth>25||out.size()>160)return;
    CharSequence txt=node.getText();CharSequence desc=node.getContentDescription();
    if(txt!=null&&!txt.toString().trim().isEmpty())out.add(txt.toString().trim());
    if(desc!=null&&!desc.toString().trim().isEmpty() && (txt==null||!desc.toString().equals(txt.toString())))out.add(desc.toString().trim());
    for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo c=node.getChild(i);if(c!=null){walk(c,out,depth+1);c.recycle();}}
  }
  private void timeout(){
    if(!running)return;
    if(attempt<(config==null?2:config.retries())){store.state("RUNNING","انتهت مهلة المعاينة؛ إعادة المحاولة وفق الإعدادات");h.postDelayed(this::open,4000);}
    else finish("UNRESOLVED","","","لم تظهر أدلة كافية بعد إعادة المحاولة؛ قد يكون السبب الشبكة أو شاشة مختلفة");
  }
  private void onLimit(){
    if(!running)return;
    running=false;paused=true;h.removeCallbacksAndMessages(null);
    int step=Math.min(store.cooldownStep(),BACKOFF.length-1);long delay=BACKOFF[step];long until=System.currentTimeMillis()+delay;
    store.cooldown(Math.min(step+1,BACKOFF.length-1),until);
    store.state("COOLDOWN","رصد تقييد؛ الانتظار "+(delay/60000)+" دقيقة قبل استئناف الفحص. أبقِ الشاشة مفتوحة عند الاستئناف");
    if(config!=null&&!config.autoResume())return;
    running=true;paused=false;h.postDelayed(()->{if(running){store.state("RUNNING","انتهى الانتظار؛ إعادة فتح الرابط الحالي");next();}},delay);
  }
  private void finish(String status,String name,String members,String note){
    if(!running)return;
    // One input -> one result; persist before launching another invitation.
    store.update(idx,status,name,members,note,false);
    store.cooldown(0,0);
    idx=-1;candidate="";stable=0;
    h.postDelayed(this::next,gap());
  }
  @Override public void onInterrupt(){stop();}
  private static final class JSONObjectSafe{
    final org.json.JSONObject o;JSONObjectSafe(org.json.JSONObject x){o=x==null?new org.json.JSONObject():x;}
    String url(){return o.optString("url");}String name(){return o.optString("name");}
    String members(){return o.optString("members");}int attempts(){return o.optInt("attempts");}
  }
}
