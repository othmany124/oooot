package com.waultimate.scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative classifier: no name alone is NEVER proof of a revoked invitation. */
public final class PreviewParser {
  static final class Result {String status="UNRESOLVED",name="",members="",note="لا تكفي معلومات المعاينة";boolean rateLimited=false;}
  private static final String[] INVALID={"invite link has been reset","invite link is invalid","this invite link is invalid","invite link has expired","couldn't find this group","can't find this group","رابط الدعوة غير صالح","تم إعادة تعيين رابط الدعوة","انتهت صلاحية رابط الدعوة","تعذر العثور على المجموعة"};
  private static final String[] LIMIT={"try again later","too many requests","please wait before trying","temporarily unavailable","حاول مرة أخرى لاحقًا","طلبات كثيرة","يرجى المحاولة لاحقاً","يرجى المحاولة لاحقا"};
  private static final String[] APPROVAL={"request to join","ask to join","طلب الانضمام","طلب الموافقة"};
  private static final String[] JOIN={"join group","join community","join channel","الانضمام إلى المجموعة","انضم إلى المجموعة","الانضمام إلى المجتمع","متابعة القناة"};
  private static final String[] IGNORE={"whatsapp","cancel","إلغاء","إلغاء الأمر","join group","join community","join channel","request to join","ask to join","انضمام","الانضمام","المجموعة","مجموعة واتساب","دعوة للانضمام","group invite","invite to group","channel invite","community invite","دعوة إلى قناة","دعوة إلى مجتمع","members","member","مشارك","مشاركون","الأعضاء","الأعضاء:","group info","المعلومات","معلومات المجموعة","back","رجوع","report","إبلاغ","ok","موافق","فتح بواسطة","open with"};
  static boolean has(String t,String[] words){for(String w:words) if(t.contains(w))return true;return false;}
  static boolean ignored(String t){if(t.length()<2||t.length()>90||t.matches("[0-9, ]+"))return true;String l=t.toLowerCase(Locale.ROOT);for(String x:IGNORE)if(l.equals(x)||l.startsWith(x+" "))return true;return l.startsWith("http")||l.contains("chat.whatsapp.com")||l.contains("whatsapp.com/channel/");}
  static Result parse(List<String> items){
    Result r=new Result();StringBuilder sb=new StringBuilder();List<String> unique=new ArrayList<>();
    for(String s:items)if(s!=null&&!s.trim().isEmpty()){String t=s.trim();sb.append(t.toLowerCase(Locale.ROOT)).append('\n');if(!unique.contains(t))unique.add(t);}
    String all=sb.toString();if(has(all,LIMIT)){r.rateLimited=true;r.note="إشارة لتقييد الطلبات؛ لم يصنف الرابط كغير شغال";return r;}
    if(has(all,INVALID)){r.status="INVALID";r.note="رسالة صريحة من واتساب بعدم صلاحية الدعوة";return r;}
    boolean approval=has(all,APPROVAL),join=has(all,JOIN);
    if(!join&&!approval) {r.note="لم تظهر معاينة دعوة مؤكدة";return r;}
    Matcher count=Pattern.compile("(?:([\\d,]+)\\s*(?:members|participants|عضو|مشارك)|(?:الأعضاء|المشاركون)\\s*[:：]?\\s*([\\d,]+))",Pattern.CASE_INSENSITIVE).matcher(all);
    if(count.find())r.members=count.group(1)!=null?count.group(1):count.group(2);
    // Preserve reading order: preview title is commonly immediately before the join control.
    int joinAt=unique.size();for(int i=0;i<unique.size();i++){String t=unique.get(i).toLowerCase(Locale.ROOT);if(has(t,JOIN)||has(t,APPROVAL)){joinAt=i;break;}}
    for(int i=joinAt-1;i>=0;i--){String candidate=unique.get(i);if(!ignored(candidate) && !candidate.matches(".*\\d+\\s*(members|عضو|مشارك).*")){r.name=candidate;break;}}
    if(r.name.isEmpty()){r.note="ظهر زر الدعوة دون اسم موثوق";return r;}
    if(all.contains("channel invite")||all.contains("دعوة إلى قناة")||all.contains("متابعة القناة"))r.status="CHANNEL";
    else if(all.contains("community invite")||all.contains("دعوة إلى مجتمع")||all.contains("join community")||all.contains("الانضمام إلى المجتمع"))r.status="COMMUNITY";
    else r.status=approval?"APPROVAL":"DIRECT";
    r.note="من واجهة واتساب الرسمية؛ العدد فارغ إذا لم يظهر";return r;
  }
}
