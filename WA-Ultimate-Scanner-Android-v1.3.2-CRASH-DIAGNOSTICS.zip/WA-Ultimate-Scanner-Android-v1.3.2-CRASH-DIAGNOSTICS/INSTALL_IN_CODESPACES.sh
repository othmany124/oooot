#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
BRANCH="$(git branch --show-current)"
git pull --ff-only origin "$BRANCH"
ZIP=WA-Ultimate-Scanner-Android-v1.3.1-NAVIGATION-REPAIR.zip
test -f "$ZIP" || { echo "ERROR: Upload $ZIP to GitHub repository root first"; exit 1; }
unzip -tq "$ZIP"
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
unzip -oq "$ZIP" -d "$TMP"
PROJECT=$(find "$TMP" -name settings.gradle -print -quit);test -n "$PROJECT"
mkdir -p .github/workflows
cp "$(dirname "$PROJECT")/.github/workflows/build-apk.yml" .github/workflows/build-apk.yml
git add "$ZIP" .github/workflows/build-apk.yml
if git diff --cached --quiet;then git commit --allow-empty -m "Rebuild v1.3.1 navigation repair";else git commit -m "Build v1.3.1 navigation repair";fi
git push origin "HEAD:$BRANCH"
echo "Build requested by push; see GitHub Actions."
