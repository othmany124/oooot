package com.waultimate.scanner;
import java.util.Arrays;
public final class ClassificationModelTest {
  static void eq(String label,String got,String expected){if(!expected.equals(got))throw new AssertionError(label+": "+got+" != "+expected);System.out.println("PASS "+label);}
  public static void main(String[] args){
    PreviewParser.Result g=PreviewParser.parse(Arrays.asList("طلاب الطب","٢٣٤ أعضاء","طلب الانضمام","تم الإنشاء 2025-02-11"));
    eq("group approval",g.status,"APPROVAL");eq("group type",g.joinType,"APPROVAL");eq("group members",g.members,"234");eq("group date",g.creationDate,"2025-02-11");
    PreviewParser.Result c=PreviewParser.parse(Arrays.asList("مجتمع الجامعة","8 قروبات","الانضمام إلى المجتمع"));
    eq("community",c.status,"COMMUNITY");eq("community groups",c.members,"8");eq("community kind",c.countType,"SUBGROUPS");
    PreviewParser.Result ch=PreviewParser.parse(Arrays.asList("قناة الأخبار","١٢٣٤ متابع","متابعة القناة"));
    eq("channel",ch.status,"CHANNEL");eq("followers",ch.members,"1234");eq("followers kind",ch.countType,"FOLLOWERS");
    PreviewParser.Result dead=PreviewParser.parse(Arrays.asList("تم تغيير رابط الدعوة"));eq("reset invalid",dead.status,"INVALID");
  }
}
