#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
SRC="$ROOT/app/src/main/java/com/waultimate/scanner"
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" "$SRC/PreviewParser.java" "$SRC/NavigationPolicy.java" \
 "$SRC/QueuePlanner.java" "$ROOT/tests/PreviewParserTest.java" "$ROOT/tests/ClassificationModelTest.java" \
 "$ROOT/tests/NavigationEngineTest.java" "$ROOT/tests/FullFlowSimulationTest.java" \
 "$ROOT/tests/SyntaxCheck.java"
java -cp "$OUT" SyntaxCheck "$SRC"
java -cp "$OUT" com.waultimate.scanner.PreviewParserTest
java -cp "$OUT" com.waultimate.scanner.ClassificationModelTest
java -cp "$OUT" com.waultimate.scanner.NavigationEngineTest
java -cp "$OUT" com.waultimate.scanner.FullFlowSimulationTest
