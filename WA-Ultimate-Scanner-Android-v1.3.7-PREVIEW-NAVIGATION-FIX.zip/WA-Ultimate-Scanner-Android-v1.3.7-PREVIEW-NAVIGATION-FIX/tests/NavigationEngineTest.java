package com.waultimate.scanner;
public final class NavigationEngineTest {
  private static int count=0;
  private static void eq(Object expected,Object actual){count++;if(!expected.equals(actual))throw new AssertionError("Expected "+expected+" but got "+actual);}
  private static void yes(boolean actual){eq(Boolean.TRUE,actual);}
  private static void no(boolean actual){eq(Boolean.FALSE,actual);}
  public static void main(String[] args){
    eq(NavigationPolicy.Action.NO_ACTION,NavigationPolicy.nextDismissAction(false,true,true,false,false));
    eq(NavigationPolicy.Action.NO_ACTION,NavigationPolicy.nextDismissAction(true,false,true,false,false));
    eq(NavigationPolicy.Action.CLICK_CLOSE,NavigationPolicy.nextDismissAction(true,true,true,false,false));
    eq(NavigationPolicy.Action.BACK,NavigationPolicy.nextDismissAction(true,true,false,false,false));
    eq(NavigationPolicy.Action.BACK,NavigationPolicy.nextDismissAction(true,true,true,true,false));
    eq(NavigationPolicy.Action.WAIT,NavigationPolicy.nextDismissAction(true,true,true,true,true));
    no(NavigationPolicy.validCallback(true,4,5,0,0));
    no(NavigationPolicy.validCallback(false,4,4,0,0));
    no(NavigationPolicy.validCallback(true,4,4,0,1));
    yes(NavigationPolicy.validCallback(true,4,4,0,0));
    no(NavigationPolicy.shouldCircuitBreak(2,4));
    yes(NavigationPolicy.shouldCircuitBreak(4,4));
    eq(2,QueuePlanner.select(new String[]{"RETRY","DONE","PENDING"},-1));
    eq(0,QueuePlanner.select(new String[]{"RETRY","DONE","PENDING"},0));
    eq(0,QueuePlanner.select(new String[]{"RETRY","DONE"},-1));
    eq(-1,QueuePlanner.select(new String[]{"INVALID","DIRECT","UNRESOLVED"},-1));
    eq(1,QueuePlanner.select(new String[]{"PENDING","RETRY","PENDING"},1));
    eq(0,QueuePlanner.select(new String[]{"PENDING","RETRY","PENDING"},55));
    System.out.println("Navigation/queue policy tests PASS: "+count);
  }
}
