package com.waultimate.scanner;
import java.util.*;
/** Deterministic simulation only. Does NOT interact with a real WhatsApp UI. */
public final class FullFlowSimulationTest {
  private static void ok(boolean condition,String message){if(!condition)throw new AssertionError(message);}
  public static void main(String[] args){
    String[] all=new String[192];Arrays.fill(all,"PENDING");
    List<Integer> finished=new ArrayList<>();
    int active=-1;
    while(true){
      int next=QueuePlanner.select(all,active);
      if(next<0)break;
      active=next; // persisted before opening
      boolean verified=true, samePackage=true, hasClose=true;
      NavigationPolicy.Action action=NavigationPolicy.nextDismissAction(samePackage,verified,hasClose,false,false);
      ok(action==NavigationPolicy.Action.CLICK_CLOSE,"Verified preview must prefer X");
      all[active]="DIRECT";finished.add(active);active=-1;
    }
    ok(finished.size()==192,"192 links must each be processed once");
    for(int i=0;i<192;i++)ok(finished.get(i)==i,"Unexpected order or skipped index "+i);
    String[] restart={"RETRY","PENDING","PENDING"};
    ok(QueuePlanner.select(restart,0)==0,"Crash must recover in-flight link first");
    ok(QueuePlanner.select(restart,-1)==1,"Deferred link must not starve new link");
    ok(NavigationPolicy.nextDismissAction(false,true,true,false,false)==NavigationPolicy.Action.NO_ACTION,"Never Back in wrong package");
    ok(NavigationPolicy.nextDismissAction(true,false,true,false,false)==NavigationPolicy.Action.NO_ACTION,"Never Back without preview");
    ok(NavigationPolicy.nextDismissAction(true,true,false,true,false)==NavigationPolicy.Action.BACK,"Back fallback once");
    ok(NavigationPolicy.nextDismissAction(true,true,false,true,true)==NavigationPolicy.Action.WAIT,"No unbounded Back loop");
    ok(!NavigationPolicy.validCallback(true,1,2,1,2),"Old timer must not affect next URL");
    System.out.println("Full-flow SIMULATION PASS: 192 unique sequential results, crash/retry/nav guards");
  }
}
