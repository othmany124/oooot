import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.nio.file.*;
import java.util.*;
/** Parses all Java source files without requiring the Android SDK or resolving imports. */
public final class SyntaxCheck {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    DiagnosticCollector<JavaFileObject> diagnostic=new DiagnosticCollector<>();
    List<java.io.File> sources=new ArrayList<>();
    try(java.util.stream.Stream<Path> all=Files.walk(Paths.get(args[0]))){
      all.filter(p->p.toString().endsWith(".java")).forEach(p->sources.add(p.toFile()));
    }
    try(StandardJavaFileManager fm=compiler.getStandardFileManager(diagnostic,null,null)){
      JavacTask task=(JavacTask)compiler.getTask(null,fm,diagnostic,Arrays.asList("-proc:none"),null,fm.getJavaFileObjectsFromFiles(sources));
      task.parse();
    }
    long errors=diagnostic.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
    for(Diagnostic<? extends JavaFileObject> d:diagnostic.getDiagnostics())
      if(d.getKind()==Diagnostic.Kind.ERROR)System.err.println(d);
    if(errors>0)throw new AssertionError("Java syntax errors: "+errors);
    System.out.println("Java syntax PARSE PASS: "+sources.size()+" source files");
  }
}
