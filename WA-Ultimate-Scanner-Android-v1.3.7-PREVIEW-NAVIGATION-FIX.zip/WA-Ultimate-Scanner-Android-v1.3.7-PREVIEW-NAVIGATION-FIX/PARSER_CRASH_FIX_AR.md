> وثيقة تاريخية مورّثة من إصدار سابق. المرجع الحالي: README_AR.md و NAVIGATION_AUDIT_AR.md؛ لم يُختبر v1.3.4 على هاتف فعلي.

# إصلاح تعطل PreviewParser – v1.3.3

أكد سجل الهاتف أن ExceptionInInitializerError ناتج من PatternSyntaxException داخل PreviewParser.<clinit> عند السطر 22، ثم توقف ScannerAccessibility.captureCurrentPreview. أزلنا كل أنماط Regex الثابتة من PreviewParser واستبدلنا قراءة أعداد الأعضاء بدالة رقمية لا تستخدم التعبيرات المنتظمة، مع رفض الأعداد المختصرة أو غير المؤكدة.

نُصح بإيقاف خدمات النسخ الأخرى والاختبار برابط واحد بعد تثبيت APK؛ لا يمكن اعتبار الإصلاح مثبتًا على الهاتف قبل الاختبار.

ملف INSTALL_IN_CODESPACES.sh يُشغّل بعد رفع ZIP الجديد إلى جذر مستودع GitHub. البناء التجريبي يوقّع تلقائيًا باستخدام مفتاح Debug وقد لا يُثبّت فوق APK قديم بمفتاح مختلف.
