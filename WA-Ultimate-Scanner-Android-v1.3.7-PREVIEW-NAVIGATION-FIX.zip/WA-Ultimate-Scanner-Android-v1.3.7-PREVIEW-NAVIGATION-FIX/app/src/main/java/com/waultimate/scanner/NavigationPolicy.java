package com.waultimate.scanner;

/** Pure, deterministic navigation rules. UI actions must remain inside a verified invite. */
public final class NavigationPolicy {
  public enum Action { CLICK_CLOSE, BACK, NO_ACTION, WAIT, PAUSE }
  private NavigationPolicy() {}

  /** Never click or press Back unless current window belongs to the selected WhatsApp
   *  package and a fresh invitation preview (not the chat list) is visible. */
  public static Action nextDismissAction(boolean correctPackage, boolean confirmedPreview,
                                         boolean closeButtonAvailable, boolean closeTried,
                                         boolean backTried) {
    if (!correctPackage || !confirmedPreview) return Action.NO_ACTION;
    if (!closeTried && closeButtonAvailable) return Action.CLICK_CLOSE;
    if (!backTried) return Action.BACK;
    return Action.WAIT;
  }

  /** A stale timer from a prior URL is never allowed to touch the current URL. */
  public static boolean validCallback(boolean running, long expectedGeneration,
                                      long currentGeneration, int expectedIndex,
                                      int activeIndex) {
    return running && expectedGeneration == currentGeneration
        && activeIndex >= 0 && expectedIndex == activeIndex;
  }

  public static boolean shouldCircuitBreak(int missingStreak, int limit) {
    return missingStreak >= limit;
  }
}
