package com.waultimate.scanner;

import android.app.Application;
import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Private local Java-crash report. Does not capture WhatsApp chats or link contents. */
public final class CrashReporter extends Application {
  private static final String FILE = "last_java_crash.txt";
  private static final String HANDLED = "last_handled_error.txt";
  @Override public void onCreate() {
    super.onCreate();
    final Thread.UncaughtExceptionHandler previous=Thread.getDefaultUncaughtExceptionHandler();
    Thread.setDefaultUncaughtExceptionHandler((thread, exception)->{
      try {
        StringBuilder b=new StringBuilder();
        b.append("WA Scanner Java crash\nDevice time: ")
          .append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date()))
          .append("\nThread: ").append(thread.getName())
          .append("\nException: ").append(exception.getClass().getName())
          .append(" / ").append(String.valueOf(exception.getMessage())).append('\n');
        Throwable issue=exception;
        for(int depth=0; issue!=null && depth<3; depth++,issue=issue.getCause()) {
          b.append("Cause type: ").append(issue.getClass().getName())
            .append(" / ").append(String.valueOf(issue.getMessage())).append('\n');
          StackTraceElement[] frames=issue.getStackTrace();
          for(int i=0;i<Math.min(frames.length,35);i++) b.append("  at ").append(frames[i]).append('\n');
        }
        getSharedPreferences("crash_state",Context.MODE_PRIVATE).edit().putBoolean("needs_ack",true).commit();
        try(FileOutputStream stream=openFileOutput(FILE,Context.MODE_PRIVATE)) {
          stream.write(b.toString().getBytes(StandardCharsets.UTF_8));stream.flush();
        }
      } catch(Throwable ignored) {}
      if(previous!=null)previous.uncaughtException(thread,exception);
      else android.os.Process.killProcess(android.os.Process.myPid());
    });
  }
  /** Save the stack trace for nonfatal accessibility/timer errors too. */
  public static void recordHandled(Context ctx,Throwable e,String stage){
    try{
      StringBuilder report=new StringBuilder("WA Scanner handled error\nStage: ").append(stage)
        .append("\nTime: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date()))
        .append("\nType: ").append(e.getClass().getName()).append(" / ")
        .append(String.valueOf(e.getMessage())).append('\n');
      Throwable cause=e;
      for(int depth=0;cause!=null&&depth<3;cause=cause.getCause(),depth++){
        report.append("Cause: ").append(cause.getClass().getName()).append('\n');
        for(StackTraceElement frame:cause.getStackTrace()){
          report.append("  at ").append(frame).append('\n');
          if(report.length()>13000)break;
        }
      }
      try(FileOutputStream out=ctx.openFileOutput(HANDLED,Context.MODE_PRIVATE)){
        out.write(report.toString().getBytes(StandardCharsets.UTF_8));
      }
    }catch(Exception ignored){}
  }
  public static String read(Context ctx){
    try {
      File f=new File(ctx.getFilesDir(),FILE);
      File handled=new File(ctx.getFilesDir(),HANDLED);
      String fatal=f.isFile()?new String(java.nio.file.Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8):"لا يوجد انهيار Java غير معالج محفوظ.";
      String intercepted=handled.isFile()?new String(java.nio.file.Files.readAllBytes(handled.toPath()),StandardCharsets.UTF_8):"لا يوجد خطأ مُعالج محفوظ.";
      return fatal+"\n\n--- Non-fatal / intercepted ---\n"+intercepted;
    }catch(Exception e){return "تعذر قراءة سجل الانهيار: "+e.getClass().getSimpleName();}
  }
  public static boolean needsAcknowledgement(Context ctx){return ctx.getSharedPreferences("crash_state",Context.MODE_PRIVATE).getBoolean("needs_ack",false);}
  public static void acknowledge(Context ctx){ctx.getSharedPreferences("crash_state",Context.MODE_PRIVATE).edit().putBoolean("needs_ack",false).commit();}
  public static boolean exists(Context ctx){return new File(ctx.getFilesDir(),FILE).isFile()||new File(ctx.getFilesDir(),HANDLED).isFile();}
}
