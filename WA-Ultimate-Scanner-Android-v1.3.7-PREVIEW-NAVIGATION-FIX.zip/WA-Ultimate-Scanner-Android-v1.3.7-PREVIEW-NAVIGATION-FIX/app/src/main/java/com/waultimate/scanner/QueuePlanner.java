package com.waultimate.scanner;

/** Pure queue ordering: recover an interrupted URL first, otherwise new before retry. */
public final class QueuePlanner {
  private QueuePlanner() {}
  public static int select(String[] statuses, int interrupted) {
    if (statuses == null) return -1;
    if (interrupted >= 0 && interrupted < statuses.length && pending(statuses[interrupted]))
      return interrupted;
    for (int i=0;i<statuses.length;i++) if ("PENDING".equals(statuses[i])) return i;
    for (int i=0;i<statuses.length;i++) if ("RETRY".equals(statuses[i])) return i;
    return -1;
  }
  private static boolean pending(String s) { return "PENDING".equals(s) || "RETRY".equals(s); }
}
