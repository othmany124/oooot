package com.waultimate.scanner;
import java.util.Arrays;
public final class PreviewParserTest {
  static void check(String label,String actual,String expected){if(!expected.equals(actual))throw new AssertionError(label+": "+actual+" != "+expected);System.out.println("PASS "+label);}
  public static void main(String[] args){
    check("direct",PreviewParser.parse(Arrays.asList("Study Group","121 members","Join group")).status,"DIRECT");
    check("generic-join",PreviewParser.parse(Arrays.asList("Study Group","Join")).status,"DIRECT");
    check("arabic-generic-join",PreviewParser.parse(Arrays.asList("مجموعة الطب","انضم")).status,"DIRECT");
    check("approval",PreviewParser.parse(Arrays.asList("Research Group","Request to join")).status,"APPROVAL");
    check("invalid",PreviewParser.parse(Arrays.asList("This invite link is invalid")).status,"INVALID");
    check("no-name becomes invalid",PreviewParser.parse(Arrays.asList("WhatsApp","Join group")).status,"INVALID");
    check("rate-limited not invalid",PreviewParser.parse(Arrays.asList("Try again later")).status,"UNRESOLVED");
    check("channel",PreviewParser.parse(Arrays.asList("News","Channel invite","Join channel")).status,"CHANNEL");
    check("community",PreviewParser.parse(Arrays.asList("Research","Community invite","Join community")).status,"COMMUNITY");
    check("channel-name",PreviewParser.parse(Arrays.asList("News", "Channel invite", "Join channel")).name,"News");
    check("community-name",PreviewParser.parse(Arrays.asList("Research", "Community invite", "Join community")).name,"Research");
    check("arabic-channel-name",PreviewParser.parse(Arrays.asList("أخبار التقنية", "دعوة إلى قناة", "متابعة القناة")).name,"أخبار التقنية");
    check("arabic-community-name",PreviewParser.parse(Arrays.asList("مجتمع المطورين", "دعوة إلى مجتمع", "الانضمام إلى المجتمع")).name,"مجتمع المطورين");
    check("arabic-prefix-count",PreviewParser.parse(Arrays.asList("فريق", "الأعضاء: ٢٣٤", "الانضمام إلى المجموعة")).members,"234");
    check("member-title-not-count",PreviewParser.parse(Arrays.asList("Class 2026 members", "Join group")).members,"");
    check("direct-count",PreviewParser.parse(Arrays.asList("Study Group","1,234 members","Join group")).members,"1234");
    check("approval-kind",PreviewParser.parse(Arrays.asList("Research Group","Request to join")).joinType,"APPROVAL");
    check("channel-followers",PreviewParser.parse(Arrays.asList("أخبار التقنية","١٢٬٣٤٥ متابع","متابعة القناة")).members,"12345");
    check("followers-kind",PreviewParser.parse(Arrays.asList("News","482K followers","Join channel")).countType,"UNKNOWN");
    check("ambiguous-no-count",PreviewParser.parse(Arrays.asList("Study Group","Join group")).members,"");
    check("no-button",PreviewParser.parse(Arrays.asList("WhatsApp", "Unknown group")).status,"UNRESOLVED");
    check("ignore-avatar-overflow",PreviewParser.parse(Arrays.asList("Medical Students 2026","+٤٩","Join group")).name,"Medical Students 2026");
    check("ignore-read-more-ar",PreviewParser.parse(Arrays.asList("مجموعة الجراحة","قراءة المزيد","انضم إلى المجموعة")).name,"مجموعة الجراحة");
    check("ignore-read-more-en",PreviewParser.parse(Arrays.asList("Radiology Group","Read more","Join group")).name,"Radiology Group");
    check("split-member-count",PreviewParser.parse(Arrays.asList("Study Group","234","members","Join group")).members,"234");
    check("split-ar-member-count",PreviewParser.parse(Arrays.asList("مجموعة الاختبار","٢٣٤","أعضاء","انضم إلى المجموعة")).members,"234");
    check("arabic-member-phrase",PreviewParser.parse(Arrays.asList("مجموعة الجراحة","٥٢ من الأعضاء","انضم إلى المجموعة")).members,"52");
    check("nearby-member-count",PreviewParser.parse(Arrays.asList("Study Group","234","Some spacer","members","Join group")).members,"234");
    check("plus-overflow-not-count",PreviewParser.parse(Arrays.asList("Study Group","+49","Join group")).members,"");
    check("community-subgroups",PreviewParser.parse(Arrays.asList("Medical Community","12 groups","Join community")).members,"12");
    check("community-count-kind",PreviewParser.parse(Arrays.asList("Medical Community","12 groups","Join community")).countType,"SUBGROUPS");
    check("creation-date",PreviewParser.parse(Arrays.asList("Study Group","Created on 2024-08-12","121 members","Join group")).creationDate,"2024-08-12");
    check("group-accuracy",Integer.toString(PreviewParser.parse(Arrays.asList("Study Group","Created on 2024-08-12","121 members","Join group")).accuracy),"100");
    check("invalid-accuracy",Integer.toString(PreviewParser.parse(Arrays.asList("This invite link is invalid")).accuracy),"100");
    check("missing-name-accuracy",Integer.toString(PreviewParser.parse(Arrays.asList("WhatsApp","Join group")).accuracy),"75");
  }
}
