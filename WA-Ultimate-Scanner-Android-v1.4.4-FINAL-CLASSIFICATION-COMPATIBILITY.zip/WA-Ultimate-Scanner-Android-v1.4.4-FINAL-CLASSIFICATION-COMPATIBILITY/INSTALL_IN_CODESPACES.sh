#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
BRANCH=$(git branch --show-current)
test "$BRANCH" = main || { echo "Switch to main before installing"; exit 1; }
ZIP="WA-Ultimate-Scanner-Android-v1.4.4-FINAL-CLASSIFICATION-COMPATIBILITY.zip"
echo "[1/5] Sync repository"
git fetch origin main
git reset --hard origin/main

echo "[2/5] Verify update"
test -f "$ZIP" || { echo "Missing $ZIP in repository root"; exit 1; }
unzip -tq "$ZIP"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
unzip -oq "$ZIP" -d "$TMP"
SOURCE=$(find "$TMP" -path '*/.github/workflows/build-apk.yml' -type f -print -quit)
test -n "$SOURCE"

echo "[3/5] Install workflow"
mkdir -p .github/workflows
cp "$SOURCE" .github/workflows/build-apk.yml

echo "[4/5] Commit workflow trigger"
git add .github/workflows/build-apk.yml
if git diff --cached --quiet; then
  git -c user.name='WA Scanner Builder' -c user.email='builder@users.noreply.github.com' commit --allow-empty -m 'Trigger WA Scanner v1.4.4 build'
else
  git -c user.name='WA Scanner Builder' -c user.email='builder@users.noreply.github.com' commit -m 'Build WA Scanner v1.4.4 final classification compatibility fix'
fi

echo "[5/5] Push and trigger Actions"
git push origin HEAD:main
echo "Submitted. Open GitHub Actions and download WA-Ultimate-Scanner-v1.4.4-APK when green."
