package com.waultimate.scanner;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;

/**
 * One invitation at a time: OPEN -> VERIFY -> SAVE -> DISMISS (X / Back) -> NEXT.
 * No automatic join action. An unverified UI never causes Back or an INVALID result.
 * All transition timers carry a generation; a previous link cannot finish the next link.
 */
public final class ScannerAccessibility extends AccessibilityService {
  public static ScannerAccessibility current;
  private enum Phase { IDLE, OPENING, VERIFYING, DISMISSING, WAITING_NEXT, PAUSED, COOLDOWN }
  private final Handler handler = new Handler(Looper.getMainLooper());
  private ScanStore store;
  private ScannerConfig config;
  private Phase phase = Phase.IDLE;
  private boolean running;
  private boolean intentionallyStopped;
  private int index = -1;
  private int attempt;
  private long generation;
  private long launchedAt;
  private long launchedUptime;
  private long lastRead;
  private int beforeWindow = -1;
  private String beforeFingerprint = "";
  private String previewFingerprint = "";
  private String targetPackage = "";
  private String candidate = "";
  private boolean sawNewWindow;
  private boolean sawWhatsAppEvent;
  private boolean previewVerified;
  private int missingStreak;
  private int stableSamples;
  private boolean stabilityGraceUsed;
  private String lastNavigation = "لم تبدأ دورة التنقل";
  private long lastWhatsAppEvent;
  private long eventCount;
  private long probeStarted;
  private int probeEvents, probeNodes;
  private String probePackage = "";
  private int dismissChecks;
  private boolean xWasTried, backWasTried;
  private int backAttempts;
  private static final int NO_PREVIEW_LIMIT = 4;
  private static final long[] COOLDOWN = {120000,300000,900000,1800000,3600000};
  private WindowManager overlayWindow;
  private LinearLayout overlayPanel;
  private TextView overlayToggle, overlayStatus, overlayMeta, overlaySkip, overlayStop, overlayCollapse;
  private LinearLayout overlayActions;
  private boolean overlayCollapsed;
  private WindowManager.LayoutParams overlayParams;
  private String overlayData="";

  public void beginProbe() {
    probeStarted = System.currentTimeMillis(); probeEvents = 0; probeNodes = 0; probePackage = "";
    DiagnosticsLog.add(this, "PROBE", "بدء اختبار استقبال أحداث واتساب");
  }
  public int probeEventCount() { return probeEvents; }
  public int probeNodeCount() { return probeNodes; }
  public String probeSummary() {
    return "أحداث واتساب: " + probeEvents + "\nعناصر مرئية: " + probeNodes
        + "\nالحزمة: " + (probePackage.isEmpty()?"لم ترصد":probePackage)
        + "\nنجاح معاينة الدعوة لا يُثبت بعدد الأحداث وحده.";
  }
  public boolean isScanning() { return running; }
  public boolean observedWhatsAppEvents() { return lastWhatsAppEvent > 0; }
  public String detectedWhatsAppPackage() { return selectedPackage(); }
  public String diagnostics() {
    return "حالة المحرك: " + phaseLabel() + "\nالرابط الجاري: "
        + (index < 0 ? "لا يوجد" : (index+1))
        + "\nآخر تنقل: " + lastNavigation
        + "\nالخدمة متصلة: " + (current==this?"نعم":"لا")
        + "\nأحداث واتساب: " + eventCount
        + "\nآخر حدث: " + (lastWhatsAppEvent==0?"لم يُرصد":((System.currentTimeMillis()-lastWhatsAppEvent)/1000)+" ثانية")
        + "\nمعاينة الرابط الحالي: " + (previewVerified?"تم تأكيدها":"لم تتأكد")
        + "\nمتتالية بدون معاينة: " + missingStreak
        + "\nبيانات العائم: " + (overlayData.isEmpty()?"لا يوجد":overlayData);
  }
  public String phaseLabel(){
    switch(phase) {
      case OPENING: return "فتح الرابط";
      case VERIFYING: return "التحقق من المعاينة";
      case DISMISSING: return "إغلاق المعاينة";
      case WAITING_NEXT: return "الانتقال للتالي";
      case PAUSED: return "متوقف بأمان";
      case COOLDOWN: return "تهدئة واتساب";
      default: return "جاهز";
    }
  }
  public String lastNavigation(){return lastNavigation;}
  public int activeLinkNumber(){return index<0?0:index+1;}

  private String selectedPackage() { return WhatsAppTarget.resolve(this); }
  private boolean legacySamsung(){
    return "samsung".equalsIgnoreCase(Build.MANUFACTURER) && Build.VERSION.SDK_INT<=31;
  }
  private long timeoutMillis(){
    long configured=(config==null?3:config.timeoutSeconds())*1000L;
    // Note 10 / older One UI can expose the preview tree later than recent Samsung devices.
    return legacySamsung()?Math.max(4000L,configured):configured;
  }
  private long gapMillis(){
    int seconds=config==null?1:config.gapSeconds();
    // Fast mode keeps a small navigation safety window without repeating the same URL.
    return seconds<=1?(legacySamsung()?420L:320L):seconds*1000L;
  }
  private long[] sampleDelays(){
    return legacySamsung()?new long[]{320,540,850,1300,1900,2700}:new long[]{220,360,560,820,1200,1750};
  }
  private String currentUrl(){
    if(store==null||index<0)return "";
    org.json.JSONObject row=store.at(index);return row==null?"":row.optString("url","");
  }
  private void navigation(String message){lastNavigation=message;DiagnosticsLog.add(this,"NAV",message);}
  private static String fingerprint(List<String> labels){StringBuilder b=new StringBuilder();for(String s:labels)b.append(s).append('\u001f');return b.toString();}
  private boolean valid(long gen,int id){return NavigationPolicy.validCallback(running,gen,generation,id,index);}

  @Override public void onServiceConnected() {
    super.onServiceConnected();
    current=this;store=new ScanStore(this);config=new ScannerConfig(this);overlayCollapsed=config.overlayCollapsed();
    getSharedPreferences("accessibility_health",MODE_PRIVATE).edit()
        .putLong("connected_at",System.currentTimeMillis()).putBoolean("connected",true).apply();
    if(config.overlayEnabled())showFloatingControls();updateFloatingControls();
    String previous=store.state();
    DiagnosticsLog.add(this,"ACCESSIBILITY","الخدمة متصلة؛ الحالة: "+previous+"؛ المعلق: "+store.pendingCount());
    if(CrashReporter.needsAcknowledgement(this)
        && ("RUNNING".equals(previous)||"RECOVERING".equals(previous))){
      phase=Phase.PAUSED;
      store.state("PAUSED","رُصد انهيار سابق؛ راجع سجل الانهيار قبل الاستئناف اليدوي");
      return;
    }
    if(("RUNNING".equals(previous)||"RECOVERING".equals(previous))&&store.pendingCount()>0){
      store.state("RECOVERING","استعادة الرابط غير المكتمل بعد اتصال Accessibility");
      safePost(950,"استعادة الجلسة",()->{
        if(current==this&&!running&&"RECOVERING".equals(store.state()))begin();
      });
    }
  }
  @Override public void onDestroy() {
    boolean owner = current==this;
    boolean interrupted = running;
    invalidateTimers();running=false;phase=Phase.IDLE;
    if(owner){
      if(interrupted&&!intentionallyStopped&&store!=null&&"RUNNING".equals(store.state()))
        store.state("RECOVERING","انقطعت الخدمة، وسيُعاد الرابط غير المكتمل");
      current=null;
    }
    getSharedPreferences("accessibility_health",MODE_PRIVATE).edit()
        .putLong("disconnected_at",System.currentTimeMillis()).putBoolean("connected",false).apply();
    removeFloatingControls();
    super.onDestroy();
  }
  @Override public void onInterrupt() {
    DiagnosticsLog.add(this,"ACCESSIBILITY","onInterrupt؛ running="+running+"؛ الرابط="+(index<0?"—":(index+1)));
    if(running){invalidateTimers();running=false;phase=Phase.PAUSED;
      store.state("RECOVERING","انقطاع Accessibility؛ سيُستعاد الرابط نفسه عند عودة الخدمة");
    }
  }
  private void invalidateTimers(){generation++;handler.removeCallbacksAndMessages(null);}
  /** Scheduled callbacks cannot crash the app's main thread without a diagnostic. */
  private void safeRun(String stage,Runnable action){
    try{action.run();}
    catch(RuntimeException | LinkageError e){
      CrashReporter.recordHandled(this,e,stage);
      DiagnosticsLog.add(this,"ERROR",stage+": "+e.getClass().getSimpleName());
      pauseForFailure("خطأ في مرحلة "+stage+"؛ تم حفظ تقرير قابل للنسخ");
    }
  }
  private void safePost(long delay,String stage,Runnable action){
    handler.postDelayed(()->safeRun(stage,action),delay);
  }

  public void begin(){safeRun("بدء الفحص",this::startInternal);}
  private void startInternal(){
    if(store==null)store=new ScanStore(this);
    if(config==null)config=new ScannerConfig(this);
    if(running)return;
    if(store.pendingCount()==0){store.state("DONE","لا توجد روابط معلقة");return;}
    targetPackage=selectedPackage();
    if(targetPackage.isEmpty()){
      store.state("PAUSED","حدد واتساب الرسمي أو Business وثبّت التطبيق المختار");return;
    }
    intentionallyStopped=false;CrashReporter.acknowledge(this);
    if(!"RECOVERING".equals(store.state()))missingStreak=0;
    running=true;phase=Phase.IDLE;store.state("RUNNING","تم بدء فحص متسلسل؛ حفظ النتيجة قبل الرابط التالي");updateFloatingControls();
    navigateNext();
  }
  public void stop(){
    DiagnosticsLog.add(this,"CONTROL","إيقاف يدوي للمحرك؛ الرابط="+(index<0?"—":(index+1))+"؛ المرحلة="+phaseLabel());
    intentionallyStopped=true;invalidateTimers();running=false;phase=Phase.PAUSED;
    if(store!=null)store.state("PAUSED","إيقاف يدوي؛ الرابط غير المكتمل محفوظ للاستكمال");updateFloatingControls();
  }
  public void clear(){
    intentionallyStopped=true;invalidateTimers();running=false;phase=Phase.IDLE;index=-1;
    if(store!=null)store.clear();updateFloatingControls();
  }
  public void applyOverlaySetting(){
    if(config==null)config=new ScannerConfig(this);
    if(config.overlayEnabled()){showFloatingControls();updateFloatingControls();}else removeFloatingControls();
  }
  public void skipCurrent(){
    safeRun("تخطي الرابط",()->{
      if(!running||index<0)return;
      DiagnosticsLog.add(this,"CONTROL","تخطي يدوي للرابط "+(index+1));
      if(!store.defer(index,"تخطي يدوي؛ أُعيد الرابط إلى قائمة الإعادة")){pauseForFailure("تعذر حفظ الرابط قبل التخطي");return;}
      dismissThenNext();
    });
  }

  private void navigateNext(){
    if(!running)return;
    int next=store.next();
    if(next<0){invalidateTimers();running=false;phase=Phase.IDLE;index=-1;
      store.state("DONE","اكتملت الروابط القابلة للمعالجة");updateFloatingControls();return;}
    index=next;overlayData="جارٍ فتح الرابط";updateFloatingControls();
    long wait=store.cooldownUntil()-System.currentTimeMillis();
    if(wait>0){phase=Phase.COOLDOWN;store.state("COOLDOWN","واتساب في فترة تهدئة");
      final long gen=generation;final int id=index;
      safePost(Math.max(1000L,wait),"نهاية التهدئة",()->{
        if(gen==generation&&running&&id==index){store.state("RUNNING","انتهت التهدئة");openCurrent();}
      });return;
    }
    openCurrent();
  }

  private void openCurrent(){
    if(!running||index<0)return;
    invalidateTimers();
    final long gen=generation;
    final int id=index;
    phase=Phase.OPENING;candidate="";stableSamples=0;stabilityGraceUsed=false;previewVerified=false;
    sawNewWindow=false;sawWhatsAppEvent=false;lastRead=0L;
    xWasTried=false;backWasTried=false;dismissChecks=0;backAttempts=0;previewFingerprint="";
    launchedAt=System.currentTimeMillis();launchedUptime=SystemClock.uptimeMillis();
    beforeWindow=-1;beforeFingerprint="";
    AccessibilityNodeInfo prior=getRootInActiveWindow();
    if(prior!=null){
      try{beforeWindow=prior.getWindowId();List<String> labels=new ArrayList<>();collect(prior,labels,0);beforeFingerprint=fingerprint(labels);}
      finally{prior.recycle();}
    }
    org.json.JSONObject data=store.at(id);
    if(data==null){pauseForFailure("رابط غير موجود في قائمة الانتظار");return;}
    String url=data.optString("url","");
    // Persist attempt + in-flight ownership in ONE transaction before opening WhatsApp.
    attempt=store.claim(id);
    if(attempt<0){pauseForFailure("تعذر تثبيت نقطة استكمال الرابط قبل فتح واتساب");return;}
    store.state("RUNNING","فتح "+(id+1)+" / "+store.size()+"؛ مرحلة: التحقق من المعاينة");
    DiagnosticsLog.add(this,"OPEN","الرابط "+(id+1)+" / "+store.size()+"؛ مهلة "+(timeoutMillis()/1000)+" ثوانٍ");
    overlayData="جارٍ قراءة البيانات";updateFloatingControls();
    try {
      Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
      intent.setPackage(targetPackage);
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
      if(intent.resolveActivity(getPackageManager())==null){
        finishResult("UNRESOLVED","","","UNKNOWN","UNKNOWN","",0,"تعذر فتح الرابط في واتساب المختار؛ لا يوجد دليل صريح أنه غير صالح");return;
      }
      startActivity(intent);
    }catch(RuntimeException e){
      DiagnosticsLog.add(this,"ERROR","فتح الرابط: "+e.getClass().getSimpleName());
      finishResult("UNRESOLVED","","","UNKNOWN","UNKNOWN","",0,"تعذر تشغيل معاينة الرابط في واتساب؛ سيعاد فحصه");return;
    }
    phase=Phase.VERIFYING;
    for(long delay:sampleDelays()){
      safePost(delay,"قراءة المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)capture();});
    }
    safePost(timeoutMillis(),"مهلة المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)onTimeout();});
  }

  @Override public void onAccessibilityEvent(AccessibilityEvent event){
    if(event==null||event.getPackageName()==null)return;
    String pkg=event.getPackageName().toString();
    if(!"com.whatsapp".equals(pkg)&&!"com.whatsapp.w4b".equals(pkg))return;
    long now=System.currentTimeMillis();lastWhatsAppEvent=now;eventCount++;WhatsAppTarget.rememberObserved(this,pkg);
    getSharedPreferences("accessibility_health",MODE_PRIVATE).edit().putLong("heartbeat",now).putBoolean("connected",true).apply();
    if(probeStarted>0&&now-probeStarted<=15000){
      probeEvents++;probePackage=pkg;
      AccessibilityNodeInfo root=getRootInActiveWindow();
      if(root!=null){try{
        if(root.getPackageName()!=null&&pkg.contentEquals(root.getPackageName())){
          List<String> l=new ArrayList<>();collectPreview(root,l);probeNodes=Math.max(probeNodes,l.size());
        }
      }finally{root.recycle();}}
    }
    if(!running||!pkg.equals(targetPackage)||event.getEventTime()<launchedUptime)return;
    sawWhatsAppEvent=true;
    if(event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.getWindowId()!=beforeWindow)
      sawNewWindow=true;
    try{
      if(phase==Phase.VERIFYING)capture();
      else if(phase==Phase.DISMISSING)checkDismissed(generation,index);
    }catch(RuntimeException | LinkageError failure){
      CrashReporter.recordHandled(this,failure,"أحداث واتساب");
      DiagnosticsLog.add(this,"ERROR","واجهة واتساب: "+failure.getClass().getSimpleName());
      pauseForFailure("خطأ في قراءة/إغلاق المعاينة؛ افتح سجل الانهيار أو التشخيص");
    }
  }

  private void collect(AccessibilityNodeInfo node,List<String> labels,int depth){
    if(node==null||depth>25||labels.size()>=160)return;
    CharSequence text=node.getText(), description=node.getContentDescription();
    if(text!=null&&!text.toString().trim().isEmpty())labels.add(text.toString().trim());
    if(description!=null&&!description.toString().trim().isEmpty()
        &&(text==null||!description.toString().equals(text.toString())))labels.add(description.toString().trim());
    for(int i=0;i<node.getChildCount()&&labels.size()<160;i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){try{collect(child,labels,depth+1);}finally{child.recycle();}}
    }
  }
  private static final class VisualLabel {
    final String text; final int top; final int left;
    VisualLabel(String text,int top,int left){this.text=text;this.top=top;this.left=left;}
  }
  private void collectVisualNodes(AccessibilityNodeInfo node,List<VisualLabel> out,int depth){
    if(node==null||depth>25||out.size()>=220)return;
    Rect r=new Rect();node.getBoundsInScreen(r);
    CharSequence text=node.getText(), description=node.getContentDescription();
    if(text!=null&&!text.toString().trim().isEmpty())out.add(new VisualLabel(text.toString().trim(),r.top,r.left));
    if(description!=null&&!description.toString().trim().isEmpty()&&(text==null||!description.toString().equals(text.toString()))){
      String d=description.toString().trim(), low=d.toLowerCase(Locale.ROOT);
      boolean structural=low.equals("close")||low.equals("drag handle")||low.equals("sheet handle")
          ||d.equals("إغلاق")||d.equals("اغلاق")||d.contains("مقبض السحب")||d.startsWith("زر إغلاق")||d.startsWith("زر اغلاق");
      if(!structural)out.add(new VisualLabel(d,r.top,r.left));
    }
    for(int i=0;i<node.getChildCount()&&out.size()<220;i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){try{collectVisualNodes(child,out,depth+1);}finally{child.recycle();}}
    }
  }
  /** Visual-order fallback for Samsung/OneUI trees where the title is outside the action subtree. */
  private void collectVisual(AccessibilityNodeInfo root,List<String> labels){
    List<VisualLabel> items=new ArrayList<>();collectVisualNodes(root,items,0);
    Collections.sort(items,new Comparator<VisualLabel>(){
      @Override public int compare(VisualLabel a,VisualLabel b){int y=Integer.compare(a.top,b.top);return y!=0?y:Integer.compare(a.left,b.left);}
    });
    LinkedHashSet<String> unique=new LinkedHashSet<>();
    for(VisualLabel item:items){String v=item.text==null?"":item.text.trim();if(!v.isEmpty())unique.add(v);}
    labels.addAll(unique);
  }
  private PreviewParser.Result parseBest(AccessibilityNodeInfo root,List<String> primary){
    PreviewParser.Result parsed=PreviewParser.parse(primary,currentUrl());
    if("UNRESOLVED".equals(parsed.status)&&"ACTION_WITHOUT_TITLE".equals(parsed.evidence)){
      List<String> visual=new ArrayList<>();collectVisual(root,visual);
      PreviewParser.Result fallback=PreviewParser.parse(visual,currentUrl());
      if(!"UNRESOLVED".equals(fallback.status)&&fallback.name!=null&&!fallback.name.isEmpty())return fallback;
    }
    return parsed;
  }
  private boolean fastFinal(PreviewParser.Result parsed){
    if(parsed==null||"UNRESOLVED".equals(parsed.status)||parsed.rateLimited)return false;
    if(parsed.name==null||parsed.name.isEmpty())return false;
    // One strong structured sample is enough; avoids reopening/duplicate processing.
    return parsed.accuracy>=90 || (parsed.evidence!=null&&parsed.evidence.startsWith("TITLE+ACTION"));
  }

  private AccessibilityNodeInfo findInvitationNode(AccessibilityNodeInfo node,int depth){
    if(node==null||depth>22)return null;
    String text=node.getText()==null?"":node.getText().toString();
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString();
    if(invitationActionLoose(text)||invitationActionLoose(desc))return AccessibilityNodeInfo.obtain(node);
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);if(child==null)continue;
      try{AccessibilityNodeInfo found=findInvitationNode(child,depth+1);if(found!=null)return found;}finally{child.recycle();}
    }
    return null;
  }
  /** Isolates the smallest large ancestor around the invitation action to avoid background chat text. */
  private AccessibilityNodeInfo previewContainer(AccessibilityNodeInfo root){
    AccessibilityNodeInfo action=findInvitationNode(root,0);if(action==null)return null;
    Rect rr=new Rect();root.getBoundsInScreen(rr);AccessibilityNodeInfo best=AccessibilityNodeInfo.obtain(action);
    AccessibilityNodeInfo cursor=action;
    try{
      for(int level=0;level<8;level++){
        AccessibilityNodeInfo parent=cursor.getParent();if(parent==null)break;
        Rect r=new Rect();parent.getBoundsInScreen(r);
        boolean broad=rr.width()>0&&rr.height()>0&&r.width()>=rr.width()*0.72&&r.height()>=rr.height()*0.28;
        boolean notFull=rr.height()==0||r.height()<rr.height()*0.96;
        if(broad&&notFull){best.recycle();best=AccessibilityNodeInfo.obtain(parent);}
        if(cursor!=action)cursor.recycle();cursor=parent;
      }
    }finally{if(cursor!=action)cursor.recycle();action.recycle();}
    return best;
  }
  private void collectPreview(AccessibilityNodeInfo root,List<String> labels){
    AccessibilityNodeInfo container=previewContainer(root);
    if(container==null){collect(root,labels,0);return;}
    try{collect(container,labels,0);}finally{container.recycle();}
  }
  private static String label(AccessibilityNodeInfo node){
    String text=node.getText()==null?"":node.getText().toString();
    String description=node.getContentDescription()==null?"":node.getContentDescription().toString();
    return (text+" "+description).trim().toLowerCase(Locale.ROOT);
  }
  private static boolean invitationAction(String text){
    return text.equals("join group")||text.equals("request to join")||text.equals("ask to join")
        ||text.equals("join community")||text.equals("follow channel")||text.equals("join channel")
        ||text.equals("انضم إلى المجموعة")||text.equals("الانضمام إلى المجموعة")
        ||text.equals("طلب الانضمام")||text.equals("الانضمام إلى المجتمع")
        ||text.equals("متابعة القناة")||text.equals("الانضمام إلى القناة");
  }
  private static boolean invitationActionLoose(String value){
    if(value==null)return false;
    String text=value.trim().toLowerCase(Locale.ROOT);
    if(invitationAction(text))return true;
    return text.equals("join")||text.equals("follow")||text.equals("request")
        ||text.contains("request to join")||text.contains("ask to join")
        ||text.equals("انضم")||text.equals("الانضمام")||text.equals("متابعة")
        ||text.contains("طلب الانضمام")||text.contains("طلب الموافقة");
  }
  private static boolean clickableNodeOrParent(AccessibilityNodeInfo node){
    if(node.isClickable())return true;
    AccessibilityNodeInfo parent=node.getParent();
    if(parent==null)return false;
    try{return parent.isClickable();}finally{parent.recycle();}
  }
  private boolean hasActionButton(AccessibilityNodeInfo node,int depth){
    if(node==null||depth>19)return false;
    String text=node.getText()==null?"":node.getText().toString().trim().toLowerCase(Locale.ROOT);
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString().trim().toLowerCase(Locale.ROOT);
    if((invitationActionLoose(text)||invitationActionLoose(desc))&&clickableNodeOrParent(node))return true;
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){boolean found;
        try{found=hasActionButton(child,depth+1);}finally{child.recycle();}
        if(found)return true;
      }
    }
    return false;
  }
  private boolean hasActionEvidence(AccessibilityNodeInfo node,int depth){
    if(node==null||depth>21)return false;
    String text=node.getText()==null?"":node.getText().toString();
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString();
    if(invitationActionLoose(text)||invitationActionLoose(desc))return true;
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){boolean found;
        try{found=hasActionEvidence(child,depth+1);}finally{child.recycle();}
        if(found)return true;
      }
    }
    return false;
  }
  private boolean hasCloseControl(AccessibilityNodeInfo node,int depth){
    if(node==null||depth>21)return false;
    String text=node.getText()==null?"":node.getText().toString();
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString();
    if((closeLabel(text,true)||closeLabel(desc,true))&&clickableNodeOrParent(node))return true;
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){boolean found;
        try{found=hasCloseControl(child,depth+1);}finally{child.recycle();}
        if(found)return true;
      }
    }
    return false;
  }
  private boolean isPreview(AccessibilityNodeInfo root,List<String> labels){
    PreviewParser.Result parsed=parseBest(root,labels);
    // Strong parser evidence is sufficient even when WhatsApp exposes the action as non-clickable.
    if(!"UNRESOLVED".equals(parsed.status)||parsed.rateLimited)return true;
    // Structural evidence from the bottom-sheet invitation is also accepted.
    return hasActionButton(root,0)||hasActionEvidence(root,0)||hasCloseControl(root,0);
  }
  private String overlayCount(PreviewParser.Result parsed){
    if(parsed==null)return "";
    if(parsed.members!=null&&!parsed.members.isEmpty())return parsed.members+" "+ScanStore.countUnit(parsed.countType);
    if(parsed.approximateCount!=null&&!parsed.approximateCount.isEmpty())return "+"+parsed.approximateCount+" ظاهر تقريبًا";
    if(parsed.name!=null&&!parsed.name.isEmpty())return "العدد غير ظاهر";
    return "جارٍ قراءة البيانات";
  }
  private void persistObservation(PreviewParser.Result parsed){
    if(parsed==null||store==null||index<0)return;
    store.observe(index,parsed.status,parsed.name,parsed.members,parsed.approximateCount,parsed.countType,parsed.countPrecision,
        parsed.joinType,parsed.creationDate,parsed.creator,parsed.evidence,parsed.accuracy,parsed.note);
    org.json.JSONObject row=store.at(index);
    if(row!=null)overlayData=ScanStore.countDisplay(row);else overlayData=overlayCount(parsed);
    updateFloatingControls();
  }

  private void capture(){
    if(!running||phase!=Phase.VERIFYING||index<0)return;
    long now=System.currentTimeMillis();
    if(now-launchedAt<280||now-lastRead<100)return;
    lastRead=now;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    try{
      if(root.getPackageName()==null||!targetPackage.contentEquals(root.getPackageName()))return;
      List<String> labels=new ArrayList<>();collectPreview(root,labels);
      String fp=fingerprint(labels);
      // Require a fresh event AND either a different window or changed visible content.
      if(!sawNewWindow&&fp.equals(beforeFingerprint))return;
      PreviewParser.Result parsed=parseBest(root,labels);
      persistObservation(parsed);
      if(parsed.rateLimited){
        if(labels.size()<=24)onLimit();
        return;
      }
      if(!isPreview(root,labels))return;
      previewVerified=true;previewFingerprint=fp;missingStreak=0;
      if("UNRESOLVED".equals(parsed.status))return;
      if(fastFinal(parsed)){
        DiagnosticsLog.add(this,"FAST","نتيجة منظمة مؤكدة من القراءة الأولى؛ حفظ وانتقال دون تكرار");
        finishResult(parsed);return;
      }
      String signature=parsed.status+"|"+parsed.name+"|"+parsed.members+"|"+parsed.approximateCount+"|"+parsed.joinType+"|"+parsed.creator+"|"+parsed.creationDate;
      if(!signature.equals(candidate)){
        candidate=signature;stableSamples=1;
        long gen=generation;int id=index;
        safePost(110,"تأكيد ثبات المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)capture();});
      }else if(++stableSamples>=2){
        finishResult(parsed);
      }
    }finally{root.recycle();}
  }

  private void onTimeout(){
    if(!running||phase!=Phase.VERIFYING||index<0)return;
    if(previewVerified && !candidate.isEmpty() && stableSamples==1 && !stabilityGraceUsed){
      stabilityGraceUsed=true;
      final long gen=generation;final int id=index;
      safePost(280,"تمديد مهلة المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)onTimeout();});
      DiagnosticsLog.add(this,"PREVIEW","تمديد قصير لتأكيد ثبات المعاينة الظاهرة");
      return;
    }
    DiagnosticsLog.add(this,"PREVIEW","الرابط "+(index+1)+": معاينة مؤكدة="+previewVerified+"؛ أحداث="+sawWhatsAppEvent
        +"؛ المدة="+(System.currentTimeMillis()-launchedAt)+"ms");
    if(!previewVerified){
      missingStreak++;
      if(NavigationPolicy.shouldCircuitBreak(missingStreak,NO_PREVIEW_LIMIT))
        DiagnosticsLog.add(this,"GUARD","لم تظهر "+missingStreak+" معاينات متتالية؛ سيستمر المحرك مع إعادة المحاولة وتصنيف الرابط النهائي وفق النتيجة");
    }
    if(attempt<Math.max(1,(config==null?1:config.retries()))){
      if(!store.defer(index,"لم تثبت معاينة الدعوة؛ أُجّلت المحاولة دون اعتباره رابطًا غير صالح")){
        pauseForFailure("تعذر حفظ محاولة الرابط المؤجل");return;
      }
      DiagnosticsLog.add(this,"FLOW","حُفظ التأجيل؛ متابعة الرابط التالي");
      dismissThenNext();
    }else{
      finishResult("UNRESOLVED","","","UNKNOWN","UNKNOWN","",0,"لم تظهر نتيجة/معاينة موثوقة بعد جميع المحاولات؛ أُبقي الرابط لإعادة الفحص");
    }
  }
  private void finishResult(PreviewParser.Result parsed){
    if(!running||index<0)return;
    persistObservation(parsed);
    if(!store.complete(index,parsed.status,parsed.name,parsed.members,parsed.approximateCount,parsed.countType,parsed.countPrecision,parsed.joinType,parsed.creationDate,parsed.creator,parsed.evidence,parsed.accuracy,parsed.note)){
      pauseForFailure("تعذر حفظ النتيجة؛ لن نفتح الرابط التالي قبل حفظها");return;
    }
    if(!"UNRESOLVED".equals(parsed.status))missingStreak=0;
    DiagnosticsLog.add(this,"FLOW","حُفظت نتيجة الرابط "+(index+1)+"؛ الدقة="+parsed.accuracy+"%؛ المدة="
        +(System.currentTimeMillis()-launchedAt)+"ms؛ الانتقال لمرحلة الإغلاق");
    dismissThenNext();
  }
  private void finishResult(String status,String name,String members,String countType,String joinType,String note){
    int accuracy="INVALID".equals(status)?100:((name!=null&&!name.isEmpty())?90:0);
    finishResult(status,name,members,countType,joinType,"",accuracy,note);
  }
  private void finishResult(String status,String name,String members,String countType,String joinType,String creationDate,int accuracy,String note){
    if(!running||index<0)return;
    if(members!=null&&!members.isEmpty()){String unit="FOLLOWERS".equals(countType)?"متابع":"SUBGROUPS".equals(countType)?"قروب":"عضو";overlayData=members+" "+unit;}else overlayData=name!=null&&!name.isEmpty()?"العدد غير ظاهر":"غير محسوم";
    updateFloatingControls();
    if(!store.complete(index,status,name,members,countType,joinType,creationDate,accuracy,note)){
      pauseForFailure("تعذر حفظ النتيجة؛ لن نفتح الرابط التالي قبل حفظها");return;
    }
    if(!"UNRESOLVED".equals(status))missingStreak=0;
    DiagnosticsLog.add(this,"FLOW","حُفظت نتيجة الرابط "+(index+1)+"؛ الدقة="+accuracy+"%؛ المدة="
        +(System.currentTimeMillis()-launchedAt)+"ms؛ الانتقال لمرحلة الإغلاق");
    dismissThenNext();
  }

  private static boolean closeLabel(String text,boolean strictX){
    if(text==null)return false;
    String s=text.trim().toLowerCase(Locale.ROOT);
    if(s.equals("×")||s.equals("✕")||s.equals("✖")||s.equals("x")||s.equals("close")
        ||s.equals("dismiss")||s.equals("إغلاق")||s.equals("اغلاق"))return true;
    return !strictX&&(s.equals("cancel")||s.equals("إلغاء")||s.equals("الغاء"));
  }
  private boolean tapClose(AccessibilityNodeInfo node,int depth,boolean strictX){
    if(node==null||depth>19)return false;
    String text=node.getText()==null?"":node.getText().toString();
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString();
    if(closeLabel(text,strictX)||closeLabel(desc,strictX)){
      if(node.isClickable()&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
      AccessibilityNodeInfo parent=node.getParent();
      if(parent!=null){try{
        if(parent.isClickable()&&parent.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
      }finally{parent.recycle();}}
    }
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){boolean clicked;
        try{clicked=tapClose(child,depth+1,strictX);}finally{child.recycle();}
        if(clicked)return true;
      }
    }
    return false;
  }
  private boolean tapStructuralClose(AccessibilityNodeInfo root){
    AccessibilityNodeInfo container=previewContainer(root);if(container==null)return false;
    try{
      Rect sheet=new Rect();container.getBoundsInScreen(sheet);if(sheet.width()<=0||sheet.height()<=0)return false;
      return tapStructuralCloseNode(container,sheet,0);
    }finally{container.recycle();}
  }
  private boolean tapStructuralCloseNode(AccessibilityNodeInfo node,Rect sheet,int depth){
    if(node==null||depth>15)return false;
    Rect r=new Rect();node.getBoundsInScreen(r);int edge=Math.max(1,sheet.width()/4);int topBand=sheet.top+Math.max(1,sheet.height()/3);
    boolean edgeNode=r.centerY()<=topBand&&(r.centerX()<=sheet.left+edge||r.centerX()>=sheet.right-edge);
    int max=(int)(120*getResources().getDisplayMetrics().density);int min=(int)(18*getResources().getDisplayMetrics().density);
    boolean size=r.width()>=min&&r.height()>=min&&r.width()<=max&&r.height()<=max;
    String l=label(node);
    if(edgeNode&&size&&!invitationActionLoose(l)){
      if(node.isClickable()&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK)){DiagnosticsLog.add(this,"NAV","تم اكتشاف X هيكليًا داخل نافذة الدعوة");return true;}
      AccessibilityNodeInfo parent=node.getParent();if(parent!=null){try{if(parent.isClickable()&&parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)){DiagnosticsLog.add(this,"NAV","تم ضغط حاوية X الهيكلية داخل نافذة الدعوة");return true;}}finally{parent.recycle();}}
    }
    for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child==null)continue;try{if(tapStructuralCloseNode(child,sheet,depth+1))return true;}finally{child.recycle();}}
    return false;
  }
  private boolean tryX(AccessibilityNodeInfo root){return tapClose(root,0,true)||tapStructuralClose(root)||tapClose(root,0,false);}
  private void dismissThenNext(){
    if(!running)return;
    invalidateTimers();phase=Phase.DISMISSING;dismissChecks=0;xWasTried=false;backWasTried=false;backAttempts=0;
    final long gen=generation;final int id=index;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null){navigation("لا توجد نافذة معاينة نشطة؛ الانتقال دون Back");queueNext(gen,id);return;}
    try{
      boolean same=root.getPackageName()!=null&&targetPackage.contentEquals(root.getPackageName());
      List<String> labels=new ArrayList<>();if(same)collectPreview(root,labels);
      String currentFingerprint=same?fingerprint(labels):"";
      boolean changed=same&&!currentFingerprint.equals(beforeFingerprint);
      boolean visible=same&&(previewVerified||hasCloseControl(root,0)||hasActionEvidence(root,0)||
          (sawWhatsAppEvent&&changed));
      boolean possibleX=visible&&hasCloseControl(root,0);
      NavigationPolicy.Action plan=NavigationPolicy.nextDismissAction(same,visible,possibleX,false,false);
      if(plan==NavigationPolicy.Action.NO_ACTION){
        navigation("لا توجد معاينة مؤكدة؛ لا يُضغط Back خارج الدعوة");queueNext(gen,id);return;
      }
      xWasTried=true;
      if(plan==NavigationPolicy.Action.CLICK_CLOSE && tryX(root)){
        navigation("نُقر زر X/إغلاق داخل معاينة واتساب؛ انتظار تأكيد الإغلاق");
      }else{
        backWasTried=true;backAttempts++;
        boolean ok=performGlobalAction(GLOBAL_ACTION_BACK);
        navigation(ok?"لا يوجد X صالح؛ استخدام Back داخل المعاينة":"تعذر إجراء Back؛ التحقق من النافذة");
      }
    }finally{root.recycle();}
    safePost(220,"تأكيد إغلاق X",()->checkDismissed(gen,id));
    safePost(650,"Back احتياطي",()->checkDismissed(gen,id));
    safePost(1250,"تأكيد الإغلاق",()->checkDismissed(gen,id));
    safePost(1900,"مهلة إغلاق المعاينة",()->checkDismissed(gen,id));
  }
  private void checkDismissed(long gen,int id){
    if(!valid(gen,id)||phase!=Phase.DISMISSING)return;
    dismissChecks++;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null){
      // A successful close can briefly leave no accessible root; verify again once.
      if(dismissChecks>=2){navigation("اختفت نافذة المعاينة؛ الانتقال للرابط التالي");queueNext(gen,id);}return;
    }
    try{
      boolean same=root.getPackageName()!=null&&targetPackage.contentEquals(root.getPackageName());
      List<String> labels=new ArrayList<>();if(same)collectPreview(root,labels);
      String fp=same?fingerprint(labels):"";
      boolean actionEvidence=same&&(hasActionEvidence(root,0)||hasCloseControl(root,0));
      boolean fingerprintChanged=!previewFingerprint.isEmpty()&&!fp.equals(previewFingerprint);
      if(!same||!actionEvidence||(fingerprintChanged&&!isPreview(root,labels))){
        navigation("تأكيد اختفاء المعاينة؛ الرابط التالي");queueNext(gen,id);return;
      }
      if(dismissChecks>=2 && backAttempts<2){
        backWasTried=true;backAttempts++;
        boolean ok=performGlobalAction(GLOBAL_ACTION_BACK);
        navigation(ok?"المعاينة ما زالت ظاهرة؛ Back احتياطي رقم "+backAttempts:"تعذر Back الاحتياطي");
      }else if(dismissChecks>=4){
        navigation("تعذر تأكيد الإغلاق بعد محاولتين؛ متابعة الرابط التالي بدون إيقاف المحرك");
        queueNext(gen,id);
      }
    }finally{root.recycle();}
  }
  private void queueNext(long gen,int id){
    if(!valid(gen,id))return;
    phase=Phase.WAITING_NEXT;
    final long newGeneration=++generation;
    handler.removeCallbacksAndMessages(null);
    navigation("حُفظت معالجة الرابط "+(id+1)+"؛ بدء التالي بعد الفاصل المحدد");
    safePost(gapMillis(),"الرابط التالي",()->{
      if(running&&phase==Phase.WAITING_NEXT&&newGeneration==generation){
        index=-1;previewVerified=false;navigateNext();
      }
    });
  }
  private void pauseForFailure(String message){
    invalidateTimers();running=false;phase=Phase.PAUSED;
    if(store!=null)store.state("PAUSED",message);updateFloatingControls();
    DiagnosticsLog.add(this,"GUARD",message);
  }
  private GradientDrawable overlayBackground(int color,int radius){
    GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;
  }
  private TextView overlayText(String text,int size,int color,boolean bold){
    TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER);
    if(bold)v.setTypeface(null,android.graphics.Typeface.BOLD);v.setPadding(16,10,16,10);return v;
  }
  private TextView overlayButton(String label,int color,Runnable action){
    TextView b=overlayText(label,13,Color.WHITE,true);b.setBackground(overlayBackground(color,18));
    b.setOnClickListener(v->action.run());return b;
  }
  private void showFloatingControls(){
    if(overlayPanel!=null||(config!=null&&!config.overlayEnabled()))return;
    try{
      overlayWindow=(WindowManager)getSystemService(WINDOW_SERVICE);
      overlayPanel=new LinearLayout(this);overlayPanel.setOrientation(LinearLayout.VERTICAL);
      overlayPanel.setPadding(10,8,10,10);overlayPanel.setBackground(overlayBackground(0xf20b2f2c,26));

      LinearLayout dragBar=new LinearLayout(this);dragBar.setOrientation(LinearLayout.HORIZONTAL);dragBar.setGravity(Gravity.CENTER_VERTICAL);
      overlayStatus=overlayText("WA Scan",11,0xffd7fff0,true);overlayStatus.setTextDirection(View.TEXT_DIRECTION_LTR);dragBar.addView(overlayStatus,new LinearLayout.LayoutParams(0,-2,1));
      overlayCollapse=overlayText("−",16,0xffffffff,true);overlayCollapse.setBackground(overlayBackground(0x33ffffff,16));
      overlayCollapse.setOnClickListener(v->toggleOverlayCollapsed());dragBar.addView(overlayCollapse,new LinearLayout.LayoutParams(-2,-2));
      overlayPanel.addView(dragBar,new LinearLayout.LayoutParams(-1,-2));
      overlayMeta=overlayText("جاهز",10,0xffe9fff7,false);overlayMeta.setGravity(Gravity.CENTER);overlayPanel.addView(overlayMeta,new LinearLayout.LayoutParams(-1,-2));

      overlayActions=new LinearLayout(this);overlayActions.setOrientation(LinearLayout.HORIZONTAL);overlayActions.setGravity(Gravity.CENTER);
      overlayToggle=overlayButton("⏸",0xff0c8f60,()->{if(running)stop();else begin();updateFloatingControls();});
      overlaySkip=overlayButton("⏭",0xff6d7780,this::skipCurrent);
      overlayStop=overlayButton("■",0xffd84242,this::stop);
      for(TextView b:new TextView[]{overlayToggle,overlaySkip,overlayStop}){LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.setMargins(4,6,4,0);overlayActions.addView(b,bp);}
      overlayPanel.addView(overlayActions,new LinearLayout.LayoutParams(-1,-2));
      overlayStatus.setOnClickListener(v->{if(overlayCollapsed)toggleOverlayCollapsed();});

      final float[] down=new float[4];
      dragBar.setOnTouchListener((v,e)->{
        if(overlayParams==null)return false;
        if(e.getAction()==MotionEvent.ACTION_DOWN){down[0]=e.getRawX();down[1]=e.getRawY();down[2]=overlayParams.x;down[3]=overlayParams.y;return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){overlayParams.x=(int)(down[2]-(e.getRawX()-down[0]));overlayParams.y=(int)(down[3]+(e.getRawY()-down[1]));overlayWindow.updateViewLayout(overlayPanel,overlayParams);return true;}
        return e.getAction()==MotionEvent.ACTION_UP;
      });
      overlayParams=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
      overlayParams.gravity=Gravity.TOP|Gravity.END;overlayParams.x=16;overlayParams.y=180;
      overlayPanel.setOnClickListener(v->{if(overlayCollapsed)toggleOverlayCollapsed();});
      overlayWindow.addView(overlayPanel,overlayParams);
      updateFloatingControls();
      DiagnosticsLog.add(this,"OVERLAY","واجهة التحكم العائمة جاهزة");
    }catch(Exception e){DiagnosticsLog.add(this,"OVERLAY","تعذر إنشاء الواجهة العائمة: "+e.getClass().getSimpleName());overlayPanel=null;}
  }
  private void toggleOverlayCollapsed(){
    overlayCollapsed=!overlayCollapsed;
    if(config!=null)config.overlayCollapsed(overlayCollapsed);
    updateFloatingControls();
    DiagnosticsLog.add(this,"OVERLAY",overlayCollapsed?"تصغير الواجهة العائمة إلى زر":"توسيع الواجهة العائمة");
  }
  private void updateFloatingControls(){
    handler.post(()->{
      if(config!=null&&config.overlayEnabled()&&overlayPanel==null)showFloatingControls();
      if(overlayToggle==null||overlayStatus==null)return;
      int total=store==null?0:store.size();int currentNo=index>=0?index+1:Math.max(0,total-(store==null?0:store.pendingCount()));
      overlayToggle.setText(running?"⏸":"▶");
      overlayToggle.setBackground(overlayBackground(running?0xfff08b24:0xff1976d2,18));
      overlayStatus.setText(overlayCollapsed?("WA "+currentNo):((running?"WA Scan":"Paused")+"  "+currentNo+" / "+total));
      if(overlayMeta!=null){String d=overlayData==null||overlayData.isEmpty()?phaseLabel():overlayData;overlayMeta.setText(d);overlayMeta.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);}
      if(overlayActions!=null)overlayActions.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);
      if(overlayCollapse!=null){overlayCollapse.setText(overlayCollapsed?"＋":"−");overlayCollapse.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);}
      if(overlaySkip!=null)overlaySkip.setAlpha(running&&index>=0?1f:.45f);
      if(overlayPanel!=null){overlayPanel.setPadding(overlayCollapsed?6:10,overlayCollapsed?4:8,overlayCollapsed?6:10,overlayCollapsed?4:10);}
    });
  }
  private void removeFloatingControls(){
    if(overlayWindow!=null&&overlayPanel!=null){try{overlayWindow.removeView(overlayPanel);}catch(Exception ignored){}}
    overlayPanel=null;overlayToggle=null;overlayStatus=null;overlayMeta=null;overlaySkip=null;overlayStop=null;overlayCollapse=null;overlayActions=null;overlayParams=null;overlayData="";
  }

  private void onLimit(){
    if(!running)return;
    invalidateTimers();running=false;phase=Phase.COOLDOWN;
    int step=Math.min(store.cooldownStep(),COOLDOWN.length-1);
    long wait=COOLDOWN[step];store.cooldown(Math.min(step+1,COOLDOWN.length-1),System.currentTimeMillis()+wait);
    store.state("COOLDOWN","واتساب طلب التمهل؛ لا نتابع الفحص أثناء التقييد");updateFloatingControls();
    DiagnosticsLog.add(this,"LIMIT","حماية التقييد: توقف الفحص؛ الانتظار "+(wait/60000)+" دقيقة");
    // Deliberately no hidden hourly retries after a restriction without user confirmation.
  }
}
