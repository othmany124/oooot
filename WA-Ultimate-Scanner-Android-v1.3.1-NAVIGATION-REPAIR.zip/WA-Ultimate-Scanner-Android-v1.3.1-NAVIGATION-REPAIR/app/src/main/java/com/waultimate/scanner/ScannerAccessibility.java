package com.waultimate.scanner;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.List;

/** User-started, sequential scanner. Only reads text; never presses Join or sends messages. */
public final class ScannerAccessibility extends AccessibilityService {
  public static ScannerAccessibility current;
  private final Handler h=new Handler(Looper.getMainLooper());
  private ScanStore store;
  private ScannerConfig config;
  private boolean running=false, paused=false;
  private int idx=-1, attempt=0;
  private long launchedAt=0,lastRead=0;
  private String candidate="";
  private String confirmedCountType="UNKNOWN",confirmedJoinType="UNKNOWN";
  private String observationNote="";
  private final Runnable settle = () -> verifyStableSnapshot();
  private int stable=0;
  private String activePackage="", preLaunchFingerprint="";
  private boolean observedNewScreen=false;
  private boolean navigationPending=false;
  private int missingPreviewStreak=0;
  private long launchSerial=0L;
  private long lastWhatsAppEvent=0;
  private long eventCount=0;
  private long probeStartAt=0;
  private int probeEvents=0, probeReadableNodes=0;
  private String probePackage="";
  // Probe captures only event counts and package name: never message text.
  public void beginProbe(){DiagnosticsLog.add(this,"PROBE","بدء اختبار الاتصال");probeStartAt=System.currentTimeMillis();probeEvents=0;probeReadableNodes=0;probePackage="";}
  public int probeEventCount(){return probeEvents;}
  public int probeNodeCount(){return probeReadableNodes;}
  public String probeSummary(){return "أحداث واتساب منذ الاختبار: "+probeEvents
      +"\nعناصر نصية مقروءة: "+probeReadableNodes
      +"\nالحزمة المرصودة: "+(probePackage.isEmpty()?"لا توجد":probePackage)
      +"\nالخدمة متصلة: "+(current==this?"نعم":"لا")
      +"\nملاحظة: ظهور الأحداث لا يثبت صحة تصنيف الدعوات.";}
  public String diagnostics(){return "الخدمة متصلة: "+(current==this?"نعم":"لا")+"\nآخر حدث واتساب: "+(lastWhatsAppEvent==0?"لم يُرصد":"منذ "+((System.currentTimeMillis()-lastWhatsAppEvent)/1000)+" ثانية")+"\nمجموع الأحداث: "+eventCount+"\nالحزمة: "+(activePackage.isEmpty()?"لم تُحدد":activePackage)+"\nانتقال الشاشة للرابط الحالي: "+(observedNewScreen?"رُصد":"لم يُرصد");}
  private static String fingerprint(List<String> words){StringBuilder b=new StringBuilder();for(String w:words)b.append(w).append('\u001f');return b.toString();}
  private long gap(){return config==null?1000L:config.gapSeconds()*1000L;}
  private long previewTimeout(){return config==null?3000L:config.timeoutSeconds()*1000L;}
  private static final long[] BACKOFF={120000,300000,900000,1800000,3600000};
  // Rebinding after WhatsApp is opened is a service lifecycle event, not a user pause.
  // Resume only a previously running task; an explicit PAUSED state is never restarted.
  @Override public void onServiceConnected(){
    super.onServiceConnected();
    current=this;
    navigationPending=false;
    store=new ScanStore(this);
    config=new ScannerConfig(this);
    DiagnosticsLog.add(this,"ACCESSIBILITY","الخدمة متصلة؛ الحالة المحفوظة: "+store.state()+"؛ المعلق: "+store.pendingCount());
    String previous=store.state();
    if(("RUNNING".equals(previous)||"RECOVERING".equals(previous))&&store.pendingCount()>0){
      store.state("RECOVERING","إعادة اتصال الخدمة؛ استكمال قائمة الانتظار تلقائيًا");
      h.postDelayed(()->{
        if(current!=this || running || store==null || !"RECOVERING".equals(store.state()))return;
        DiagnosticsLog.add(this,"RECOVERY","إعادة تشغيل الرابط الجاري بعد عودة Accessibility");
        begin();
      },850);
    }
  }
  @Override public void onDestroy(){
    boolean owner=current==this;
    boolean interrupted=running;
    running=false;paused=true;h.removeCallbacksAndMessages(null);
    if(owner){
      if(interrupted && store!=null && "RUNNING".equals(store.state()))
        store.state("RECOVERING","انفصلت خدمة Accessibility أثناء المعاينة؛ ستستأنف عند اتصالها");
      current=null;
    }
    DiagnosticsLog.add(this,"ACCESSIBILITY","الخدمة انفصلت؛ "+(interrupted?"تم حفظ مهمة الاستكمال":"لا يوجد فحص نشط"));
    super.onDestroy();
  }
  public void begin(){
    if(store==null)store=new ScanStore(this);
    if(config==null)config=new ScannerConfig(this);
    if(running)return;
    int pending=store.pendingCount();
    if(pending==0){
      String message=store.size()==0?"قائمة الروابط فارغة؛ افتح تبويب الروابط وأضف رابطًا قبل بدء الفحص":"لا توجد روابط معلقة؛ أضف روابط جديدة أو اختر إعادة غير المحسوم";
      DiagnosticsLog.add(this,"QUEUE",message);
      store.state("DONE",message);
      return;
    }
    String pkg=availableWhatsAppPackage();
    if(pkg.isEmpty()){
      DiagnosticsLog.add(this,"CONNECT","لم يتم تحديد واتساب أو أن التطبيق المحدد غير مثبت");
      store.state("PAUSED","تعذر العثور على واتساب الرسمي؛ افتح أدوات الفحص ← اختبار اتصال مباشر");
      return;
    }
    DiagnosticsLog.add(this,"CONNECT","تطبيق واتساب متاح: "+pkg+"؛ لم يتم التحقق بعد من ظهور معاينة الدعوة");
    running=true;paused=false;store.state("RUNNING","بدأ الفحص؛ روابط معلقة: "+pending);next();
  }
  public void stop(){running=false;paused=true;navigationPending=false;h.removeCallbacksAndMessages(null);if(store!=null)store.state("PAUSED","تم الإيقاف؛ النتائج محفوظة");}
  public void clear(){running=false;paused=true;navigationPending=false;h.removeCallbacksAndMessages(null);if(store!=null)store.clear();}
  private void next(){
    if(!running || navigationPending)return;
    idx=store.next();attempt=0;candidate="";stable=0;
    if(idx<0){running=false;store.state("DONE","لا توجد روابط معلقة؛ يمكنك إضافة روابط أو إعادة غير المحسوم");return;}
    long wait=store.cooldownUntil()-System.currentTimeMillis();if(wait>0){store.state("COOLDOWN","وقت الانتظار المتبقي: "+(wait/1000)+" ثانية");h.postDelayed(this::next,Math.max(1000,wait));return;}
    open();
  }
  private void open(){
    if(!running||idx<0)return;
    JSONObjectSafe old=new JSONObjectSafe(store.at(idx));
    attempt=old.attempts()+1;
    final long serial=++launchSerial;
    h.removeCallbacks(settle);candidate="";stable=0;confirmedCountType="UNKNOWN";confirmedJoinType="UNKNOWN";observationNote="";observedNewScreen=false;preLaunchFingerprint="";launchedAt=System.currentTimeMillis();lastRead=0;
    AccessibilityNodeInfo before=getRootInActiveWindow();if(before!=null){List<String> oldWords=new ArrayList<>();walk(before,oldWords,0);preLaunchFingerprint=fingerprint(oldWords);before.recycle();}
    store.update(idx,"RETRY",old.name(),old.members(),"جار فتح معاينة الرابط — المحاولة "+attempt,true);
    store.state("RUNNING","جار فحص "+(idx+1)+" / "+store.size());DiagnosticsLog.add(this,"OPEN","فتح الرابط "+(idx+1)+" من "+store.size()+"؛ المحاولة "+attempt+"؛ مهلة "+(previewTimeout()/1000)+" ثوانٍ");
    try{
      activePackage=availableWhatsAppPackage();
      if(activePackage.isEmpty()){DiagnosticsLog.add(this,"ERROR","لم يُعثر على واتساب الرسمي أو Business");finish("UNRESOLVED","","","لا يوجد تطبيق WhatsApp رسمي أو Business مثبت");return;}
      Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(old.url()));i.setPackage(activePackage);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
      if(i.resolveActivity(getPackageManager())==null){finish("UNRESOLVED","","","تطبيق واتساب مثبت لكنه لا يستقبل هذا النوع من الروابط مباشرة");return;}
      startActivity(i);
    }catch(Exception ex){
      DiagnosticsLog.add(this,"ERROR","فشل فتح رابط: "+ex.getClass().getSimpleName());
      // Do not fall back to an arbitrary browser: this scanner reads WhatsApp's view only.
      finish("UNRESOLVED","","","تعذر فتح الرابط في تطبيق WhatsApp الرسمي: "+ex.getClass().getSimpleName());return;
    }
    final int expected=idx,number=attempt;
    // Timed samples handle previews that emit very few accessibility events.
    h.postDelayed(()->{if(running&&!navigationPending&&idx==expected&&attempt==number&&launchSerial==serial)captureCurrentPreview();},700);
    h.postDelayed(()->{if(running&&!navigationPending&&idx==expected&&attempt==number&&launchSerial==serial)captureCurrentPreview();},1550);
    h.postDelayed(()->{if(running&&!navigationPending&&idx==expected&&attempt==number&&launchSerial==serial)timeout();},previewTimeout());
  }
  public boolean isScanning(){return running;}
  public String detectedWhatsAppPackage(){return availableWhatsAppPackage();}
  public boolean observedWhatsAppEvents(){return lastWhatsAppEvent>0;}
  private String availableWhatsAppPackage(){
    String pkg=getSharedPreferences("wa_target",MODE_PRIVATE).getString("package","");
    if(!"com.whatsapp".equals(pkg)&&!"com.whatsapp.w4b".equals(pkg))return "";
    try{getPackageManager().getPackageInfo(pkg,0);return pkg;}
    catch(PackageManager.NameNotFoundException ignored){return "";}
  }
  @Override public void onAccessibilityEvent(AccessibilityEvent e){
    if(e.getPackageName()==null)return;
    String pkg=e.getPackageName().toString();
    if(!"com.whatsapp".equals(pkg)&&!"com.whatsapp.w4b".equals(pkg))return;
    if(running && !pkg.equals(availableWhatsAppPackage()))return;
    lastWhatsAppEvent=System.currentTimeMillis();
    eventCount++;
    if(probeStartAt>0 && lastWhatsAppEvent-probeStartAt<=15000){
      probeEvents++;
      probePackage=pkg;
      AccessibilityNodeInfo probeRoot=getRootInActiveWindow();
      if(probeRoot!=null){
        // Count visible accessibility labels without retaining their contents.
        List<String> labels=new ArrayList<>();walk(probeRoot,labels,0);
        probeReadableNodes=Math.max(probeReadableNodes,labels.size());
        probeRoot.recycle();
      }
    }
    if(!running||navigationPending||idx<0||!pkg.equals(activePackage))return;
    captureCurrentPreview();
  }
  private void captureCurrentPreview(){
    if(!running||navigationPending||idx<0||activePackage.isEmpty())return;
    long now=System.currentTimeMillis();if(now-launchedAt<900||now-lastRead<260)return;
    lastRead=now;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    if(root.getPackageName()==null || !activePackage.equals(root.getPackageName().toString())){root.recycle();return;}
    List<String> words=new ArrayList<>();walk(root,words,0);root.recycle();
    String currentFingerprint=fingerprint(words);
    if(!observedNewScreen){
      if(words.isEmpty()||currentFingerprint.equals(preLaunchFingerprint))return;
      observedNewScreen=true;candidate="";stable=0;
    }
    PreviewParser.Result r=PreviewParser.parse(words);
    if(r.rateLimited){onLimit();return;}
    if("UNRESOLVED".equals(r.status))return;
    String signature=r.status+"|"+r.name+"|"+r.members+"|"+r.joinType;
    if(!signature.equals(candidate)){
      candidate=signature;stable=1;confirmedCountType=r.countType;confirmedJoinType=r.joinType;observationNote=r.note;
      h.removeCallbacks(settle);h.postDelayed(settle,550);return;
    }
    stable++;
    if(stable>=2)finish(r.status,r.name,r.members,r.countType,r.joinType,r.note);
  }
  private void verifyStableSnapshot(){
    if(!running||navigationPending||idx<0||!observedNewScreen||candidate.isEmpty())return;
    if(System.currentTimeMillis()-launchedAt>previewTimeout())return;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    if(root.getPackageName()==null||!activePackage.equals(root.getPackageName().toString())){root.recycle();return;}
    List<String> words=new ArrayList<>();walk(root,words,0);root.recycle();
    PreviewParser.Result r=PreviewParser.parse(words);
    if(r.rateLimited){onLimit();return;}
    String signature=r.status+"|"+r.name+"|"+r.members+"|"+r.joinType;
    if(signature.equals(candidate)&&!"UNRESOLVED".equals(r.status)){
      stable++;if(stable>=2)finish(r.status,r.name,r.members,r.countType,r.joinType,r.note);
    }else{candidate="";stable=0;}
  }
  private void walk(AccessibilityNodeInfo node,List<String> out,int depth){
    if(node==null||depth>25||out.size()>160)return;
    CharSequence txt=node.getText();CharSequence desc=node.getContentDescription();
    if(txt!=null&&!txt.toString().trim().isEmpty())out.add(txt.toString().trim());
    if(desc!=null&&!desc.toString().trim().isEmpty() && (txt==null||!desc.toString().equals(txt.toString())))out.add(desc.toString().trim());
    for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo c=node.getChild(i);if(c!=null){walk(c,out,depth+1);c.recycle();}}
  }
private void timeout(){
  if(!running||idx<0||navigationPending)return;
  DiagnosticsLog.add(this,"PREVIEW","انتهت المهلة؛ معاينة جديدة: "+observedNewScreen+"؛ التطبيق: "+activePackage);
  if(!observedNewScreen){
    missingPreviewStreak++;
    // Repeating a broken WhatsApp hand-off 192 times is not a successful scan.
    if(missingPreviewStreak>=3){
      store.updateDetail(idx,"UNRESOLVED","","","UNKNOWN","UNKNOWN","تعذّر تأكيد فتح المعاينة بعد ثلاث روابط متتالية؛ تحقق من أذونات واتساب واختبار الاتصال");
      running=false;paused=true;h.removeCallbacksAndMessages(null);
      store.state("PAUSED","ثلاث معاينات متتالية لم تظهر؛ أوقف الفحص للتحقق من الاتصال، والروابط المتبقية محفوظة");
      DiagnosticsLog.add(this,"CONNECT","إيقاف حماية: لم تظهر المعاينة ثلاث مرات متتالية؛ لن نستهلك بقية الروابط");
      return;
    }
  } else missingPreviewStreak=0;
  if(attempt<(config==null?2:config.retries())){
    store.update(idx,"RETRY","","","تأجيل المحاولة إلى نهاية قائمة الانتظار؛ لم تظهر معاينة مؤكدة",false);
    DiagnosticsLog.add(this,"FLOW","تأجيل الرابط غير المحسوم؛ الانتقال للرابط التالي");
    advanceAfterPreview();
  }else finish("UNRESOLVED","","","لم تتوفر معلومات مؤكدة بعد المحاولات؛ لا يُصنّف رابطًا غير صالح");
}
private static boolean dismissLabel(String text){
  if(text==null)return false;
  String t=text.trim().toLowerCase(java.util.Locale.ROOT);
  return "×".equals(t)||"✕".equals(t)||"✖".equals(t)||"close".equals(t)
    ||"dismiss".equals(t)||"cancel".equals(t)||"إغلاق".equals(t)||"اغلاق".equals(t)||"إلغاء".equals(t);
}
// Search ONLY a verified WhatsApp invitation preview; never click Join / Request / Follow.
private boolean tapClose(AccessibilityNodeInfo node,int depth){
  if(node==null||depth>18)return false;
  String text=node.getText()==null?"":node.getText().toString();
  String desc=node.getContentDescription()==null?"":node.getContentDescription().toString();
  if(dismissLabel(text)||dismissLabel(desc)){
    AccessibilityNodeInfo target=node;
    for(int i=0;i<2&&target!=null;i++){
      if(target.isClickable() && target.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
      target=target.getParent();
    }
  }
  for(int i=0;i<node.getChildCount();i++){
    AccessibilityNodeInfo child=node.getChild(i);
    if(child!=null){boolean clicked=tapClose(child,depth+1);child.recycle();if(clicked)return true;}
  }
  return false;
}
private boolean isWhatsAppInvitationVisible(AccessibilityNodeInfo root){
  if(root==null||root.getPackageName()==null||!activePackage.equals(root.getPackageName().toString()))return false;
  List<String> labels=new ArrayList<>();walk(root,labels,0);
  PreviewParser.Result r=PreviewParser.parse(labels);
  if(r.rateLimited)return false;
  if(!"UNRESOLVED".equals(r.status))return true;
  for(String item:labels){
    String x=item.trim().toLowerCase(java.util.Locale.ROOT);
    if(x.equals("join group")||x.equals("request to join")||x.equals("join community")
        ||x.equals("follow channel")||x.equals("انضم إلى المجموعة")||x.equals("طلب الانضمام")
        ||x.equals("الانضمام إلى المجتمع")||x.equals("متابعة القناة"))return true;
  }
  return false;
}
private void advanceAfterPreview(){
  if(!running)return;
  navigationPending=true;
  h.removeCallbacksAndMessages(null); // Cancel stale timed samples from the preceding invitation.
  boolean closed=false;
  // Only dismiss when we observed a real new WhatsApp screen AND its current tree still
  // has invitation evidence; otherwise a global Back might exit an unrelated screen.
  AccessibilityNodeInfo root=getRootInActiveWindow();
  if(observedNewScreen && isWhatsAppInvitationVisible(root)){
    closed=tapClose(root,0);
    if(closed)DiagnosticsLog.add(this,"NAV","إغلاق معاينة الدعوة بزر X/إلغاء");
    else{
      closed=performGlobalAction(GLOBAL_ACTION_BACK);
      DiagnosticsLog.add(this,"NAV",closed?"إغلاق معاينة الدعوة بزر Back":"تعذر الضغط على Back؛ المتابعة دون تفاعل إضافي");
    }
  } else DiagnosticsLog.add(this,"NAV","لم يُؤكد وجود معاينة؛ تجنب الضغط على Back خارج المعاينة");
  if(root!=null)root.recycle();
  idx=-1;candidate="";stable=0;observedNewScreen=false;
  // One-second spacing is between launches once the previous preview is handled.
  long delay=Math.max(450L,gap());
  h.postDelayed(()->{navigationPending=false;if(running)next();},delay);
}
  private void onLimit(){
    if(!running)return;DiagnosticsLog.add(this,"LIMIT","رُصد تقييد واتساب؛ إيقاف الطلبات مؤقتًا");
    running=false;paused=true;h.removeCallbacksAndMessages(null);
    int step=Math.min(store.cooldownStep(),BACKOFF.length-1);long delay=BACKOFF[step];long until=System.currentTimeMillis()+delay;
    store.cooldown(Math.min(step+1,BACKOFF.length-1),until);
    store.state("COOLDOWN","رصد تقييد؛ الانتظار "+(delay/60000)+" دقيقة قبل استئناف الفحص. أبقِ الشاشة مفتوحة عند الاستئناف");
    if(config!=null&&!config.autoResume())return;
    running=true;paused=false;h.postDelayed(()->{if(running){store.state("RUNNING","انتهى الانتظار؛ إعادة فتح الرابط الحالي");next();}},delay);
  }
  private void finish(String status,String name,String members,String note){finish(status,name,members,"UNKNOWN","UNKNOWN",note);}
  private void finish(String status,String name,String members,String countType,String joinType,String note){
    if(!running)return;
    // One input -> one result; persist before launching another invitation.
    h.removeCallbacks(settle);
    store.updateDetail(idx,status,name,members,countType,joinType,note);
    store.cooldown(0,0);
    if(!"UNRESOLVED".equals(status) || observedNewScreen)missingPreviewStreak=0;
    DiagnosticsLog.add(this,"FLOW","حُفظت النتيجة؛ إغلاق المعاينة ثم الانتقال للرابط التالي");
    advanceAfterPreview();
  }
  @Override public void onInterrupt(){
    if(running){
      running=false;paused=true;h.removeCallbacksAndMessages(null);
      if(store!=null)store.state("RECOVERING","أوقف النظام Accessibility مؤقتًا؛ الاستئناف عند عودة الخدمة");
      DiagnosticsLog.add(this,"RECOVERY","انقطاع الخدمة أثناء فتح رابط؛ النتائج السابقة محفوظة");
    }
  }
  private static final class JSONObjectSafe{
    final org.json.JSONObject o;JSONObjectSafe(org.json.JSONObject x){o=x==null?new org.json.JSONObject():x;}
    String url(){return o.optString("url");}String name(){return o.optString("name");}
    String members(){return o.optString("members");}int attempts(){return o.optInt("attempts");}
  }
}
