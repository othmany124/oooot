package com.waultimate.scanner;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Professional RTL XLSX export matching the scanner's final classification model. */
public final class ExcelExporter {
  private static final String[] NAMES={"الملخص","جميع النتائج","القروبات","المجتمعات","القنوات","غير شغالة"};
  private ExcelExporter(){}
  private static String esc(String s){if(s==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='&')b.append("&amp;");else if(c=='<')b.append("&lt;");else if(c=='>')b.append("&gt;");else if(c=='\"')b.append("&quot;");else if(c=='\'')b.append("&apos;");else if(c>=32||c=='\n'||c=='\t'||c=='\r')b.append(c);}return b.toString();}
  private static String col(int n){String s="";while(n>0){n--;s=(char)('A'+n%26)+s;n/=26;}return s;}
  private static void textCell(StringBuilder out,int x,int y,String value,int style){out.append("<c r=\"").append(col(x)).append(y).append("\" s=\"").append(style).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(value)).append("</t></is></c>");}
  private static void numberCell(StringBuilder out,int x,int y,long value,int style){out.append("<c r=\"").append(col(x)).append(y).append("\" s=\"").append(style).append("\"><v>").append(value).append("</v></c>");}
  private static void row(StringBuilder out,int y,String[] strings,boolean header){out.append("<row r=\"").append(y).append("\" ht=\"").append(header?28:24).append("\" customHeight=\"1\">");for(int i=0;i<strings.length;i++)textCell(out,i+1,y,strings[i],header?1:(y%2==0?2:3));out.append("</row>");}
  private static String time(long epoch){return epoch==0?"":new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(epoch));}
  private static String statusAr(String s){if("DIRECT".equals(s)||"APPROVAL".equals(s))return "قروب";if("COMMUNITY".equals(s))return "مجتمع";if("CHANNEL".equals(s))return "قناة";if("INVALID".equals(s))return "غير شغال";if("RETRY".equals(s))return "إعادة فحص";if("PENDING".equals(s))return "قيد الانتظار";return s;}
  private static String joinAr(String s){if("APPROVAL".equals(s))return "موافقة";if("DIRECT".equals(s))return "بدون موافقة";if("FOLLOW".equals(s))return "متابعة";if("COMMUNITY".equals(s))return "مجتمع";if("INVALID".equals(s))return "غير شغال";return "";}
  private static String accuracy(JSONObject o){int a=o.optInt("accuracy",0);if(a<=0)return "";String q=a>=90?"عالية":a>=70?"متوسطة":"منخفضة";return a+"% - "+q;}
  private static String scanDate(JSONObject o){return time(o.optLong("scannedAt",0L));}
  private static String creation(JSONObject o){String d=o.optString("creationDate");return d.isEmpty()?"غير ظاهر":d;}
  private static String countFor(JSONObject o,String expected){return expected.equals(o.optString("countType"))?o.optString("members"):"";}
  private static long numericCount(JSONObject o,String expected){
    if(!expected.equals(o.optString("countType")))return -1L;String v=o.optString("members","");if(v.isEmpty())return -1L;
    try{return Long.parseLong(v.replaceAll("[^0-9]",""));}catch(Exception e){return -1L;}
  }

  private static boolean isGroup(JSONObject o){String s=o.optString("status");return "DIRECT".equals(s)||"APPROVAL".equals(s);}
  private static String[] allRecord(JSONObject o,int ix){return new String[]{Integer.toString(ix),o.optString("url"),o.optString("name"),statusAr(o.optString("status")),joinAr(o.optString("joinType")),o.optString("members"),o.optString("countType"),creation(o),scanDate(o),accuracy(o),Integer.toString(o.optInt("attempts")),o.optString("note")};}
  private static String[] groupRecord(JSONObject o,int ix){return new String[]{Integer.toString(ix),o.optString("url"),o.optString("name"),joinAr(o.optString("joinType")),countFor(o,"MEMBERS"),creation(o),scanDate(o),accuracy(o)};}
  private static String[] communityRecord(JSONObject o,int ix){return new String[]{Integer.toString(ix),o.optString("url"),o.optString("name"),countFor(o,"SUBGROUPS"),creation(o),scanDate(o),accuracy(o)};}
  private static String[] channelRecord(JSONObject o,int ix){return new String[]{Integer.toString(ix),o.optString("url"),countFor(o,"FOLLOWERS")};}
  private static String[] invalidRecord(JSONObject o,int ix){return new String[]{Integer.toString(ix),o.optString("url"),o.optString("note"),scanDate(o),accuracy(o),Integer.toString(o.optInt("attempts"))};}

  private static void cols(StringBuilder s,int widths[]){s.append("<cols>");for(int i=0;i<widths.length;i++)s.append("<col min=\"").append(i+1).append("\" max=\"").append(i+1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");s.append("</cols>");}
  private static String worksheet(JSONArray input,int which){
    StringBuilder s=new StringBuilder(5000+input.length()*600);s.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
    if(which==0){
      cols(s,new int[]{34,18});s.append("<sheetData>");row(s,1,new String[]{"التصنيف","عدد الروابط"},true);
      String[][] cats={{"القروبات","GROUP"},{"المجتمعات","COMMUNITY"},{"القنوات","CHANNEL"},{"غير شغالة","INVALID"},{"قيد الانتظار/الإعادة","PENDING"}};
      for(int k=0;k<cats.length;k++){int n=0;for(int i=0;i<input.length();i++){JSONObject o=input.optJSONObject(i);if(o==null)continue;String st=o.optString("status");boolean ok="GROUP".equals(cats[k][1])?isGroup(o):"PENDING".equals(cats[k][1])?("PENDING".equals(st)||"RETRY".equals(st)||"UNRESOLVED".equals(st)):cats[k][1].equals(st);if(ok)n++;}s.append("<row r=\"").append(k+2).append("\">");textCell(s,1,k+2,cats[k][0],k%2==0?2:3);numberCell(s,2,k+2,n,4);s.append("</row>");}
      s.append("<row r=\"8\">");textCell(s,1,8,"إجمالي الروابط الفريدة",1);numberCell(s,2,8,input.length(),4);s.append("</row></sheetData><autoFilter ref=\"A1:B6\"/>");
    }else{
      String[] head;int[] widths;
      if(which==1){head=new String[]{"#","الرابط","الاسم","النوع","نوع القروب/الانضمام","العدد","نوع العدد","تاريخ الإنشاء","تاريخ الفحص","دقة الفحص","المحاولات","السبب / الملاحظات"};widths=new int[]{7,58,34,18,22,15,16,22,23,18,12,65};}
      else if(which==2){head=new String[]{"#","الرابط","الاسم","نوع القروب","عدد الأعضاء","تاريخ الإنشاء","تاريخ الفحص","دقة الفحص"};widths=new int[]{7,58,36,20,16,22,23,18};}
      else if(which==3){head=new String[]{"#","رابط المجتمع","اسم المجتمع","عدد القروبات في المجتمع","تاريخ الإنشاء","تاريخ الفحص","دقة الفحص"};widths=new int[]{7,58,36,24,22,23,18};}
      else if(which==4){head=new String[]{"#","رابط القناة","عدد المتابعين"};widths=new int[]{7,58,20};}
      else {head=new String[]{"#","الرابط","سبب عدم العمل","تاريخ الفحص","دقة الفحص","المحاولات"};widths=new int[]{7,58,65,23,18,12};}
      cols(s,widths);s.append("<sheetData>");row(s,1,head,true);int n=2;
      List<JSONObject> rows=new ArrayList<>();
      for(int i=0;i<input.length();i++){JSONObject o=input.optJSONObject(i);if(o==null)continue;boolean include=which==1||(which==2&&isGroup(o))||(which==3&&"COMMUNITY".equals(o.optString("status")))||(which==4&&"CHANNEL".equals(o.optString("status")))||(which==5&&"INVALID".equals(o.optString("status")));if(include)rows.add(o);}
      if(which==2)Collections.sort(rows,new Comparator<JSONObject>(){public int compare(JSONObject a,JSONObject b){return Long.compare(numericCount(b,"MEMBERS"),numericCount(a,"MEMBERS"));}});
      int seq=1;for(JSONObject o:rows){String[] rec=which==1?allRecord(o,seq):which==2?groupRecord(o,seq):which==3?communityRecord(o,seq):which==4?channelRecord(o,seq):invalidRecord(o,seq);row(s,n++,rec,false);seq++;}

      s.append("</sheetData><autoFilter ref=\"A1:").append(col(head.length)).append(Math.max(1,n-1)).append("\"/>");
    }
    s.append("</worksheet>");return s.toString();
  }
  private static String workbook(){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>");for(int i=0;i<NAMES.length;i++)s.append("<sheet name=\"").append(esc(NAMES[i])).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");return s.append("</sheets></workbook>").toString();}
  private static String rels(){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");for(int i=0;i<NAMES.length;i++)s.append("<Relationship Id=\"rId").append(i+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i+1).append(".xml\"/>");return s.append("<Relationship Id=\"rId").append(NAMES.length+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>").toString();}
  private static final String STYLES="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Arial\"/></font></fonts><fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF075E45\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE9F5F0\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"5\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/></cellXfs></styleSheet>";
  private static void add(ZipOutputStream z,String name,String body)throws IOException{z.putNextEntry(new ZipEntry(name));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
  public static void write(OutputStream destination,JSONArray input)throws IOException{ZipOutputStream z=new ZipOutputStream(destination);add(z,"[Content_Types].xml",types());add(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");add(z,"xl/workbook.xml",workbook());add(z,"xl/_rels/workbook.xml.rels",rels());add(z,"xl/styles.xml",STYLES);for(int i=0;i<NAMES.length;i++)add(z,"xl/worksheets/sheet"+(i+1)+".xml",worksheet(input,i));z.finish();z.flush();}
  private static String types(){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");for(int i=1;i<=NAMES.length;i++)s.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");return s.append("</Types>").toString();}
}
