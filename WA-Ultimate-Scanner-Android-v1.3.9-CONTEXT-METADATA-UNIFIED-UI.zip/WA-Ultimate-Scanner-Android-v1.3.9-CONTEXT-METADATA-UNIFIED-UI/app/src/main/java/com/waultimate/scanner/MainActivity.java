package com.waultimate.scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.PackageManager;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** RTL native UI: dashboard, input, live progress, categorized result cards and tools. */
public final class MainActivity extends Activity {
  private static final int PICK=101, SAVE=102, SAVE_XLSX=103;
  private static final int DARK=0xff082e2c, GREEN=0xff078153, BG=0xfff3f7f6, INK=0xff173a34, MUTED=0xff617a75;
  private static final int[] COLORS={0xff08884f,0xff2867d4,0xff823be1,0xff0099b4,0xffe13a39,0xffd99000};
  private static final String[] TYPES={"الكل","قروبات بدون موافقة","قروبات بموافقة","المجتمعات","القنوات","غير شغال","قيد إعادة الفحص"};
  private static final String[] CODES={"","DIRECT","APPROVAL","COMMUNITY","CHANNEL","INVALID","UNRESOLVED"};
  private ScanStore store;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private LinearLayout content,nav; private TextView heroStatus,heroProgress,engineStage,engineDetail; private ProgressBar progress;
  private EditText input,search; private String query="";private int tab=0,filter=0; private boolean active=false; private final Set<String> selected=new LinkedHashSet<>();
  private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
  private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
  private TextView txt(String value,int size,int color,boolean strong){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);if(strong)t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
  private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private void pad(View v,int x,int y){v.setPadding(dp(x),dp(y),dp(x),dp(y));}
  private LinearLayout card(LinearLayout parent){LinearLayout c=vertical();c.setBackground(bg(Color.WHITE,22));pad(c,15,15);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);parent.addView(c,p);return c;}
  private void small(LinearLayout parent,String text){TextView t=txt(text,12,MUTED,false);t.setPadding(0,dp(4),0,dp(4));parent.addView(t);}
  private Button button(LinearLayout host,String text,int color,boolean outline,Runnable click){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(outline?color:Color.WHITE);GradientDrawable d=bg(outline?Color.WHITE:color,12);if(outline)d.setStroke(dp(1),color);b.setBackground(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(51),1);p.setMargins(dp(3),dp(4),dp(3),dp(4));host.addView(b,p);b.setOnClickListener(v->click.run());return b;}
  private void title(LinearLayout parent,String s){TextView t=txt(s,17,INK,true);t.setPadding(0,0,0,dp(12));parent.addView(t);}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onCreate(Bundle bundle){super.onCreate(bundle);getWindow().setStatusBarColor(DARK);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);store=new ScanStore(this);show(0);}
  private void show(int next){
    if(input!=null) saveDraft(input.getText().toString());
    input=null;engineStage=null;engineDetail=null;resultHost=null;tab=0;
    LinearLayout page=vertical();page.setBackgroundColor(BG);
    LinearLayout bar=horizontal();bar.setBackgroundColor(DARK);pad(bar,15,13);
    TextView brand=txt("WA ULTIMATE SCANNER PRO  •  v1.3.9",20,Color.WHITE,true);bar.addView(brand,new LinearLayout.LayoutParams(0,dp(51),1));
    TextView cog=txt("⚙",28,Color.WHITE,true);pad(cog,12,5);bar.addView(cog);cog.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));page.addView(bar);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=vertical();pad(content,12,13);scroll.addView(content);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    dashboard();imports();progressPage();results();tools();
    setContentView(page);
  }
  private int[] counts(JSONArray a){int[] c=new int[7];for(int i=0;i<a.length();i++){String s=a.optJSONObject(i).optString("status");for(int j=1;j<CODES.length;j++)if(CODES[j].equals(s)){c[j]++;c[0]++;break;}}return c;}
  private void summary(LinearLayout target){JSONArray data=store.all();int completed=counts(data)[0];LinearLayout c=card(target);LinearLayout row=horizontal();heroStatus=txt("حالة الفحص: "+state(),14,GREEN,true);row.addView(heroStatus,new LinearLayout.LayoutParams(0,-2,1));heroProgress=txt("مكتمل "+completed+" من "+data.length(),15,INK,true);row.addView(heroProgress);c.addView(row);progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgress(data.length()==0?0:completed*100/data.length());progress.setProgressTintList(ColorStateList.valueOf(GREEN));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(8));pp.topMargin=dp(14);pp.bottomMargin=dp(5);c.addView(progress,pp);small(c,store.message().isEmpty()?"يتم حفظ كل نتيجة بعد اكتمال الفحص":store.message());}
  private String state(){switch(store.state()){case "RUNNING":return "جار الفحص";case "PAUSED":return "متوقف";case "COOLDOWN":return "فترة تهدئة";case "RECOVERING":return "استعادة الجلسة";case "DONE":return "مكتمل";default:return "جاهز";}}
  private void metrics(LinearLayout target){JSONArray all=store.all();int[] c=counts(all);String[] labels={"قروبات بدون موافقة","قروبات بموافقة","المجتمعات","القنوات","غير شغال","قيد إعادة الفحص"};for(int r=0;r<3;r++){LinearLayout row=horizontal();target.addView(row);for(int col=0;col<2;col++){int ix=r*2+col;LinearLayout tile=vertical();tile.setBackground(bg(COLORS[ix],15));pad(tile,13,13);tile.addView(txt(""+c[ix+1],27,Color.WHITE,true));tile.addView(txt(labels[ix],13,Color.WHITE,true));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(97),1);p.setMargins(dp(3),dp(4),dp(3),dp(5));row.addView(tile,p);final int f=ix+1;tile.setOnClickListener(v->{filter=f;renderResults();});}}}
  private void dashboard(){LinearLayout hero=card(content);hero.setBackground(bg(DARK,22));
    TextView version=txt("SCANNER PRO  /  CONTEXT METADATA ENGINE 1.3.9",11,0xffa6ecce,true);
    hero.addView(version);hero.addView(txt("فحص روابط واتساب بدقة",21,Color.WHITE,true));
    TextView subtitle=txt("فتح → تحقق → حفظ → إغلاق X / Back → التالي",13,0xffc7f2df,false);
    hero.addView(subtitle);summary(content);metrics(content);LinearLayout a=card(content);title(a,"التحكم السريع");LinearLayout row=horizontal();a.addView(row);button(row,"▶ بدء / استئناف",GREEN,false,this::start);button(row,"■ إيقاف فوري",0xffda3d40,false,this::stop);small(a,"النتيجة تُحفظ قبل الانتقال؛ لا يُضغط Join أو Request أو Follow.");
    LinearLayout engine=card(content);title(engine,"محرك التنقل والتحقق");
    ScannerAccessibility engineService=ScannerAccessibility.current;
    engineStage=txt("المرحلة: "+(engineService==null?"خدمة الفحص غير متصلة":engineService.phaseLabel()),16,GREEN,true);
    engine.addView(engineStage);
    engineDetail=txt(engineService==null?"فعّل Accessibility لبدء فحص رابط تجريبي":engineService.lastNavigation(),13,MUTED,false);
    engineDetail.setPadding(0,dp(7),0,dp(7));engine.addView(engineDetail);
    small(engine,"الجديد والمعلق: "+store.pendingCount()+" • الرابط النشط: "+(engineService==null?"—":engineService.activeLinkNumber()));
    LinearLayout navActions=horizontal();engine.addView(navActions);
    button(navActions,"تشخيص الحركة",0xff236c85,true,()->{
      ScannerAccessibility service=ScannerAccessibility.current;
      new AlertDialog.Builder(this).setTitle("تشخيص التنقل")
        .setMessage(service==null?"خدمة Accessibility غير متصلة":service.diagnostics())
        .setPositiveButton("حسنًا",null).show();
    });
    button(navActions,"إضافة روابط",GREEN,false,()->show(1));
    small(engine,"إذا لم تثبت المعاينة، يُؤجل الرابط. عند تعطل الاتصال المتكرر يتوقف المحرك بأمان.");
    LinearLayout connection=card(content);title(connection,"ربط واتساب الرسمي");
    boolean enabled=serviceEnabled();
    ScannerAccessibility svc=ScannerAccessibility.current;
    String installedPkg=installed("com.whatsapp")?"WhatsApp":"غير موجود";
    String businessPkg=installed("com.whatsapp.w4b")?"WhatsApp Business":"غير موجود";
    small(connection,"Accessibility: "+(enabled&&svc!=null?"متصلة":"غير متصلة")+" | واتساب: "+installedPkg+" | الأعمال: "+businessPkg);
    small(connection,"استقبال أحداث واتساب: "+(svc!=null&&svc.observedWhatsAppEvents()?"تم رصد أحداث؛ يلزم اختبار رابط":"لم يتم التحقق بعد"));
    small(connection,"الحساب المحدد: "+targetLabel(selectedWhatsApp())+" — اختيار التطبيق لا يثبت نجاح قراءة المعاينة");
    small(connection,"روابط معلقة: "+store.pendingCount()+" من "+store.size());
    LinearLayout connectionActions=horizontal();connection.addView(connectionActions);
    button(connectionActions,"تحديد واتساب",0xff2477a5,false,()->chooseWhatsApp(false));
    button(connectionActions,"اختبار الربط",GREEN,false,this::testConnection);
    button(connectionActions,"تشخيص مفصل",DARK,false,this::diagnose);
    LinearLayout importActions=horizontal();connection.addView(importActions);
    button(importActions,"إضافة روابط الفحص",0xff2777a3,false,()->show(1));
  }
  private void imports(){LinearLayout c=card(content);title(c,"إضافة روابط الفحص");small(c,"ألصق روابط المجموعات أو القنوات؛ كل رابط في سطر مستقل.");input=new EditText(this);input.setHint("https://chat.whatsapp.com/...\nhttps://whatsapp.com/channel/...");input.setText(loadDraft());input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence v,int st,int c,int a){}public void onTextChanged(CharSequence v,int st,int b,int c){saveDraft(v.toString());}public void afterTextChanged(android.text.Editable e){}});input.setGravity(Gravity.TOP);input.setMinLines(8);input.setTextSize(14);input.setTextColor(INK);input.setBackground(bg(0xffeaf0f0,12));pad(input,12,12);c.addView(input,new LinearLayout.LayoutParams(-1,dp(210)));LinearLayout row=horizontal();c.addView(row);button(row,"حفظ الروابط",GREEN,false,()->{try{String draft=input.getText().toString();if(!ScanStore.containsLinks(draft)){toast("لم يُعثر على روابط واتساب في النص");DiagnosticsLog.add(this,"IMPORT","النص المدخل لا يحتوي على روابط واتساب معروفة");return;}int n=store.add(draft);input.setText("");saveDraft("");toast(n>0?"أضيف "+n+" رابط؛ جاهز للفحص":"كل الروابط موجودة مسبقًا؛ لم يُضف شيء");DiagnosticsLog.add(this,"QUEUE","الروابط المعلقة بعد الحفظ: "+store.pendingCount());show(1);}catch(Exception e){DiagnosticsLog.add(this,"ERROR","فشل حفظ مربع الروابط: "+e.getClass().getSimpleName());toast("تعذر حفظ الروابط");}});button(row,"استيراد TXT/CSV/XLSX",0xff2777a3,false,()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);});LinearLayout options=card(content);title(options,"خيارات الإدخال");small(options,"✓ حذف الروابط المكررة تلقائيًا");small(options,"✓ إدراج الروابط الجديدة دون حذف النتائج السابقة");small(options,"✓ حفظ قائمة الانتظار محليًا");small(options,"الروابط المسجلة: "+store.size()+" | المعلقة للفحص: "+store.pendingCount());small(options,"عند بدء الفحص يُحفظ أي نص لم تضغط له حفظ الروابط.");}
  private void progressPage(){
    LinearLayout c=card(content);title(c,"إعدادات التشغيل والجلسة");ScannerConfig conf=new ScannerConfig(this);
    small(c,"الفاصل بين الروابط: "+conf.gapSeconds()+" ث • مهلة المعاينة: "+conf.timeoutSeconds()+" ث • المحاولات: "+conf.retries());
    long rest=store.cooldownUntil()-System.currentTimeMillis();if(rest>0)small(c,"التهدئة المتبقية: "+(rest/1000)+" ثانية");
    small(c,"الواجهة العائمة تظهر فوق واتساب عند تفعيل Accessibility وتسمح بالإيقاف/الاستئناف دون الرجوع للتطبيق.");
  }
  private void results(){LinearLayout c=card(content);title(c,"نتائج الفحص");search=new EditText(this);search.setSingleLine(true);search.setTextSize(14);search.setHint("بحث بالاسم أو الرابط...");search.setText(query);search.setBackground(bg(BG,12));pad(search,10,11);c.addView(search);search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();renderResults();}public void afterTextChanged(android.text.Editable e){}});
    HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout chips=horizontal();for(int i=0;i<TYPES.length;i++){final int f=i;TextView t=txt(TYPES[i],12,i==filter?Color.WHITE:GREEN,true);GradientDrawable b=bg(i==filter?GREEN:BG,13);t.setBackground(b);pad(t,10,8);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(3),dp(6),dp(3),dp(5));chips.addView(t,p);t.setOnClickListener(v->{filter=f;renderResults();});}hs.addView(chips);c.addView(hs);
    LinearLayout selection=horizontal();c.addView(selection);
    button(selection,"✓ تحديد الكل",0xff2b709d,true,this::selectAllVisible);
    button(selection,"إلغاء التحديد",0xff6f7f7b,true,()->{selected.clear();renderResults();});
    button(selection,"حذف المحدد",0xffd34b47,false,this::deleteSelected);
    resultHost=vertical();content.addView(resultHost);renderResults();LinearLayout exp=card(content);LinearLayout row=horizontal();exp.addView(row);button(row,"تصدير CSV",GREEN,false,this::export);button(row,"تصدير Excel",0xff168069,false,this::exportExcel);LinearLayout extra=horizontal();exp.addView(extra);button(extra,"نسخ النتائج",0xff2c709a,true,this::copy);}
  private LinearLayout resultHost;
  private String label(String type){for(int i=1;i<CODES.length;i++)if(CODES[i].equals(type))return TYPES[i];return "قيد الانتظار";}
  private int resultColor(String type){for(int i=1;i<CODES.length;i++)if(CODES[i].equals(type))return COLORS[i-1];return MUTED;}
  private boolean matchesCurrentFilter(JSONObject o){
    if(o==null)return false;String st=o.optString("status"),name=o.optString("name"),url=o.optString("url");
    if(filter>0&&!st.equals(CODES[filter]))return false;
    String q=query==null?"":query.toLowerCase(Locale.ROOT);
    return q.isEmpty()||name.toLowerCase(Locale.ROOT).contains(q)||url.toLowerCase(Locale.ROOT).contains(q);
  }
  private void selectAllVisible(){JSONArray a=store.all();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(matchesCurrentFilter(o))selected.add(o.optString("url"));}renderResults();}
  private void deleteSelected(){
    if(selected.isEmpty()){toast("لم تحدد أي روابط");return;}
    new AlertDialog.Builder(this).setTitle("حذف الروابط المحددة؟").setMessage("سيتم حذف "+selected.size()+" رابط من القائمة والنتائج.")
      .setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{store.deleteUrls(selected);selected.clear();show(0);}).show();
  }
  private void renderResults(){if(resultHost==null)return;resultHost.removeAllViews();JSONArray a=store.all();int shown=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(!matchesCurrentFilter(o))continue;String st=o.optString("status"),name=o.optString("name"),url=o.optString("url");shown++;LinearLayout c=card(resultHost);LinearLayout r=horizontal();
      CheckBox cb=new CheckBox(this);cb.setChecked(selected.contains(url));cb.setOnCheckedChangeListener((b,checked)->{if(checked)selected.add(url);else selected.remove(url);});r.addView(cb);
      TextView n=txt(name.isEmpty()?"اسم غير متاح":name,15,INK,true);r.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView tag=txt(label(st),11,Color.WHITE,true);tag.setBackground(bg(resultColor(st),9));pad(tag,8,6);r.addView(tag);c.addView(r);
      TextView u=txt(url,12,MUTED,false);u.setMaxLines(2);u.setEllipsize(android.text.TextUtils.TruncateAt.END);LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,-2);up.topMargin=dp(9);c.addView(u,up);
      if(!o.optString("members").isEmpty())small(c,"العدد ("+o.optString("countType","غير محدد")+"): "+o.optString("members"));if(!o.optString("joinType").isEmpty())small(c,"نوع الانضمام: "+o.optString("joinType"));if(!o.optString("creationDate").isEmpty())small(c,"تاريخ الإنشاء: "+o.optString("creationDate"));if(o.optLong("scannedAt")>0)small(c,"تاريخ الفحص: "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(o.optLong("scannedAt"))));if(o.optInt("accuracy")>0)small(c,"دقة الفحص: "+o.optInt("accuracy")+"%");if(!o.optString("note").isEmpty())small(c,o.optString("note"));final JSONObject item=o;c.setOnClickListener(v->detail(item));}
    if(shown==0)small(resultHost,"لا توجد روابط تطابق البحث أو التصنيف المختار.");
  }
  private void detail(JSONObject o){
    String url=o.optString("url");
    String scanned=o.optLong("scannedAt")>0?new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(o.optLong("scannedAt"))):"غير مكتمل";
    String msg="التصنيف: "+label(o.optString("status"))
      +"\nنوع الانضمام: "+o.optString("joinType","UNKNOWN")
      +"\nنوع العدد: "+o.optString("countType","UNKNOWN")
      +"\n\nالرابط: "+url
      +"\n\nالعدد: "+(o.optString("members").isEmpty()?"غير متاح":o.optString("members"))
      +"\nتاريخ الإنشاء: "+(o.optString("creationDate").isEmpty()?"غير ظاهر":o.optString("creationDate"))
      +"\nتاريخ الفحص: "+scanned
      +"\nدقة الفحص: "+o.optInt("accuracy")+"%"
      +"\nالمحاولات: "+o.optInt("attempts")
      +"\nملاحظات: "+o.optString("note");
    new AlertDialog.Builder(this).setTitle(o.optString("name","تفاصيل الرابط")).setMessage(msg)
      .setPositiveButton("نسخ الرابط",(d,w)->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("WA link",url));toast("نُسخ الرابط");})
      .setNeutralButton("فتح في واتساب",(d,w)->{try{Intent in=new Intent(Intent.ACTION_VIEW,Uri.parse(url));in.setPackage(selectedWhatsApp().isEmpty()?"com.whatsapp":selectedWhatsApp());startActivity(in);}catch(Exception ex){toast("لم يتمكن التطبيق من فتح واتساب");}})
      .setNegativeButton("إغلاق",null).show();
  }
  private void tools(){LinearLayout c=card(content);title(c,"أدوات وإدارة الجلسة");LinearLayout manage=horizontal();c.addView(manage);button(manage,"✓ تحديد الكل",0xff2b709d,true,this::selectAllVisible);button(manage,"مسح الكل",0xffd4383e,false,()->new AlertDialog.Builder(this).setTitle("مسح كل الروابط والنتائج؟").setMessage("لا يمكن التراجع عن المسح. صدّر النتائج أولًا إذا احتجتها.").setNegativeButton("إلغاء",null).setPositiveButton("مسح الكل",(d,w)->{if(ScannerAccessibility.current!=null)ScannerAccessibility.current.clear();else store.clear();selected.clear();show(0);}).show());LinearLayout row=horizontal();c.addView(row);button(row,"إعادة غير المحسوم",0xffcb8a00,false,this::retry);button(row,"حفظ CSV",GREEN,false,this::export);button(row,"حفظ Excel",0xff168069,false,this::exportExcel);LinearLayout next=horizontal();c.addView(next);button(next,"نسخ جميع النتائج",0xff2b709d,false,this::copy);button(next,"فحص الاتصال",0xff7354a2,false,this::diagnose);button(next,"سجل الانهيار",0xffac4535,false,this::showCrashReport);LinearLayout wipe=card(content);title(wipe,"إدارة البيانات");LinearLayout r=horizontal();wipe.addView(r);button(r,"حذف جميع النتائج",0xffd4383e,false,()->new AlertDialog.Builder(this).setTitle("مسح كل الروابط والنتائج؟").setMessage("لا يمكن التراجع عن المسح. تأكد من تصدير النتائج أولًا.").setNegativeButton("إلغاء",null).setPositiveButton("مسح",(d,w)->{if(ScannerAccessibility.current!=null)ScannerAccessibility.current.clear();else store.clear();show(4);}).show());LinearLayout connect=card(content);title(connect,"اتصال واتساب الرسمي");small(connect,"حالة خدمة إمكانية الوصول: "+(ScannerAccessibility.current==null?"غير مفعلة":"مفعلة"));small(connect,"يفتح الروابط باستخدام التطبيق الرسمي ويقرأ معاينة الدعوة الظاهرة؛ لا يضغط زر الانضمام.");LinearLayout a=horizontal();connect.addView(a);button(a,"إعدادات إمكانية الوصول",DARK,false,()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    LinearLayout verify=horizontal();connect.addView(verify);
    button(verify,"اختبار اتصال مباشر (10 ث)",GREEN,false,this::testConnection);
    small(connect,"يختبر استقبال أحداث واتساب وقراءة عناصر الواجهة دون فحص أي رسائل أو الانضمام.");
    diagnosticsPanel();}
  private void diagnosticsPanel(){
    LinearLayout panel=card(content);title(panel,"سجل التشخيصات والأخطاء");
    small(panel,"سجل محلي مختصر؛ لا يحتفظ بنصوص المحادثات أو رموز الدعوات.");
    EditText log=new EditText(this);log.setText(DiagnosticsLog.read(this));log.setTextSize(12);
    log.setTextColor(INK);log.setBackground(bg(0xffe8f1ee,10));pad(log,12,12);
    log.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
    log.setKeyListener(null);log.setGravity(Gravity.TOP);log.setVerticalScrollBarEnabled(true);
    panel.addView(log,new LinearLayout.LayoutParams(-1,dp(230)));
    LinearLayout commands=horizontal();panel.addView(commands);
    button(commands,"تحديث السجل",GREEN,false,()->log.setText(DiagnosticsLog.read(this)));
    button(commands,"نسخ السجل",0xff2563a4,false,()->{
      ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
      clipboard.setPrimaryClip(ClipData.newPlainText("WA Scanner diagnostics",DiagnosticsLog.read(this)));
      toast("تم نسخ سجل التشخيصات");
    });
    LinearLayout actions=horizontal();panel.addView(actions);
    button(actions,"تسجيل فحص الاتصال",0xff7654ac,false,()->{diagnose();log.setText(DiagnosticsLog.read(this));});
    button(actions,"مسح السجل",0xffce4545,true,()->new AlertDialog.Builder(this)
      .setTitle("مسح سجل التشخيصات؟").setMessage("لن تُحذف الروابط أو نتائج الفحص.")
      .setNegativeButton("إلغاء",null).setPositiveButton("مسح",(d,w)->{
        DiagnosticsLog.clear(this);log.setText(DiagnosticsLog.read(this));
      }).show());
  }
  private void testConnection(){
    ScannerAccessibility activeScanner=ScannerAccessibility.current;
    if(activeScanner!=null && activeScanner.isScanning()){
      new AlertDialog.Builder(this).setTitle("الفحص يعمل الآن")
        .setMessage("اختبار فتح واتساب أثناء الفحص قد يبدّل المعاينة الجاري قراءتها. أوقف المهمة أولًا أو انتظر اكتمالها.")
        .setPositiveButton("حسنًا",null).show();return;
    }
    if(selectedWhatsApp().isEmpty()){chooseWhatsApp(true);return;}
    ScannerAccessibility service=ScannerAccessibility.current;
    if(service==null){new AlertDialog.Builder(this).setTitle("الاتصال غير جاهز")
      .setMessage("فعّل خدمة Accessibility من إعدادات الهاتف أولًا.")
      .setPositiveButton("فتح الإعدادات",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
      .setNegativeButton("إلغاء",null).show();return;}
    String pkg=selectedWhatsApp();
    if(pkg.isEmpty()){new AlertDialog.Builder(this).setMessage("واتساب الرسمي غير مثبت.")
      .setPositiveButton("حسنًا",null).show();return;}
    if(!serviceEnabled()){toast("الخدمة ليست مفعّلة في إعدادات إمكانية الوصول");return;}
    Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
    if(launch==null){toast("تعذر فتح التطبيق الرسمي؛ افحص إعدادات واتساب");return;}
    service.beginProbe();DiagnosticsLog.add(this,"PROBE","فتح واتساب لإجراء اختبار مباشر");
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    startActivity(launch);
    // User returns to the scanner after ten seconds; results available in Tools > Check connection.
    handler.postDelayed(()->{
      String report=service.probeSummary();DiagnosticsLog.add(this,"PROBE","نتيجة الاختبار: أحداث "+service.probeEventCount()+"، عناصر "+service.probeNodeCount());
      android.util.Log.i("WA_SCANNER_DIAG",report.replace('\n',' '));
      if(active)new AlertDialog.Builder(this).setTitle("نتيجة الاختبار")
        .setMessage(report).setPositiveButton("إغلاق",null).show();
      else getSharedPreferences("probe",MODE_PRIVATE).edit().putString("last",report).apply();
    },10000);
    toast("فُتح واتساب للاختبار. ارجع إلى Scanner بعد 10 ثوانٍ ثم افتح فحص الاتصال.");
  }
  private String selectedWhatsApp(){
    String pkg=getSharedPreferences("wa_target",MODE_PRIVATE).getString("package","");
    return ("com.whatsapp".equals(pkg)||"com.whatsapp.w4b".equals(pkg))?pkg:"";
  }
  private static String targetLabel(String pkg){
    if("com.whatsapp".equals(pkg))return "WhatsApp الرسمي";
    if("com.whatsapp.w4b".equals(pkg))return "WhatsApp Business";
    return "لم يتم الاختيار";
  }
  private void chooseWhatsApp(boolean testAfterSelection){
    ArrayList<String> candidates=new ArrayList<>();
    ArrayList<String> titles=new ArrayList<>();
    if(installed("com.whatsapp")){candidates.add("com.whatsapp");titles.add("WhatsApp الرسمي");}
    if(installed("com.whatsapp.w4b")){candidates.add("com.whatsapp.w4b");titles.add("WhatsApp Business");}
    if(candidates.isEmpty()){
      DiagnosticsLog.add(this,"CONNECT","لا يوجد WhatsApp رسمي أو Business على الهاتف");
      new AlertDialog.Builder(this).setTitle("لم يُعثر على واتساب")
        .setMessage("ثبّت واتساب الرسمي أو Business ثم أعد المحاولة. لا تكفي خدمة Accessibility وحدها.")
        .setPositiveButton("حسنًا",null).show();return;
    }
    int checked=Math.max(0,candidates.indexOf(selectedWhatsApp()));
    new AlertDialog.Builder(this).setTitle("اختر واتساب المستخدم في الفحص")
      .setSingleChoiceItems(titles.toArray(new String[0]),checked,(dialog,which)->{
        String pkg=candidates.get(which);
        ScannerAccessibility service=ScannerAccessibility.current;
        if(service!=null&&service.isScanning()){
          toast("أوقف الفحص قبل تغيير واتساب");dialog.dismiss();return;
        }
        getSharedPreferences("wa_target",MODE_PRIVATE).edit().putString("package",pkg).apply();
        DiagnosticsLog.add(this,"CONNECT","تم اختيار "+targetLabel(pkg)+"؛ يلزم اختبار ظهور المعاينة");
        dialog.dismiss();show(tab);
        if(testAfterSelection)testConnection();
      })
      .setNegativeButton("إلغاء",null).show();
  }
  private boolean serviceEnabled(){AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);if(am==null)return false;for(AccessibilityServiceInfo x:am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){if(x.getResolveInfo()!=null&&x.getResolveInfo().serviceInfo!=null&&getPackageName().equals(x.getResolveInfo().serviceInfo.packageName)&&"com.waultimate.scanner.ScannerAccessibility".equals(x.getResolveInfo().serviceInfo.name))return true;}return false;}
  private boolean installed(String pkg){try{getPackageManager().getPackageInfo(pkg,0);return true;}catch(PackageManager.NameNotFoundException ex){return false;}}
  private void showCrashReport(){
    final String report=CrashReporter.read(this);
    new AlertDialog.Builder(this).setTitle("سجل انهيار التطبيق (Java)")
      .setMessage(report)
      .setPositiveButton("نسخ السجل",(dialog,which)->{
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("WA Scanner Java crash",report));
        toast("تم نسخ سجل الانهيار؛ راجعه قبل مشاركته");
      }).setNegativeButton("إغلاق",null).show();
  }
  private void diagnose(){DiagnosticsLog.add(this,"DIAG","فحص الربط والصلاحيات؛ الخدمة "+(serviceEnabled()?"مفعلة":"غير مفعلة"));String msg="إذن Accessibility مفعّل: "+(serviceEnabled()?"نعم":"لا")+"\nالخدمة متصلة بالتطبيق: "+(ScannerAccessibility.current!=null?"نعم":"لا")+"\nWhatsApp مثبت: "+(installed("com.whatsapp")?"نعم":"لا")+"\nWhatsApp Business مثبت: "+(installed("com.whatsapp.w4b")?"نعم":"لا")+"\nالتطبيق المحدد: "+targetLabel(selectedWhatsApp())+"\n"+(ScannerAccessibility.current==null?"لم تتصل الخدمة بعد":ScannerAccessibility.current.diagnostics())+"\nآخر اختبار مباشر: "+getSharedPreferences("probe",MODE_PRIVATE).getString("last","لم يُجرَ")+"\nحالة المهمة: "+state()+"\nالروابط في الطابور: "+store.size()+"\nآخر حالة: "+store.message()+"\n\nالتشخيص لا يثبت نجاح القراءة إلا بعد تجربة فعلية على الهاتف.";new AlertDialog.Builder(this).setTitle("تشخيص Accessibility").setMessage(msg).setPositiveButton("حسنًا",null).show();}
  private static final String DRAFT_PREF="wa_link_draft";
  private void saveDraft(String draft){getSharedPreferences(DRAFT_PREF,MODE_PRIVATE).edit().putString("text",draft).apply();}
  private String loadDraft(){return getSharedPreferences(DRAFT_PREF,MODE_PRIVATE).getString("text","");}
  private boolean flushDraftForScan(){
    String draft=input!=null?input.getText().toString():loadDraft();
    if(draft.trim().isEmpty())return true;
    if(!ScanStore.containsLinks(draft)){
      DiagnosticsLog.add(this,"IMPORT","مربع الروابط يحتوي نصًا دون روابط واتساب صالحة");
      new AlertDialog.Builder(this).setTitle("الروابط غير محفوظة")
        .setMessage("النص المكتوب لا يحتوي على روابط دعوات أو قنوات واتساب معروفة؛ راجع مربع الروابط.")
        .setPositiveButton("عرض الروابط",(d,w)->show(1)).setNegativeButton("إغلاق",null).show();
      return false;
    }
    try{
      int added=store.add(draft);
      saveDraft("");if(input!=null)input.setText("");
      DiagnosticsLog.add(this,"IMPORT","حفظ تلقائي قبل بدء الفحص: جديد "+added+"؛ معلق "+store.pendingCount());
      return true;
    }catch(Exception ex){DiagnosticsLog.add(this,"ERROR","تعذر إدخال النص قبل الفحص: "+ex.getClass().getSimpleName());toast("تعذر حفظ روابطك؛ لم يبدأ الفحص");return false;}
  }
  private void start(){if(!flushDraftForScan())return;if(selectedWhatsApp().isEmpty()){chooseWhatsApp(false);return;}if(!installed(selectedWhatsApp())){DiagnosticsLog.add(this,"CONNECT","واتساب المحدد غير مثبت: "+selectedWhatsApp());chooseWhatsApp(false);return;}if(store.pendingCount()==0){DiagnosticsLog.add(this,"QUEUE","روابط مسجلة: "+store.size()+"؛ روابط معلقة: 0؛ المسودة: "+loadDraft().length()+" حرف");new AlertDialog.Builder(this).setTitle("لا توجد روابط للفحص").setMessage(store.size()==0?"أضف روابط واتساب من تبويب الروابط أولًا.":"جميع الروابط مكتملة أو غير محسومة. أضف روابط جديدة أو اختر إعادة غير المحسوم.").setPositiveButton("إضافة روابط",(d,w)->show(1)).setNegativeButton("إغلاق",null).show();DiagnosticsLog.add(this,"QUEUE","منع بدء الفحص: قائمة الانتظار فارغة");return;}if(ScannerAccessibility.current==null){new AlertDialog.Builder(this).setTitle("خدمة الفحص غير مفعلة").setMessage("فعّل WA Ultimate Scanner في إعدادات إمكانية الوصول، ثم عد إلى التطبيق.").setPositiveButton("فتح الإعدادات",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("إلغاء",null).show();return;}ScannerAccessibility.current.begin();show(tab);}
  private void stop(){DiagnosticsLog.add(this,"CONTROL","ضغط زر الإيقاف الفوري من الواجهة");if(ScannerAccessibility.current!=null)ScannerAccessibility.current.stop();show(tab);}
  private void retry(){DiagnosticsLog.add(this,"CONTROL","إعادة غير المحسوم من الواجهة");if(ScannerAccessibility.current!=null)ScannerAccessibility.current.stop();store.retryUnresolved();toast("أعيدت الروابط غير المحسومة إلى قائمة الانتظار");show(tab);}
  private static String q(String s){return "\""+s.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\"";}
  private String csv(){StringBuilder s=new StringBuilder("\uFEFFURL,Status,Name,JoinType,Count,CountType,CreationDate,ScannedAt,Accuracy,Attempts,Reason\r\n");JSONArray a=store.all();SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String scanned=o.optLong("scannedAt")>0?f.format(new Date(o.optLong("scannedAt"))):"";s.append(q(o.optString("url"))).append(',').append(q(o.optString("status"))).append(',').append(q(o.optString("name"))).append(',').append(q(o.optString("joinType"))).append(',').append(q(o.optString("members"))).append(',').append(q(o.optString("countType"))).append(',').append(q(o.optString("creationDate"))).append(',').append(q(scanned)).append(',').append(o.optInt("accuracy")).append(',').append(o.optInt("attempts")).append(',').append(q(o.optString("note"))).append("\r\n");}return s.toString();}
  private void copy(){ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("WA results",csv()));toast("نُسخت جميع النتائج");}
  private void exportExcel(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"WA-Scanner-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".xlsx");startActivityForResult(i,SAVE_XLSX);}
  private void export(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"WA-Scanner-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".csv");startActivityForResult(i,SAVE);}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;try{if(req==PICK){
      String filename="";try(android.database.Cursor cursor=getContentResolver().query(data.getData(),new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(cursor!=null&&cursor.moveToFirst())filename=cursor.getString(0);}
      String extracted=LinkFileImporter.read(this,data.getData(),filename);
      int matched=ScanStore.countLinks(extracted);
      if(matched==0){DiagnosticsLog.add(this,"IMPORT","ملف بدون روابط WhatsApp معروفة: "+filename);new AlertDialog.Builder(this).setTitle("لم تُعثر على روابط")
        .setMessage("لم نجد روابط واتساب في هذا الملف. يدعم التطبيق TXT وCSV وXLSX؛ تحقق من أن الروابط كاملة.")
        .setPositiveButton("حسنًا",null).show();return;}
      int added=store.add(extracted);
      DiagnosticsLog.add(this,"IMPORT","ملف "+filename+": مطابقات "+matched+"، جديد "+added+"، معلق "+store.pendingCount());
      toast("تمت قراءة "+matched+" رابط؛ أضيف "+added+" جديد؛ المعلق "+store.pendingCount());show(1);
    }else if(req==SAVE){try(OutputStream o=getContentResolver().openOutputStream(data.getData())){o.write(csv().getBytes(StandardCharsets.UTF_8));}toast("حُفظ ملف CSV");}else if(req==SAVE_XLSX){try(OutputStream o=getContentResolver().openOutputStream(data.getData())){if(o==null)throw new IOException("تعذر فتح الملف");ExcelExporter.write(o,store.all());}toast("حُفظ Excel بأوراق منفصلة");}}catch(Exception ex){DiagnosticsLog.add(this,"ERROR","عملية الملف فشلت: "+ex.getClass().getSimpleName()+" / "+(ex.getMessage()==null?"":ex.getMessage()));toast("تعذر استيراد أو حفظ الملف: "+ex.getMessage());}}
  private final Runnable ticker=new Runnable(){public void run(){if(!active)return;if(heroStatus!=null&&heroProgress!=null&&progress!=null){JSONArray a=store.all();int done=counts(a)[0];heroStatus.setText("حالة الفحص: "+state());heroProgress.setText("مكتمل "+done+" من "+a.length());progress.setProgress(a.length()==0?0:(100*done/a.length()));
      ScannerAccessibility service=ScannerAccessibility.current;
      if(engineStage!=null)engineStage.setText("المرحلة: "+(service==null?"غير متصل":service.phaseLabel()));
      if(engineDetail!=null)engineDetail.setText(service==null?"فعّل Accessibility لبدء فحص رابط تجريبي":service.lastNavigation());}handler.postDelayed(this,1500);}};
  @Override protected void onResume(){super.onResume();if(new ScannerConfig(this).keepAwake())getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);active=true;handler.removeCallbacks(ticker);handler.post(ticker);}
  @Override protected void onPause(){active=false;handler.removeCallbacks(ticker);super.onPause();}
}
