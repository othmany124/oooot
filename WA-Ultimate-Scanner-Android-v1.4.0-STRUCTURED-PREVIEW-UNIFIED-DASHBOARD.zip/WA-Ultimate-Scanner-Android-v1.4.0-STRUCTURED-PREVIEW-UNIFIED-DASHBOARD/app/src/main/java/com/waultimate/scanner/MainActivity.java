package com.waultimate.scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.*;
import android.view.accessibility.AccessibilityManager;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** v1.4.0 — compact single-screen RTL dashboard. */
public final class MainActivity extends Activity {
  private static final int PICK=101,SAVE=102,SAVE_XLSX=103;
  private static final int DARK=0xff063d37,GREEN=0xff0a8f59,BG=0xfff3f7f6,INK=0xff142c28,MUTED=0xff687b77;
  private static final String[] FILTER_LABELS={"الكل","قروبات","موافقة","مجتمعات","قنوات","غير محسوم","غير شغال"};
  private static final String[] FILTER_CODES={"","GROUP","APPROVAL","COMMUNITY","CHANNEL","UNRESOLVED","INVALID"};
  private ScanStore store; private ScannerConfig config;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private LinearLayout resultHost,statsHost; private TextView targetText,stateText,progressText,pendingText,selectionText;
  private ProgressBar progress; private EditText input,search; private int filter=0; private String query="";
  private final Set<String> selected=new LinkedHashSet<>(); private int lastHash=0; private boolean resumed;

  private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
  private GradientDrawable shape(int color,float radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
  private TextView text(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);if(bold)v.setTypeface(null,Typeface.BOLD);return v;}
  private LinearLayout h(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
  private LinearLayout v(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
  private void pad(View x,int h,int y){x.setPadding(dp(h),dp(y),dp(h),dp(y));}
  private TextView action(String label,int color,Runnable run){TextView b=text(label,13,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(shape(color,13));b.setOnClickListener(x->run.run());return b;}
  private TextView outlined(String label,int color,Runnable run){TextView b=text(label,12,color,true);b.setGravity(Gravity.CENTER);GradientDrawable d=shape(Color.WHITE,13);d.setStroke(dp(1),0xffdbe5e2);b.setBackground(d);b.setOnClickListener(x->run.run());return b;}

  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(DARK);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);store=new ScanStore(this);config=new ScannerConfig(this);build();}
  @Override protected void onResume(){super.onResume();resumed=true;tick();}
  @Override protected void onPause(){resumed=false;super.onPause();}

  private void build(){
    LinearLayout root=v();root.setBackgroundColor(BG);
    root.addView(header(),new LinearLayout.LayoutParams(-1,dp(82)));
    LinearLayout upper=v();pad(upper,10,8);root.addView(upper,new LinearLayout.LayoutParams(-1,-2));
    upper.addView(statusAndStats());
    upper.addView(controlsAndInput());
    upper.addView(filters());
    LinearLayout searchRow=h();search=new EditText(this);search.setSingleLine(true);search.setHint("ابحث بالاسم أو الرابط...");search.setTextSize(13);search.setBackground(shape(Color.WHITE,13));pad(search,12,5);searchRow.addView(search,new LinearLayout.LayoutParams(0,dp(44),1));
    TextView sort=outlined("ترتيب: العدد ↓",GREEN,()->{toast("القروبات مرتبة من الأكبر إلى الأصغر عند ظهور العدد");renderResults();});LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(128),dp(44));sp.setMargins(dp(6),0,0,0);searchRow.addView(sort,sp);upper.addView(searchRow);
    search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){query=s.toString();renderResults();}public void afterTextChanged(android.text.Editable e){}});

    ScrollView resultsScroll=new ScrollView(this);resultsScroll.setFillViewport(true);resultHost=v();pad(resultHost,10,4);resultsScroll.addView(resultHost);root.addView(resultsScroll,new LinearLayout.LayoutParams(-1,0,1));
    root.addView(bottomBar(),new LinearLayout.LayoutParams(-1,dp(62)));
    setContentView(root);refreshSummary();renderResults();
  }

  private View header(){
    LinearLayout bar=h();bar.setBackgroundColor(DARK);pad(bar,12,10);
    TextView gear=action("⚙",0x33000000,this::settingsDialog);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(48),dp(48));bar.addView(gear,gp);
    LinearLayout brand=v();TextView title=text("WA Ultimate Scanner",19,Color.WHITE,true);TextView sub=text("فحص روابط واتساب باحتراف",11,0xffc9eee1,false);brand.addView(title);brand.addView(sub);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.setMargins(dp(10),0,dp(8),0);bar.addView(brand,bp);
    LinearLayout target=v();target.setBackground(shape(Color.WHITE,15));pad(target,12,6);targetText=text(WhatsAppTarget.label(this),13,INK,true);TextView connected=text(serviceEnabled()?"● الخدمة متصلة":"○ Accessibility",10,serviceEnabled()?GREEN:0xffc27400,false);target.addView(targetText);target.addView(connected);target.setOnClickListener(x->chooseTarget());bar.addView(target,new LinearLayout.LayoutParams(dp(170),dp(56)));
    return bar;
  }

  private View statusAndStats(){
    LinearLayout row=h();
    LinearLayout status=v();status.setBackground(shape(Color.WHITE,17));pad(status,12,10);LinearLayout top=h();stateText=text("جاهز",14,GREEN,true);top.addView(stateText,new LinearLayout.LayoutParams(0,-2,1));progressText=text("0 / 0",18,INK,true);top.addView(progressText);status.addView(top);progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgressTintList(ColorStateList.valueOf(GREEN));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(8));pp.setMargins(0,dp(8),0,dp(5));status.addView(progress,pp);pendingText=text("معلق: 0",11,MUTED,false);status.addView(pendingText);row.addView(status,new LinearLayout.LayoutParams(dp(152),dp(112)));
    statsHost=v();LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(0,dp(112),1);stp.setMargins(dp(7),0,0,0);row.addView(statsHost,stp);return row;
  }

  private View controlsAndInput(){
    LinearLayout box=v();LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,dp(7),0,dp(7));box.setLayoutParams(bp);
    LinearLayout controls=h();
    controls.addView(action("⏸ إيقاف",0xfff08b24,this::pause),new LinearLayout.LayoutParams(0,dp(48),1));
    LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(0,dp(48),1);gap.setMargins(dp(6),0,0,0);controls.addView(action("▶ بدء/استئناف",0xff1976d2,this::start),gap);
    LinearLayout.LayoutParams gap2=new LinearLayout.LayoutParams(0,dp(48),1);gap2.setMargins(dp(6),0,0,0);controls.addView(action("⏭ تخطي",0xff69767c,this::skip),gap2);
    LinearLayout.LayoutParams gap3=new LinearLayout.LayoutParams(0,dp(48),1);gap3.setMargins(dp(6),0,0,0);controls.addView(action("■ إيقاف",0xffdf3d3d,this::pause),gap3);box.addView(controls);
    LinearLayout add=h();add.setPadding(0,dp(7),0,0);input=new EditText(this);input.setSingleLine(true);input.setHint("الصق روابط واتساب هنا...");input.setTextSize(13);input.setBackground(shape(Color.WHITE,13));pad(input,12,4);add.addView(input,new LinearLayout.LayoutParams(0,dp(44),1));
    TextView plus=action("+ إضافة",GREEN,this::addDraft);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(88),dp(44));ap.setMargins(dp(6),0,0,0);add.addView(plus,ap);
    TextView file=outlined("استيراد",GREEN,this::pickFile);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(82),dp(44));fp.setMargins(dp(6),0,0,0);add.addView(file,fp);box.addView(add);return box;
  }

  private View filters(){
    HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);LinearLayout row=h();
    for(int i=0;i<FILTER_LABELS.length;i++){final int f=i;TextView chip=text(FILTER_LABELS[i],11,i==filter?Color.WHITE:INK,true);chip.setGravity(Gravity.CENTER);chip.setBackground(shape(i==filter?GREEN:0xffe9efed,12));pad(chip,10,7);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(38));p.setMargins(dp(3),dp(5),dp(3),dp(5));row.addView(chip,p);chip.setOnClickListener(x->{filter=f;rebuildFilters(sc,row);renderResults();});}
    sc.addView(row);return sc;
  }
  private void rebuildFilters(HorizontalScrollView sc,LinearLayout row){for(int i=0;i<row.getChildCount();i++){TextView chip=(TextView)row.getChildAt(i);chip.setTextColor(i==filter?Color.WHITE:INK);chip.setBackground(shape(i==filter?GREEN:0xffe9efed,12));}}

  private View bottomBar(){
    LinearLayout bar=h();bar.setBackgroundColor(Color.WHITE);pad(bar,8,7);selectionText=text("0 محدد",11,MUTED,true);bar.addView(selectionText,new LinearLayout.LayoutParams(dp(62),-1));
    String[] labels={"تحديد الكل","إعادة فحص","حذف المحدد","مسح الكل","Excel"};int[] colors={0xff596d68,0xff1976d2,0xffd23d3d,0xffe45b5b,GREEN};Runnable[] acts={this::selectAll,this::retrySelected,this::deleteSelected,this::clearAll,this::exportExcel};
    for(int i=0;i<labels.length;i++){TextView b=i==4?action(labels[i],colors[i],acts[i]):outlined(labels[i],colors[i],acts[i]);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(2),0,dp(2),0);bar.addView(b,p);}return bar;
  }

  private void refreshSummary(){
    JSONArray all=store.all();int total=all.length(),done=0,direct=0,approval=0,community=0,channel=0,unresolved=0,invalid=0;
    for(int i=0;i<total;i++){JSONObject o=all.optJSONObject(i);if(o==null)continue;String s=o.optString("status");if(!"PENDING".equals(s)&&!"RETRY".equals(s))done++;if("DIRECT".equals(s))direct++;else if("APPROVAL".equals(s))approval++;else if("COMMUNITY".equals(s))community++;else if("CHANNEL".equals(s))channel++;else if("UNRESOLVED".equals(s))unresolved++;else if("INVALID".equals(s))invalid++;}
    progressText.setText(done+" / "+total);progress.setProgress(total==0?0:done*100/total);pendingText.setText("معلق: "+store.pendingCount()+"  •  "+store.message());stateText.setText(stateLabel());
    statsHost.removeAllViews();int[] values={direct,approval,community,channel,unresolved,invalid};String[] names={"قروبات","موافقة","مجتمعات","قنوات","غير محسوم","غير شغال"};int[] cols={0xffe7f6ee,0xfffff0df,0xffe8f1ff,0xfff1e9ff,0xfffff5d9,0xffffe8e8};
    for(int r=0;r<2;r++){LinearLayout rr=h();statsHost.addView(rr,new LinearLayout.LayoutParams(-1,0,1));for(int c=0;c<3;c++){int idx=r*3+c;LinearLayout tile=v();tile.setGravity(Gravity.CENTER);tile.setBackground(shape(cols[idx],13));TextView n=text(String.valueOf(values[idx]),17,INK,true);n.setGravity(Gravity.CENTER);TextView l=text(names[idx],9,MUTED,true);l.setGravity(Gravity.CENTER);tile.addView(n);tile.addView(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(2),dp(2),dp(2),dp(2));rr.addView(tile,p);final int f=idx+1;tile.setOnClickListener(x->{filter=f;renderResults();});}}
    if(targetText!=null)targetText.setText(WhatsAppTarget.label(this));
  }
  private String stateLabel(){String s=store.state();if("RUNNING".equals(s))return "جاري الفحص";if("PAUSED".equals(s))return "متوقف";if("COOLDOWN".equals(s))return "تهدئة";if("RECOVERING".equals(s))return "استعادة";if("DONE".equals(s))return "مكتمل";return "جاهز";}

  private boolean matches(JSONObject o){if(o==null)return false;String s=o.optString("status"),url=o.optString("url"),name=o.optString("name");String q=query.trim().toLowerCase(Locale.ROOT);if(!q.isEmpty()&&!url.toLowerCase(Locale.ROOT).contains(q)&&!name.toLowerCase(Locale.ROOT).contains(q))return false;if(filter==0)return true;String f=FILTER_CODES[filter];if("GROUP".equals(f))return "DIRECT".equals(s)||"APPROVAL".equals(s);return f.equals(s);}
  private long sortCount(JSONObject o){String exact=o.optString("members");if(!exact.isEmpty())try{return Long.parseLong(exact.replaceAll("[^0-9]",""))*1000L;}catch(Exception ignored){}String approx=o.optString("approximateCount");if(!approx.isEmpty())try{return Long.parseLong(approx.replaceAll("[^0-9]",""));}catch(Exception ignored){}return -1;}
  private void renderResults(){if(resultHost==null)return;resultHost.removeAllViews();JSONArray all=store.all();List<JSONObject> rows=new ArrayList<>();for(int i=0;i<all.length();i++){JSONObject o=all.optJSONObject(i);if(matches(o))rows.add(o);}if(filter==1||filter==2)rows.sort((a,b)->Long.compare(sortCount(b),sortCount(a)));
    int shown=0;for(JSONObject o:rows){if(shown++>=120)break;resultHost.addView(resultRow(o));}if(rows.isEmpty()){TextView empty=text("لا توجد نتائج في هذا التصنيف",13,MUTED,false);empty.setGravity(Gravity.CENTER);pad(empty,10,25);resultHost.addView(empty);}selectionText.setText(selected.size()+" محدد");}
  private View resultRow(JSONObject o){
    LinearLayout row=h();row.setBackground(shape(Color.WHITE,14));pad(row,8,7);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(78));rp.setMargins(0,dp(3),0,dp(3));row.setLayoutParams(rp);
    String url=o.optString("url"),status=o.optString("status"),name=o.optString("name");TextView check=text(selected.contains(url)?"☑":"☐",21,selected.contains(url)?GREEN:MUTED,true);check.setGravity(Gravity.CENTER);row.addView(check,new LinearLayout.LayoutParams(dp(42),-1));
    LinearLayout main=v();TextView nameV=text(name.isEmpty()?shortUrl(url):name,13,INK,true);main.addView(nameV);String meta=statusAr(status)+"  •  "+countDisplay(o)+(o.optString("creationDate").isEmpty()?"":"  •  "+o.optString("creationDate"));TextView metaV=text(meta,10,MUTED,false);main.addView(metaV);TextView urlV=text(shortUrl(url),9,GREEN,false);main.addView(urlV);row.addView(main,new LinearLayout.LayoutParams(0,-1,1));
    LinearLayout tail=v();tail.setGravity(Gravity.CENTER);TextView acc=text(o.optInt("accuracy")>0?o.optInt("accuracy")+"%":"—",12,accuracyColor(o.optInt("accuracy")),true);acc.setGravity(Gravity.CENTER);tail.addView(acc);TextView tag=text(statusTag(status),9,statusColor(status),true);tag.setGravity(Gravity.CENTER);tail.addView(tag);row.addView(tail,new LinearLayout.LayoutParams(dp(72),-1));
    row.setOnClickListener(x->{if(selected.contains(url))selected.remove(url);else selected.add(url);renderResults();});return row;
  }
  private String countDisplay(JSONObject o){String s=o.optString("members");if(!s.isEmpty())return s+" "+countUnit(o.optString("countType"));String a=o.optString("approximateCount");if(!a.isEmpty())return "+"+a+" تقريبي";return "العدد غير ظاهر";}
  private String countUnit(String type){if("FOLLOWERS".equals(type))return "متابع";if("SUBGROUPS".equals(type))return "قروب";return "عضو";}
  private String statusAr(String s){if("DIRECT".equals(s))return "قروب بدون موافقة";if("APPROVAL".equals(s))return "قروب بموافقة";if("COMMUNITY".equals(s))return "مجتمع";if("CHANNEL".equals(s))return "قناة";if("INVALID".equals(s))return "غير شغال";if("UNRESOLVED".equals(s))return "غير محسوم";if("RETRY".equals(s))return "إعادة فحص";return "معلق";}
  private String statusTag(String s){if("DIRECT".equals(s))return "DIRECT";if("APPROVAL".equals(s))return "APPROVAL";if("COMMUNITY".equals(s))return "COMMUNITY";if("CHANNEL".equals(s))return "CHANNEL";if("INVALID".equals(s))return "INVALID";if("UNRESOLVED".equals(s))return "UNRESOLVED";return s;}
  private int statusColor(String s){if("INVALID".equals(s))return 0xffd83b3b;if("UNRESOLVED".equals(s))return 0xffd88900;if("CHANNEL".equals(s))return 0xff7a40c8;return GREEN;}
  private int accuracyColor(int n){return n>=90?GREEN:n>=70?0xffd88900:0xffd83b3b;}
  private String shortUrl(String u){if(u==null)return "";return u.length()>42?u.substring(0,39)+"...":u;}

  private void addDraft(){try{String d=input.getText().toString();if(!ScanStore.containsLinks(d)){toast("لا توجد روابط واتساب صالحة في النص");return;}int n=store.add(d);input.setText("");toast(n>0?"أضيف "+n+" رابط":"كل الروابط موجودة مسبقًا");refreshAll();}catch(Exception e){toast("تعذر إضافة الروابط");DiagnosticsLog.add(this,"ERROR","إضافة الروابط: "+e.getClass().getSimpleName());}}
  private void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
  private String displayName(Uri u){String name="";try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix);}}catch(Exception ignored){}return name;}
  private void start(){if(!input.getText().toString().trim().isEmpty())addDraft();if(store.pendingCount()==0){toast("لا توجد روابط معلقة. أضف روابط جديدة أو أعد غير المحسوم.");return;}if(WhatsAppTarget.resolve(this).isEmpty()){chooseTarget();return;}if(ScannerAccessibility.current==null){new AlertDialog.Builder(this).setTitle("فعّل خدمة Accessibility").setMessage("يلزم تفعيل WA Ultimate Scanner لقراءة معاينة واتساب والتنقل بين الروابط.").setPositiveButton("فتح الإعدادات",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("إلغاء",null).show();return;}ScannerAccessibility.current.begin();refreshAll();}
  private void pause(){if(ScannerAccessibility.current!=null)ScannerAccessibility.current.stop();refreshAll();}
  private void skip(){if(ScannerAccessibility.current!=null)ScannerAccessibility.current.skipCurrent();else toast("خدمة الفحص غير متصلة");}
  private void selectAll(){JSONArray a=store.all();selected.clear();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(matches(o))selected.add(o.optString("url"));}renderResults();}
  private void deleteSelected(){if(selected.isEmpty()){toast("لم تحدد روابط");return;}new AlertDialog.Builder(this).setTitle("حذف المحدد؟").setMessage("سيتم حذف "+selected.size()+" رابط/نتيجة.").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{store.deleteUrls(selected);selected.clear();refreshAll();}).show();}
  private void retrySelected(){if(selected.isEmpty()){store.retryUnresolved();refreshAll();toast("أُعيدت الروابط غير المحسومة");return;}try{JSONArray a=store.all();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&selected.contains(o.optString("url"))&&("UNRESOLVED".equals(o.optString("status"))||"INVALID".equals(o.optString("status"))))o.put("status","RETRY");}getSharedPreferences("scan_state",MODE_PRIVATE).edit().putString("queue",a.toString()).commit();selected.clear();refreshAll();}catch(Exception e){toast("تعذر إعادة المحدد");}}
  private void clearAll(){new AlertDialog.Builder(this).setTitle("مسح الكل؟").setMessage("سيتم حذف جميع الروابط والنتائج نهائيًا.").setNegativeButton("إلغاء",null).setPositiveButton("مسح الكل",(d,w)->{if(ScannerAccessibility.current!=null)ScannerAccessibility.current.clear();else store.clear();selected.clear();refreshAll();}).show();}

  private void chooseTarget(){String[] items={"تلقائي","WhatsApp Messenger","WhatsApp Business"};String pref=WhatsAppTarget.preference(this);int checked=WhatsAppTarget.MESSENGER.equals(pref)?1:WhatsAppTarget.BUSINESS.equals(pref)?2:0;new AlertDialog.Builder(this).setTitle("تطبيق واتساب المستخدم للفحص").setSingleChoiceItems(items,checked,(d,which)->{WhatsAppTarget.preference(this,which==1?WhatsAppTarget.MESSENGER:which==2?WhatsAppTarget.BUSINESS:WhatsAppTarget.AUTO);d.dismiss();refreshAll();}).setNegativeButton("إلغاء",null).show();}
  private void settingsDialog(){
    LinearLayout box=v();pad(box,18,8);TextView wa=outlined("تطبيق واتساب: "+WhatsAppTarget.label(this),GREEN,this::chooseTarget);box.addView(wa,new LinearLayout.LayoutParams(-1,dp(46)));
    Switch overlay=new Switch(this);overlay.setText("الواجهة العائمة أثناء الفحص");overlay.setChecked(config.overlayEnabled());overlay.setOnCheckedChangeListener((b,on)->{config.overlayEnabled(on);if(ScannerAccessibility.current!=null)ScannerAccessibility.current.applyOverlaySetting();});box.addView(overlay);
    TextView speed=text("سرعة الفحص",13,INK,true);box.addView(speed);RadioGroup rg=new RadioGroup(this);rg.setOrientation(RadioGroup.HORIZONTAL);int[] gaps={1,4,8};String[] names={"ذكي","متوازن","محافظ"};for(int i=0;i<3;i++){RadioButton r=new RadioButton(this);r.setText(names[i]);r.setChecked((config.gapSeconds()<=1?0:config.gapSeconds()<=4?1:2)==i);final int x=i;r.setOnClickListener(v->config.gapSeconds(gaps[x]));rg.addView(r);}box.addView(rg);
    LinearLayout actions=h();actions.addView(outlined("Accessibility",0xff1976d2,()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))),new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);p.setMargins(dp(6),0,0,0);actions.addView(outlined("تشخيص",0xff6b4cb7,this::diagnose),p);box.addView(actions);
    new AlertDialog.Builder(this).setTitle("الإعدادات").setView(box).setPositiveButton("إغلاق",null).show();
  }
  private void diagnose(){String m="Accessibility: "+(serviceEnabled()?"مفعّل":"غير مفعّل")+"\nMessenger: "+(WhatsAppTarget.installed(this,WhatsAppTarget.MESSENGER)?"مثبت":"غير مثبت")+"\nBusiness: "+(WhatsAppTarget.installed(this,WhatsAppTarget.BUSINESS)?"مثبت":"غير مثبت")+"\nالهدف: "+WhatsAppTarget.label(this)+"\n\n"+(ScannerAccessibility.current==null?"الخدمة غير متصلة":ScannerAccessibility.current.diagnostics());new AlertDialog.Builder(this).setTitle("تشخيص الفحص").setMessage(m).setPositiveButton("حسنًا",null).show();}
  private boolean serviceEnabled(){AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);if(am==null||!am.isEnabled())return false;for(AccessibilityServiceInfo i:am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK))if(i.getId()!=null&&i.getId().startsWith(getPackageName()+"/"))return true;return false;}

  private void exportExcel(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"WA-Scanner-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".xlsx");startActivityForResult(i,SAVE_XLSX);}
  private void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"WA-Scanner-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".csv");startActivityForResult(i,SAVE);}
  private String csv(){StringBuilder b=new StringBuilder("url,name,status,join_type,exact_count,approx_count,count_type,count_precision,creator,creation_date,scan_date,accuracy,note\n");JSONArray a=store.all();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String[] v={o.optString("url"),o.optString("name"),o.optString("status"),o.optString("joinType"),o.optString("members"),o.optString("approximateCount"),o.optString("countType"),o.optString("countPrecision"),o.optString("creator"),o.optString("creationDate"),String.valueOf(o.optLong("scannedAt")),String.valueOf(o.optInt("accuracy")),o.optString("note")};for(int x=0;x<v.length;x++){if(x>0)b.append(',');b.append('"').append(v[x].replace("\"","\"\"")).append('"');}b.append('\n');}return b.toString();}

  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{if(req==PICK){String raw=LinkFileImporter.read(this,uri,displayName(uri));int n=store.add(raw);toast("أضيف "+n+" رابط");refreshAll();}else if(req==SAVE){try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(csv().getBytes(StandardCharsets.UTF_8));}toast("تم حفظ CSV");}else if(req==SAVE_XLSX){try(OutputStream out=getContentResolver().openOutputStream(uri)){ExcelExporter.write(out,store.all());}toast("تم حفظ Excel");}}catch(Exception e){DiagnosticsLog.add(this,"ERROR","ملف/تصدير: "+e.getClass().getSimpleName());toast("فشلت العملية: "+e.getMessage());}}

  private void refreshAll(){refreshSummary();renderResults();lastHash=store.all().toString().hashCode();}
  private void tick(){if(!resumed)return;int hash=store.all().toString().hashCode();refreshSummary();if(hash!=lastHash){lastHash=hash;renderResults();}handler.postDelayed(this::tick,900);}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
