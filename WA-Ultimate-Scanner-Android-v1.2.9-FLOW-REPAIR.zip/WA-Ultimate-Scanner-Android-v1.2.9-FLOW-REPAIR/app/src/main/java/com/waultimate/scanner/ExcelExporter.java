package com.waultimate.scanner;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Dependency-free, native XLSX export. All externally sourced text uses inline strings (not formulas). */
public final class ExcelExporter {
  private static final String[] NAMES={"الملخص","جميع النتائج","مباشر","يتطلب موافقة","المجتمعات","القنوات","غير شغالة","غير محسومة"};
  private static final String[] STATUS={"","","DIRECT","APPROVAL","COMMUNITY","CHANNEL","INVALID","UNRESOLVED"};
  private static final String[] HEAD={"#","الرابط","الاسم","التصنيف","نوع الانضمام","العدد","نوع العدد","المحاولات","تاريخ الفحص","الملاحظات"};
  private static final String[][] SUM={{"DIRECT","المجموعات المباشرة"},{"APPROVAL","تتطلب الموافقة"},{"COMMUNITY","المجتمعات"},{"CHANNEL","القنوات"},{"INVALID","غير شغالة"},{"UNRESOLVED","غير محسومة"},{"PENDING","قيد الانتظار"},{"RETRY","بانتظار إعادة المحاولة"}};
  private ExcelExporter(){}
  private static String esc(String s){if(s==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='&')b.append("&amp;");else if(c=='<')b.append("&lt;");else if(c=='>')b.append("&gt;");else if(c=='\"')b.append("&quot;");else if(c=='\'')b.append("&apos;");else if(c>=32||c=='\n'||c=='\t'||c=='\r')b.append(c);}return b.toString();}
  private static String col(int n){String s="";while(n>0){n--;s=(char)('A'+n%26)+s;n/=26;}return s;}
  private static void textCell(StringBuilder out,int x,int y,String value,int style){out.append("<c r=\"").append(col(x)).append(y).append("\" s=\"").append(style).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(value)).append("</t></is></c>");}
  private static void numberCell(StringBuilder out,int x,int y,long value,int style){out.append("<c r=\"").append(col(x)).append(y).append("\" s=\"").append(style).append("\"><v>").append(value).append("</v></c>");}
  private static void row(StringBuilder out,int y,String[] strings, boolean header){out.append("<row r=\"").append(y).append("\" ht=\"").append(header?27:23).append("\" customHeight=\"1\">");for(int i=0;i<strings.length;i++)textCell(out,i+1,y,strings[i],header?1:(y%2==0?2:3));out.append("</row>");}
  private static String time(long epoch){return epoch==0?"":new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(epoch));}
  private static String[] record(JSONObject o,int ix){return new String[]{Integer.toString(ix),o.optString("url"),o.optString("name"),o.optString("status"),o.optString("joinType","UNKNOWN"),o.optString("members"),o.optString("countType","UNKNOWN"),Integer.toString(o.optInt("attempts")),time(o.optLong("updated")),o.optString("note")};}
  private static String worksheet(JSONArray input,int which){
    StringBuilder s=new StringBuilder(4096+input.length()*500);
    s.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
    if(which==0){
      s.append("<cols><col min=\"1\" max=\"1\" width=\"28\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"19\" customWidth=\"1\"/></cols><sheetData>");row(s,1,new String[]{"التصنيف","عدد الروابط"},true);
      for(int k=0;k<SUM.length;k++){int n=0;for(int i=0;i<input.length();i++){JSONObject o=input.optJSONObject(i);if(o!=null&&SUM[k][0].equals(o.optString("status")))n++;}s.append("<row r=\"").append(k+2).append("\">");textCell(s,1,k+2,SUM[k][1],k%2==0?2:3);numberCell(s,2,k+2,n,4);s.append("</row>");}
      s.append("<row r=\"11\">");textCell(s,1,11,"إجمالي الروابط الفريدة",1);numberCell(s,2,11,input.length(),4);s.append("</row></sheetData><autoFilter ref=\"A1:B9\"/>");
    }else{
      s.append("<cols><col min=\"1\" max=\"1\" width=\"7\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"58\" customWidth=\"1\"/><col min=\"3\" max=\"3\" width=\"36\" customWidth=\"1\"/><col min=\"4\" max=\"5\" width=\"22\" customWidth=\"1\"/><col min=\"6\" max=\"8\" width=\"15\" customWidth=\"1\"/><col min=\"9\" max=\"9\" width=\"23\" customWidth=\"1\"/><col min=\"10\" max=\"10\" width=\"68\" customWidth=\"1\"/></cols><sheetData>");row(s,1,HEAD,true);
      int n=2;for(int i=0;i<input.length();i++){JSONObject o=input.optJSONObject(i);if(o==null)continue;if(which>=2&&!STATUS[which].equals(o.optString("status")))continue;row(s,n,record(o,i+1),false);n++;}
      s.append("</sheetData><autoFilter ref=\"A1:J").append(Math.max(1,n-1)).append("\"/>");
    }
    s.append("</worksheet>");return s.toString();
  }
  private static String workbook(){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>");for(int i=0;i<NAMES.length;i++)s.append("<sheet name=\"").append(esc(NAMES[i])).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");return s.append("</sheets></workbook>").toString();}
  private static String rels(){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");for(int i=0;i<NAMES.length;i++)s.append("<Relationship Id=\"rId").append(i+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i+1).append(".xml\"/>");return s.append("<Relationship Id=\"rId9\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>").toString();}
  private static final String STYLES="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Arial\"/></font></fonts><fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF075E45\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE9F5F0\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"5\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/></cellXfs></styleSheet>";
  private static void add(ZipOutputStream z,String name,String body)throws IOException{z.putNextEntry(new ZipEntry(name));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
  public static void write(OutputStream destination, JSONArray input)throws IOException{
    ZipOutputStream z=new ZipOutputStream(destination);
    add(z,"[Content_Types].xml",types());
    add(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
    add(z,"xl/workbook.xml",workbook());add(z,"xl/_rels/workbook.xml.rels",rels());add(z,"xl/styles.xml",STYLES);
    for(int i=0;i<NAMES.length;i++)add(z,"xl/worksheets/sheet"+(i+1)+".xml",worksheet(input,i));z.finish();z.flush();
  }
  private static String types(){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");for(int i=1;i<=NAMES.length;i++)s.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");return s.append("</Types>").toString();}
}
