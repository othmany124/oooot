package com.waultimate.scanner;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Explicit evidence only. Missing fields stay empty and never imply a dead invite. */
public final class PreviewParser {
  static final class Result {
    String status="UNRESOLVED", name="", members="", joinType="UNKNOWN", countType="UNKNOWN", note="لا تكفي معلومات المعاينة";
    boolean rateLimited=false;
  }
  private static final String[] INVALID={"invite link has been reset","invite link is invalid","this invite link is invalid","invite link has expired","couldn't find this group","can't find this group","رابط الدعوة غير صالح","تم إعادة تعيين رابط الدعوة","انتهت صلاحية رابط الدعوة","تعذر العثور على المجموعة"};
  private static final String[] LIMIT={"try again later","too many requests","please wait before trying","حاول مرة أخرى لاحقًا","طلبات كثيرة","يرجى المحاولة لاحقاً","يرجى المحاولة لاحقا"};
  private static final String[] APPROVAL={"request to join","ask to join","request approval","approval required","طلب الانضمام","طلب الموافقة","موافقة المشرف","موافقة المسؤول"};
  private static final String[] JOIN={"join group","join community","join channel","follow channel","الانضمام إلى المجموعة","انضم إلى المجموعة","الانضمام إلى المجتمع","متابعة القناة","الانضمام إلى القناة"};
  private static final String[] CHANNEL={"channel invite","join channel","follow channel","whatsapp channel","دعوة إلى قناة","متابعة القناة","الانضمام إلى القناة"};
  private static final String[] COMMUNITY={"community invite","join community","whatsapp community","دعوة إلى مجتمع","الانضمام إلى المجتمع"};
  private static final String[] IGNORE={"whatsapp","cancel","إلغاء","إلغاء الأمر","join group","join community","join channel","follow channel","request to join","ask to join","الانضمام إلى المجموعة","انضم إلى المجموعة","الانضمام إلى المجتمع","متابعة القناة","طلب الانضمام","طلب الموافقة","مجموعة واتساب","دعوة للانضمام","group invite","invite to group","channel invite","community invite","دعوة إلى قناة","دعوة إلى مجتمع","members","member","مشارك","مشاركون","الأعضاء","الأعضاء:","group info","المعلومات","معلومات المجموعة","back","رجوع","report","إبلاغ","ok","موافق","فتح بواسطة","open with"};
  private static final Pattern COUNT=Pattern.compile("(?iuU)(?:([0-9\\d,٬،.]+)\\s*(members|participants|followers|subscribers|عضو|أعضاء|مشارك|مشترك|متابع|متابعون|مشتركين|قروب|مجموعات|groups|subgroups)|(?:الأعضاء|المشاركون|المتابعون|المشتركون)\\s*[:：]?\\s*([0-9\\d,٬،.]+))");
  private static final Pattern COUNT_ONLY=Pattern.compile("(?iuU)^[0-9\\d,٬،.]+\\s*(members|participants|followers|subscribers|عضو|أعضاء|مشارك|متابع|متابعون|مشترك|مشتركين|قروب|مجموعات|groups|subgroups)$");
  static boolean has(String s,String[] needles){for(String n:needles)if(s.contains(n))return true;return false;}
  private static String digits(String input){StringBuilder s=new StringBuilder();for(int i=0;i<input.length();i++){char c=input.charAt(i);int d=Character.digit(c,10);if(d>=0)s.append((char)('0'+d));}return s.toString();}
  private static boolean ignored(String s){String t=s.toLowerCase(Locale.ROOT).trim();if(t.length()<2||t.length()>120||t.startsWith("http")||t.contains("chat.whatsapp.com")||t.contains("whatsapp.com/channel/"))return true;if(t.matches("[0-9\\d,٬،. ]+"))return true;if(COUNT_ONLY.matcher(t).matches())return true;for(String n:IGNORE)if(t.equals(n))return true;return false;}
  static Result parse(List<String> input){
    Result r=new Result();if(input==null)return r;
    List<String> parts=new ArrayList<>();StringBuilder allText=new StringBuilder();
    for(String entry:input){if(entry==null)continue;String item=entry.trim();if(item.isEmpty())continue; if(!parts.contains(item))parts.add(item);allText.append(item.toLowerCase(Locale.ROOT)).append('\n');}
    String all=allText.toString();
    if(has(all,LIMIT)){r.rateLimited=true;r.note="رُصد حد الطلبات؛ يُعاد فحص الرابط بعد التهدئة";return r;}
    // A generic connectivity error or absent title is NOT evidence of an invalid invite.
    if(has(all,INVALID)){r.status="INVALID";r.joinType="INVALID";r.note="واتساب عرض رسالة صريحة بعدم صلاحية الرابط";return r;}
    boolean approval=has(all,APPROVAL),join=has(all,JOIN);
    if(!approval&&!join){r.note="لم تظهر معاينة دعوة مؤكدة";return r;}
    boolean channel=has(all,CHANNEL),community=has(all,COMMUNITY);
    if(channel&&community){r.note="ظهرت إشارات متعارضة للقناة والمجتمع";return r;}
    if(channel)r.status="CHANNEL";
    else if(community)r.status="COMMUNITY";
    else r.status=approval?"APPROVAL":"DIRECT";
    r.joinType=approval?"APPROVAL":channel?"FOLLOW":join?"DIRECT":"UNKNOWN";
    int firstAction=parts.size();for(int i=0;i<parts.size();i++){String t=parts.get(i).toLowerCase(Locale.ROOT);if(has(t,JOIN)||has(t,APPROVAL)){firstAction=i;break;}}
    // Prefer the title preceding the action, but ignore numbers and generic labels.
    for(int i=firstAction-1;i>=0;i--){String title=parts.get(i);if(!ignored(title)){r.name=title;break;}}
    if(r.name.isEmpty()){r.status="UNRESOLVED";r.joinType="UNKNOWN";r.note="زر الانضمام ظاهر دون اسم موثوق؛ يلزم التحقق مجددًا";return r;}
    for(String item:parts){Matcher m=COUNT.matcher(item);if(!m.find())continue;String raw=m.group(1)!=null?m.group(1):m.group(3);String value=digits(raw);if(value.isEmpty())continue;String unit=m.group(2)==null?item.toLowerCase(Locale.ROOT):m.group(2).toLowerCase(Locale.ROOT);
      String type=(unit.contains("follow")||unit.contains("subscr")||unit.contains("متابع")||unit.contains("مشترك"))?"FOLLOWERS":(unit.contains("group")||unit.contains("subgroup")||unit.contains("مجموعات")||unit.contains("قروب"))?"SUBGROUPS":"MEMBERS";
      // Prefer entity-appropriate counts when multiple visible counts exist.
      if(r.members.isEmpty() || (channel&&"FOLLOWERS".equals(type)) || (community&&"SUBGROUPS".equals(type))){r.members=value;r.countType=type;}
    }
    // Type remains as displayed by WhatsApp; missing count is explicitly left blank.
    r.note="معاينة واتساب؛ العدد غير متاح إذا لم يكن ظاهرًا";
    return r;
  }
}
