package com.waultimate.scanner;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Bounded, private diagnostic events. Never store message text or invite tokens. */
public final class DiagnosticsLog {
  private static final String FILE="scanner_diagnostics.txt";
  private static final int MAX_BYTES=100*1024;
  private DiagnosticsLog(){}
  public static synchronized void add(Context context,String type,String message){
    if(context==null)return;
    try {
      String stamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());
      String safe=(message==null?"":message)
        .replaceAll("https?://(?:chat\\.whatsapp\\.com|whatsapp\\.com/channel)/[A-Za-z0-9_-]+","[INVITE_REDACTED]")
        .replaceAll("[\r\n]+"," ");
      if(safe.length()>350)safe=safe.substring(0,350);
      File file=new File(context.getFilesDir(),FILE);
      if(file.exists()&&file.length()>MAX_BYTES){
        byte[] bytes=readFile(file);
        int from=Math.max(0,bytes.length-MAX_BYTES/2);
        while(from<bytes.length&&bytes[from]!='\n')from++;
        if(from<bytes.length)from++;
        try(FileOutputStream trim=new FileOutputStream(file,false)){trim.write(bytes,from,bytes.length-from);}
      }
      String line=stamp+" ["+type+"] "+safe+"\n";
      try(FileOutputStream stream=new FileOutputStream(file,true)){stream.write(line.getBytes(StandardCharsets.UTF_8));}
    }catch(Exception ignored){}
  }
  private static byte[] readFile(File file) throws Exception {
    try(FileInputStream f=new FileInputStream(file); java.io.ByteArrayOutputStream o=new java.io.ByteArrayOutputStream()){
      byte[] b=new byte[4096];int n;while((n=f.read(b))!=-1)o.write(b,0,n);return o.toByteArray();
    }
  }
  public static synchronized String read(Context c){
    try{File file=new File(c.getFilesDir(),FILE);if(!file.exists())return "لا توجد تشخيصات مسجلة حتى الآن.";
      return new String(readFile(file),StandardCharsets.UTF_8);
    }catch(Exception e){return "تعذر قراءة سجل التشخيص: "+e.getClass().getSimpleName();}
  }
  public static synchronized void clear(Context c){new File(c.getFilesDir(),FILE).delete();}
}
