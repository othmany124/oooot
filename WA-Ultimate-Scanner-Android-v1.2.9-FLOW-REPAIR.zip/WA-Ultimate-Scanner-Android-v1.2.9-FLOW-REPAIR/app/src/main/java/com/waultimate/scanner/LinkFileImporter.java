package com.waultimate.scanner;

import android.content.Context;
import android.net.Uri;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Reads user-chosen text, CSV, and XLSX locally. No file permissions or network required. */
public final class LinkFileImporter {
  private static final int MAX_FILE=25*1024*1024;
  private static final int MAX_ENTRY=12*1024*1024;
  private LinkFileImporter(){}

  public static String read(Context context, Uri uri, String name) throws Exception {
    String lower=name==null?"":name.toLowerCase(Locale.ROOT);
    try(InputStream stream=context.getContentResolver().openInputStream(uri)) {
      if(stream==null)throw new IOException("تعذر فتح الملف المختار");
      byte[] bytes=readBytes(stream,MAX_FILE);
      if(lower.endsWith(".xlsx") || looksZip(bytes))return xlsx(bytes);
      if(lower.endsWith(".zip")||lower.endsWith(".xls"))throw new IOException("الملف ليس XLSX؛ حوّله إلى CSV أو XLSX");
      if(bytes.length>=2 && (bytes[0]&255)==255 && (bytes[1]&255)==254)
        return new String(bytes,2,bytes.length-2,StandardCharsets.UTF_16LE);
      if(bytes.length>=2 && (bytes[0]&255)==254 && (bytes[1]&255)==255)
        return new String(bytes,2,bytes.length-2,StandardCharsets.UTF_16BE);
      String text=new String(bytes,StandardCharsets.UTF_8);
      return text.startsWith("\uFEFF")?text.substring(1):text;
    }
  }
  private static boolean looksZip(byte[] b){return b.length>4&&b[0]=='P'&&b[1]=='K'&&b[2]==3&&b[3]==4;}
  private static byte[] readBytes(InputStream stream,int max) throws IOException {
    ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
    while((n=stream.read(buf))!=-1){if(out.size()+n>max)throw new IOException("حجم الملف كبير جدًا؛ الحد 25 ميجابايت");out.write(buf,0,n);}
    return out.toByteArray();
  }
  private static XmlPullParser parser(byte[] xml) throws Exception {
    XmlPullParser x=Xml.newPullParser();x.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,false);
    x.setInput(new ByteArrayInputStream(xml),"UTF-8");return x;
  }
  private static List<String> strings(byte[] xml) throws Exception {
    List<String> values=new ArrayList<>();XmlPullParser x=parser(xml);StringBuilder cur=null;
    int e;while((e=x.next())!=XmlPullParser.END_DOCUMENT){
      if(e==XmlPullParser.START_TAG && "si".equals(x.getName()))cur=new StringBuilder();
      else if(e==XmlPullParser.START_TAG && "t".equals(x.getName())&&cur!=null)cur.append(x.nextText());
      else if(e==XmlPullParser.END_TAG && "si".equals(x.getName())&&cur!=null){values.add(cur.toString());cur=null;}
    }return values;
  }
  private static String xlsx(byte[] archive) throws Exception {
    byte[] shared=null;List<byte[]> sheets=new ArrayList<>();int total=0;
    try(ZipInputStream z=new ZipInputStream(new ByteArrayInputStream(archive))){ZipEntry item;
      while((item=z.getNextEntry())!=null){
        String n=item.getName();if(n.contains("..")||n.startsWith("/"))continue;
        if(n.equals("xl/sharedStrings.xml") || n.matches("xl/worksheets/sheet[0-9]+\\.xml")){
          byte[] data=readBytes(z,MAX_ENTRY);total+=data.length;
          if(total>MAX_FILE)throw new IOException("جداول Excel كبيرة جدًا للقراءة دفعة واحدة");
          if(n.equals("xl/sharedStrings.xml"))shared=data;else sheets.add(data);
        }
        z.closeEntry();
      }
    }
    if(sheets.isEmpty())throw new IOException("لم يتم العثور على أوراق Excel قابلة للقراءة");
    List<String> s=shared==null?new ArrayList<>():strings(shared);
    StringBuilder out=new StringBuilder();
    for(byte[] sheet:sheets){XmlPullParser x=parser(sheet);String type="",value="";boolean cell=false;int ev;
      while((ev=x.next())!=XmlPullParser.END_DOCUMENT){
        if(ev==XmlPullParser.START_TAG && "c".equals(x.getName())){cell=true;type=x.getAttributeValue(null,"t");value="";}
        else if(ev==XmlPullParser.START_TAG && cell && ("v".equals(x.getName())||"t".equals(x.getName())))value+=x.nextText();
        else if(ev==XmlPullParser.END_TAG && "c".equals(x.getName())&&cell){
          if("s".equals(type)){
            try{int idx=Integer.parseInt(value.trim());value=idx>=0&&idx<s.size()?s.get(idx):"";}
            catch(NumberFormatException ignore){value="";}
          }
          if(!value.isEmpty())out.append(value).append('\n');
          cell=false;
        }
      }
    }return out.toString();
  }
}
