# WA Ultimate Scanner PRO 1.2.5

تحديث مصدر مخصص للفحص فقط، يضيف تحسين تأكيد المعاينات، استخراج نوع الانضمام والأعداد الظاهرة، وتصدير Excel أصلي بأوراق منفصلة، بالإضافة إلى CSV وسجل التشخيصات.

**ليس APK جاهزًا، ولم يثبت الاتصال على هاتف فعلي.** التعليمات التفصيلية في `RELEASE_NOTES_AR.md`.

لتجهيز البناء في GitHub Codespaces بعد رفع ZIP الحالي، شغّل:

```bash
bash <(unzip -p WA-Ultimate-Scanner-Android-v1.2.5-PRECISION-FAST-EXCEL.zip WA-Ultimate-Scanner-Android-v1.2.5-PRECISION-FAST-EXCEL/INSTALL_IN_CODESPACES.sh)
```

إذا كان لديك التطبيق مثبتًا بالفعل، لا تستبدل مفتاح التوقيع: تحتاج المفتاح الأصلي نفسه لتثبيت النسخة الجديدة فوق القديمة، وإلا سيرفض أندرويد التحديث.
