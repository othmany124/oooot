package com.waultimate.scanner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Private, local-only queue; commits each completed record before opening another link. */
public final class ScanStore {
  private static final String PREF = "scan_state";
  private static final Pattern URL = Pattern.compile("https?://(?:chat\\.whatsapp\\.com/[A-Za-z0-9_-]{8,}|whatsapp\\.com/channel/[A-Za-z0-9_-]{8,})",Pattern.CASE_INSENSITIVE);
  private final SharedPreferences p;
  private final Context context;
  public ScanStore(Context c) { context=c.getApplicationContext();p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE); }
  public static boolean containsLinks(String value){return value!=null&&URL.matcher(value).find();}
  public static int countLinks(String value){if(value==null)return 0;Matcher m=URL.matcher(value);int n=0;while(m.find())n++;return n;}
  public static String normalize(String v) { Matcher m=URL.matcher(v.trim()); return m.find()?m.group().replaceAll("/+$",""):null; }
  public synchronized int add(String incoming) throws Exception {
    JSONArray old=all(); LinkedHashSet<String> seen=new LinkedHashSet<>();
    for(int i=0;i<old.length();i++) seen.add(old.getJSONObject(i).getString("url"));
    Matcher m=URL.matcher(incoming); int count=0;
    while(m.find()) { String url=normalize(m.group()); if(url!=null && seen.add(url)) {
      JSONObject r=new JSONObject();r.put("url",url);r.put("status","PENDING");r.put("name","");r.put("members","");r.put("countType","UNKNOWN");r.put("joinType","UNKNOWN");r.put("creationDate","");r.put("creator","");r.put("approximateCount","");r.put("countPrecision","UNKNOWN");r.put("evidence","");r.put("accuracy",0);r.put("scannedAt",0L);r.put("note","");r.put("attempts",0);r.put("updated",System.currentTimeMillis()); old.put(r);count++;
    }}
    p.edit().putString("queue",old.toString()).commit();DiagnosticsLog.add(context,"IMPORT","روابط جديدة: "+count);return count;
  }
  public synchronized JSONArray all() { try{return new JSONArray(p.getString("queue","[]"));}catch(Exception e){return new JSONArray();} }
  public synchronized int size(){return all().length();}
  public synchronized int pendingCount(){
    JSONArray rows=all();int count=0;
    for(int i=0;i<rows.length();i++){
      JSONObject row=rows.optJSONObject(i);
      if(row==null)continue;
      String status=row.optString("status");
      if("PENDING".equals(status)||"RETRY".equals(status))count++;
    }
    return count;
  }
  public synchronized JSONObject at(int idx){return all().optJSONObject(idx);}
  public synchronized void update(int idx,String status,String name,String members,String note,boolean increment) {
    try {JSONArray a=all();JSONObject r=a.getJSONObject(idx);r.put("status",status);r.put("name",name);r.put("members",members);r.put("note",note);r.put("updated",System.currentTimeMillis());if(increment)r.put("attempts",r.optInt("attempts")+1);
      p.edit().putString("queue",a.toString()).commit();DiagnosticsLog.add(context,"RETRY".equals(status)?"QUEUE":"RESULT","رابط رقم "+(idx+1)+" تصنيفه "+status+" والمحاولة "+r.optInt("attempts"));}catch(Exception ignored){}
  }
  public synchronized void updateDetail(int idx,String status,String name,String count,String countType,String joinType,String note){
    try { JSONArray a=all();JSONObject row=a.getJSONObject(idx);
      row.put("status",status);row.put("name",name);row.put("members",count);
      row.put("countType",countType);row.put("joinType",joinType);row.put("note",note);
      row.put("updated",System.currentTimeMillis());
      p.edit().putString("queue",a.toString()).commit();
      DiagnosticsLog.add(context,"RESULT","الرابط "+(idx+1)+": "+status+" / "+joinType+(count.isEmpty()?" / العدد غير ظاهر":" / العدد ظاهر"));
    }catch(Exception ex){DiagnosticsLog.add(context,"ERROR","تعذر حفظ نتيجة الفحص: "+ex.getClass().getSimpleName());}
  }
  /** An in-flight row survives service death. A recovered session must revisit it first. */
  public synchronized int next() {
    JSONArray a=all();String[] statuses=new String[a.length()];
    for(int i=0;i<a.length();i++){
      JSONObject row=a.optJSONObject(i);statuses[i]=row==null?"":row.optString("status");
    }
    return QueuePlanner.select(statuses,p.getInt("active_index",-1));
  }
  public synchronized int activeIndex(){return p.getInt("active_index",-1);}
  /** Atomic disk checkpoint before opening an external activity. Returns attempt number or -1. */
  public synchronized int claim(int idx){
    try{JSONArray a=all();JSONObject row=a.getJSONObject(idx);
      String old=row.optString("status");
      if(!"PENDING".equals(old)&&!"RETRY".equals(old))return -1;
      int attempts=row.optInt("attempts")+1;
      row.put("attempts",attempts);row.put("status","RETRY");
      row.put("note","فتح الرابط؛ المحاولة "+attempts);row.put("updated",System.currentTimeMillis());
      boolean saved=p.edit().putString("queue",a.toString()).putInt("active_index",idx).commit();
      if(saved)DiagnosticsLog.add(context,"QUEUE","بدء الرابط "+(idx+1)+"، المحاولة "+attempts);
      return saved?attempts:-1;
    }catch(Exception e){DiagnosticsLog.add(context,"ERROR","فشل حفظ بدء الرابط: "+e.getClass().getSimpleName());return -1;}
  }
  public synchronized void clearActiveIndex(){p.edit().remove("active_index").commit();}
  /** Persist the completed or deferred result before releasing in-flight ownership. */
  public synchronized boolean defer(int idx,String note){
    try{JSONArray a=all();JSONObject row=a.getJSONObject(idx);
      row.put("status","RETRY");row.put("note",note);row.put("updated",System.currentTimeMillis());
      if(!p.edit().putString("queue",a.toString()).remove("active_index").commit())return false;
      DiagnosticsLog.add(context,"QUEUE","تأجيل الرابط "+(idx+1)+" إلى نهاية الانتظار");return true;
    }catch(Exception e){DiagnosticsLog.add(context,"ERROR","تعذر حفظ الرابط المؤجل: "+e.getClass().getSimpleName());return false;}
  }
  public synchronized boolean complete(int idx,String status,String name,String count,String countType,String joinType,String note){
    return complete(idx,status,name,count,countType,joinType,"",defaultAccuracy(status,name,count),note);
  }
  public synchronized boolean complete(int idx,String status,String name,String count,String countType,String joinType,String creationDate,int accuracy,String note){
    return complete(idx,status,name,count,"",countType,"UNKNOWN",joinType,creationDate,"","",accuracy,note);
  }
  public synchronized boolean complete(int idx,String status,String name,String count,String approximateCount,String countType,String countPrecision,String joinType,String creationDate,String creator,String evidence,int accuracy,String note){
    try{JSONArray a=all();JSONObject row=a.getJSONObject(idx);
      row.put("status",status);row.put("name",name);row.put("members",count==null?"":count);
      row.put("approximateCount",approximateCount==null?"":approximateCount);row.put("countType",countType==null?"UNKNOWN":countType);
      row.put("countPrecision",countPrecision==null?"UNKNOWN":countPrecision);row.put("joinType",joinType==null?"UNKNOWN":joinType);
      row.put("creationDate",creationDate==null?"":creationDate);row.put("creator",creator==null?"":creator);row.put("evidence",evidence==null?"":evidence);
      row.put("accuracy",Math.max(0,Math.min(100,accuracy)));row.put("scannedAt",System.currentTimeMillis());row.put("note",note==null?"":note);
      row.put("updated",System.currentTimeMillis());
      if(!p.edit().putString("queue",a.toString()).remove("active_index").commit())return false;
      DiagnosticsLog.add(context,"RESULT","الرابط "+(idx+1)+": "+status+" / "+joinType+" / دقة "+row.optInt("accuracy")+"%");return true;
    }catch(Exception e){DiagnosticsLog.add(context,"ERROR","تعذر حفظ النتيجة: "+e.getClass().getSimpleName());return false;}
  }
  private static int defaultAccuracy(String status,String name,String count){
    if("INVALID".equals(status))return 100;
    if("DIRECT".equals(status)||"APPROVAL".equals(status)||"COMMUNITY".equals(status)||"CHANNEL".equals(status)){
      int n=85;if(name!=null&&!name.isEmpty())n+=10;if(count!=null&&!count.isEmpty())n+=5;return Math.min(100,n);
    }
    return 0;
  }
  public synchronized int deleteUrls(Set<String> urls){
    if(urls==null||urls.isEmpty())return 0;
    try{JSONArray src=all();JSONArray out=new JSONArray();int removed=0;for(int i=0;i<src.length();i++){JSONObject row=src.optJSONObject(i);if(row==null)continue;if(urls.contains(row.optString("url"))){removed++;continue;}out.put(row);}p.edit().putString("queue",out.toString()).remove("active_index").commit();DiagnosticsLog.add(context,"DATA","حذف روابط محددة: "+removed);return removed;}catch(Exception e){DiagnosticsLog.add(context,"ERROR","تعذر حذف المحدد: "+e.getClass().getSimpleName());return 0;}
  }
  public synchronized void retryUnresolved(){try {JSONArray a=all();for(int i=0;i<a.length();i++){JSONObject r=a.getJSONObject(i);if("UNRESOLVED".equals(r.optString("status")))r.put("status","RETRY");}p.edit().putString("queue",a.toString()).commit();}catch(Exception ignored){}}
  public synchronized void clear(){DiagnosticsLog.add(context,"DATA","مسح الروابط والنتائج");p.edit().remove("queue").remove("active_index").putString("state","IDLE").putString("message","").remove("cooldown_step").remove("cooldown_until").commit();}
  public void state(String s,String msg){String old=state();p.edit().putString("state",s).putString("message",msg).commit();if(!old.equals(s))DiagnosticsLog.add(context,"STATE",old+" → "+s);}
  public String state(){return p.getString("state","IDLE");}
  public String message(){return p.getString("message","");}
  public void cooldown(int step,long until){p.edit().putInt("cooldown_step",step).putLong("cooldown_until",until).commit();}
  public int cooldownStep(){return p.getInt("cooldown_step",0);}
  public long cooldownUntil(){return p.getLong("cooldown_until",0L);}
}
