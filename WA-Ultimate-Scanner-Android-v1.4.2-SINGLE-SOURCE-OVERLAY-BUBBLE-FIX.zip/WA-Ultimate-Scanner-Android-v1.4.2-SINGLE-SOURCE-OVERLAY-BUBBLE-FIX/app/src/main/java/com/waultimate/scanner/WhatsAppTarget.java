package com.waultimate.scanner;

import android.content.Context;
import android.content.pm.PackageManager;

/** Resolves WhatsApp Messenger / Business using a single adapter. */
public final class WhatsAppTarget {
  private WhatsAppTarget(){}
  public static final String AUTO="auto", MESSENGER="com.whatsapp", BUSINESS="com.whatsapp.w4b";
  public static boolean installed(Context c,String pkg){try{c.getPackageManager().getPackageInfo(pkg,0);return true;}catch(PackageManager.NameNotFoundException e){return false;}}
  public static String preference(Context c){return c.getSharedPreferences("wa_target",Context.MODE_PRIVATE).getString("package",AUTO);}
  public static void preference(Context c,String value){c.getSharedPreferences("wa_target",Context.MODE_PRIVATE).edit().putString("package",value).apply();}
  public static void rememberObserved(Context c,String pkg){if(MESSENGER.equals(pkg)||BUSINESS.equals(pkg))c.getSharedPreferences("wa_target",Context.MODE_PRIVATE).edit().putString("last_package",pkg).apply();}
  public static String resolve(Context c){
    String pref=preference(c);
    if(MESSENGER.equals(pref)&&installed(c,MESSENGER))return MESSENGER;
    if(BUSINESS.equals(pref)&&installed(c,BUSINESS))return BUSINESS;
    if(!AUTO.equals(pref))return "";
    String last=c.getSharedPreferences("wa_target",Context.MODE_PRIVATE).getString("last_package","");
    if((MESSENGER.equals(last)||BUSINESS.equals(last))&&installed(c,last))return last;
    if(installed(c,BUSINESS)&&!installed(c,MESSENGER))return BUSINESS;
    if(installed(c,MESSENGER)&&!installed(c,BUSINESS))return MESSENGER;
    if(installed(c,BUSINESS))return BUSINESS;
    if(installed(c,MESSENGER))return MESSENGER;
    return "";
  }
  public static String label(Context c){
    String pref=preference(c), resolved=resolve(c);
    String name=BUSINESS.equals(resolved)?"WhatsApp Business":MESSENGER.equals(resolved)?"WhatsApp Messenger":"غير متاح";
    return AUTO.equals(pref)?"تلقائي — "+name:name;
  }
}
