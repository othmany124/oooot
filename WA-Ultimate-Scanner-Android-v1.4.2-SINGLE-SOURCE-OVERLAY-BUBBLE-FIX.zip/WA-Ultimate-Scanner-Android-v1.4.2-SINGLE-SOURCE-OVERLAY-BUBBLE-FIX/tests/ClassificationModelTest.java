package com.waultimate.scanner;
import java.util.Arrays;
public final class ClassificationModelTest {
  static void eq(String label,String got,String expected){if(!expected.equals(got))throw new AssertionError(label+": "+got+" != "+expected);System.out.println("PASS "+label);}
  public static void main(String[] args){
    PreviewParser.Result g=PreviewParser.parse(Arrays.asList("طلاب الطب","٢٣٤ أعضاء","طلب الانضمام","تم الإنشاء 2025-02-11"));
    eq("group approval",g.status,"APPROVAL");eq("group members",g.members,"234");eq("group date",g.creationDate,"2025-02-11");
    PreviewParser.Result c=PreviewParser.parse(Arrays.asList("مجتمع الجامعة","8 قروبات","الانضمام إلى المجتمع"));eq("community",c.status,"COMMUNITY");eq("community groups",c.members,"8");
    PreviewParser.Result ch=PreviewParser.parse(Arrays.asList("قناة الأخبار","١٢٣٤ متابع","متابعة القناة"),"https://whatsapp.com/channel/ABCDEFGH123456");eq("channel",ch.status,"CHANNEL");eq("followers",ch.members,"1234");
    PreviewParser.Result dead=PreviewParser.parse(Arrays.asList("تم تغيير رابط الدعوة"));eq("reset invalid",dead.status,"INVALID");
    PreviewParser.Result unknown=PreviewParser.parse(Arrays.asList("WhatsApp","Join group"));eq("missing title unresolved",unknown.status,"UNRESOLVED");
  }
}
