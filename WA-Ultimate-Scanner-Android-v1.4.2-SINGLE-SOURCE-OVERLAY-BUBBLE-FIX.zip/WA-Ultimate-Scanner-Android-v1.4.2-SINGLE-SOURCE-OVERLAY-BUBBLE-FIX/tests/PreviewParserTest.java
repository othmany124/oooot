package com.waultimate.scanner;
import java.util.Arrays;
public final class PreviewParserTest {
  static void check(String label,String actual,String expected){if(!expected.equals(actual))throw new AssertionError(label+": "+actual+" != "+expected);System.out.println("PASS "+label);}
  public static void main(String[] args){
    check("direct",PreviewParser.parse(Arrays.asList("Study Group","121 members","Join group")).status,"DIRECT");
    check("approval",PreviewParser.parse(Arrays.asList("Research Group","Request to join")).status,"APPROVAL");
    check("invalid-explicit",PreviewParser.parse(Arrays.asList("This invite link is invalid")).status,"INVALID");
    check("no-name-unresolved",PreviewParser.parse(Arrays.asList("WhatsApp","Join group")).status,"UNRESOLVED");
    check("rate-limited",PreviewParser.parse(Arrays.asList("Try again later")).status,"UNRESOLVED");
    check("channel",PreviewParser.parse(Arrays.asList("News","Channel invite","Join channel"),"https://whatsapp.com/channel/ABCDEFGH123456").status,"CHANNEL");
    check("community",PreviewParser.parse(Arrays.asList("Research","Community invite","Join community")).status,"COMMUNITY");
    check("arabic-title",PreviewParser.parse(Arrays.asList("مجموعة الجراحة","قراءة المزيد","انضم إلى المجموعة")).name,"مجموعة الجراحة");
    check("exact-ar-count",PreviewParser.parse(Arrays.asList("مجموعة الاختبار","٢٣٤","أعضاء","انضم إلى المجموعة")).members,"234");
    check("approx-not-exact",PreviewParser.parse(Arrays.asList("Software Engineer 2007","أنشأها +962 7 8530 5004، ٢٠٢٦/٢/١٥","+٦٠","https://chat.whatsapp.com/XYZ","قراءة المزيد","الانضمام إلى المجموعة")).members,"");
    check("approx-count",PreviewParser.parse(Arrays.asList("Software Engineer 2007","أنشأها +962 7 8530 5004، ٢٠٢٦/٢/١٥","+٦٠","https://chat.whatsapp.com/XYZ","قراءة المزيد","الانضمام إلى المجموعة")).approximateCount,"60");
    check("approx-precision",PreviewParser.parse(Arrays.asList("Software Engineer 2007","أنشأها +962 7 8530 5004، ٢٠٢٦/٢/١٥","+٦٠","الانضمام إلى المجموعة")).countPrecision,"APPROXIMATE");
    check("creator",PreviewParser.parse(Arrays.asList("Software Engineer 2007","أنشأها +962 7 8530 5004، ٢٠٢٦/٢/١٥","+٦٠","الانضمام إلى المجموعة")).creator,"+962 7 8530 5004");
    check("creation-date",PreviewParser.parse(Arrays.asList("Software Engineer 2007","أنشأها +962 7 8530 5004، ٢٠٢٦/٢/١٥","+٦٠","الانضمام إلى المجموعة")).creationDate,"2026/2/15");
    check("description-url-not-title",PreviewParser.parse(Arrays.asList("Software Engineer 2007","أنشأها +962 7 8530 5004، ٢٠٢٦/٢/١٥","وصف المجموعة وروابط مفيدة","https://chat.whatsapp.com/OTHER","قراءة المزيد","الانضمام إلى المجموعة")).name,"Software Engineer 2007");
    check("community-count",PreviewParser.parse(Arrays.asList("Medical Community","12 groups","Join community")).members,"12");
    check("community-kind",PreviewParser.parse(Arrays.asList("Medical Community","12 groups","Join community")).countType,"SUBGROUPS");
    check("channel-followers",PreviewParser.parse(Arrays.asList("أخبار التقنية","١٢٣٤ متابع","متابعة القناة"),"https://whatsapp.com/channel/ABCDEFGH123456").members,"1234");
    check("chat-follow-not-channel",PreviewParser.parse(Arrays.asList("Study Group","Follow","Join group"),"https://chat.whatsapp.com/ABCDEFGH123456").status,"DIRECT");
    check("invalid-accuracy",Integer.toString(PreviewParser.parse(Arrays.asList("This invite link is invalid")).accuracy),"100");
  }
}
