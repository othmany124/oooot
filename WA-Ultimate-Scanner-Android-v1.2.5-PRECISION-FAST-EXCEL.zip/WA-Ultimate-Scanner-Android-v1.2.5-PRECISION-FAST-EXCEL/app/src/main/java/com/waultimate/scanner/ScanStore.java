package com.waultimate.scanner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Private, local-only queue; commits each completed record before opening another link. */
public final class ScanStore {
  private static final String PREF = "scan_state";
  private static final Pattern URL = Pattern.compile("https?://(?:chat\\.whatsapp\\.com/[A-Za-z0-9_-]{8,}|whatsapp\\.com/channel/[A-Za-z0-9_-]{8,})",Pattern.CASE_INSENSITIVE);
  private final SharedPreferences p;
  private final Context context;
  public ScanStore(Context c) { context=c.getApplicationContext();p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE); }
  public static String normalize(String v) { Matcher m=URL.matcher(v.trim()); return m.find()?m.group().replaceAll("/+$",""):null; }
  public synchronized int add(String incoming) throws Exception {
    JSONArray old=all(); LinkedHashSet<String> seen=new LinkedHashSet<>();
    for(int i=0;i<old.length();i++) seen.add(old.getJSONObject(i).getString("url"));
    Matcher m=URL.matcher(incoming); int count=0;
    while(m.find()) { String url=normalize(m.group()); if(url!=null && seen.add(url)) {
      JSONObject r=new JSONObject();r.put("url",url);r.put("status","PENDING");r.put("name","");r.put("members","");r.put("countType","UNKNOWN");r.put("joinType","UNKNOWN");r.put("note","");r.put("attempts",0);r.put("updated",System.currentTimeMillis()); old.put(r);count++;
    }}
    p.edit().putString("queue",old.toString()).commit();DiagnosticsLog.add(context,"IMPORT","روابط جديدة: "+count);return count;
  }
  public synchronized JSONArray all() { try{return new JSONArray(p.getString("queue","[]"));}catch(Exception e){return new JSONArray();} }
  public synchronized int size(){return all().length();}
  public synchronized JSONObject at(int idx){return all().optJSONObject(idx);}
  public synchronized void update(int idx,String status,String name,String members,String note,boolean increment) {
    try {JSONArray a=all();JSONObject r=a.getJSONObject(idx);r.put("status",status);r.put("name",name);r.put("members",members);r.put("note",note);r.put("updated",System.currentTimeMillis());if(increment)r.put("attempts",r.optInt("attempts")+1);
      p.edit().putString("queue",a.toString()).commit();DiagnosticsLog.add(context,"RESULT","رابط رقم "+(idx+1)+" تصنيفه "+status+" والمحاولة "+r.optInt("attempts"));}catch(Exception ignored){}
  }
  public synchronized void updateDetail(int idx,String status,String name,String count,String countType,String joinType,String note){
    try { JSONArray a=all();JSONObject row=a.getJSONObject(idx);
      row.put("status",status);row.put("name",name);row.put("members",count);
      row.put("countType",countType);row.put("joinType",joinType);row.put("note",note);
      row.put("updated",System.currentTimeMillis());
      p.edit().putString("queue",a.toString()).commit();
      DiagnosticsLog.add(context,"RESULT","الرابط "+(idx+1)+": "+status+" / "+joinType+(count.isEmpty()?" / العدد غير ظاهر":" / العدد ظاهر"));
    }catch(Exception ex){DiagnosticsLog.add(context,"ERROR","تعذر حفظ نتيجة الفحص: "+ex.getClass().getSimpleName());}
  }
  public synchronized int next() {
    JSONArray a=all();for(int i=0;i<a.length();i++) {String st=a.optJSONObject(i).optString("status");if("PENDING".equals(st)||"RETRY".equals(st))return i;}return -1;
  }
  public synchronized void retryUnresolved(){try {JSONArray a=all();for(int i=0;i<a.length();i++){JSONObject r=a.getJSONObject(i);if("UNRESOLVED".equals(r.optString("status")))r.put("status","RETRY");}p.edit().putString("queue",a.toString()).commit();}catch(Exception ignored){}}
  public synchronized void clear(){DiagnosticsLog.add(context,"DATA","مسح الروابط والنتائج");p.edit().remove("queue").putString("state","IDLE").putString("message","").remove("cooldown_step").remove("cooldown_until").commit();}
  public void state(String s,String msg){String old=state();p.edit().putString("state",s).putString("message",msg).commit();if(!old.equals(s))DiagnosticsLog.add(context,"STATE",old+" → "+s);}
  public String state(){return p.getString("state","IDLE");}
  public String message(){return p.getString("message","");}
  public void cooldown(int step,long until){p.edit().putInt("cooldown_step",step).putLong("cooldown_until",until).commit();}
  public int cooldownStep(){return p.getInt("cooldown_step",0);}
  public long cooldownUntil(){return p.getLong("cooldown_until",0L);}
}
