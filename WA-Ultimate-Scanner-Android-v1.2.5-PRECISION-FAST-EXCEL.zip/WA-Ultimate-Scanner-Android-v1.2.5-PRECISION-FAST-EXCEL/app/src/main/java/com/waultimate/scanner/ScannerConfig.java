package com.waultimate.scanner;

import android.content.Context;
import android.content.SharedPreferences;

/** Local user preferences. Conservative minimum intervals avoid burst requests. */
public final class ScannerConfig {
  private final SharedPreferences p;
  public ScannerConfig(Context context){p=context.getSharedPreferences("scanner_prefs",Context.MODE_PRIVATE);}
  public int gapSeconds(){return p.getInt("gap_seconds",5);}
  public void gapSeconds(int value){p.edit().putInt("gap_seconds",Math.max(4,Math.min(15,value))).apply();}
  public int timeoutSeconds(){return p.getInt("timeout_seconds",20);}
  public void timeoutSeconds(int v){p.edit().putInt("timeout_seconds",Math.max(12,Math.min(45,v))).apply();}
  public int retries(){return p.getInt("retries",2);}
  public void retries(int v){p.edit().putInt("retries",Math.max(1,Math.min(3,v))).apply();}
  public boolean autoResume(){return p.getBoolean("auto_resume",true);}
  public void autoResume(boolean b){p.edit().putBoolean("auto_resume",b).apply();}
  public boolean keepAwake(){return p.getBoolean("keep_awake",true);}
  public void keepAwake(boolean b){p.edit().putBoolean("keep_awake",b).apply();}
}
