package com.waultimate.scanner;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** Clear, persistent settings with realistic latency controls and rate-limit safeguards. */
public final class SettingsActivity extends Activity {
  private final int green=Color.rgb(7,94,69),ink=Color.rgb(26,43,38),muted=Color.rgb(100,116,112);
  private LinearLayout body; private ScannerConfig config;
  private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
  private GradientDrawable bg(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
  private TextView t(String value,int sp,boolean bold){TextView x=new TextView(this);x.setText(value);x.setTextSize(sp);x.setTextColor(ink);if(bold)x.setTypeface(null,Typeface.BOLD);return x;}
  private LinearLayout card(String heading,String description){
    LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(16),dp(16),dp(16),dp(16));c.setBackground(bg(Color.WHITE,18));
    LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(13);body.addView(c,cp);
    TextView title=t(heading,17,true);c.addView(title);
    TextView sub=t(description,12,false);sub.setTextColor(muted);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(6);lp.bottomMargin=dp(12);c.addView(sub,lp);
    return c;
  }
  private void choice(LinearLayout card,String caption,String[] options,int selected,java.util.function.IntConsumer change){
    TextView label=t(caption,14,true);card.addView(label);
    RadioGroup rg=new RadioGroup(this);rg.setOrientation(RadioGroup.VERTICAL);
    for(int i=0;i<options.length;i++){RadioButton rb=new RadioButton(this);rb.setText(options[i]);rb.setTextSize(14);rb.setTextColor(ink);rg.addView(rb);if(i==selected)rb.setChecked(true);final int n=i;rb.setOnClickListener(v->change.accept(n));}card.addView(rg);
  }
  private void toggle(LinearLayout card,String label,boolean value,java.util.function.Consumer<Boolean> action){Switch s=new Switch(this);s.setText(label);s.setTextSize(14);s.setTextColor(ink);s.setPadding(0,dp(8),0,dp(8));s.setChecked(value);s.setOnCheckedChangeListener((b,checked)->action.accept(checked));card.addView(s);}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);getWindow().setStatusBarColor(green);config=new ScannerConfig(this);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(245,249,247));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(16),dp(22),dp(16),dp(30));scroll.addView(body);
    TextView header=t("إعدادات الماسح",27,true);header.setTextColor(green);body.addView(header);TextView intro=t("تحكم دقيق • تخزين محلي • حماية من التقييد",13,false);intro.setTextColor(muted);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(-1,-2);ilp.bottomMargin=dp(20);body.addView(intro,ilp);
    LinearLayout performance=card("الأداء وسرعة الفحص","سرعة الواجهة مستقلة عن انتظار معاينات واتساب. الأسرع ليس دائمًا أكثر ثباتًا.");
    choice(performance,"الفاصل بين الروابط",new String[]{"سريع — 4 ثوانٍ","متوازن — 5 ثوانٍ","مستقر — 8 ثوانٍ","محافظ — 15 ثانية"},gapIndex(config.gapSeconds()),n->config.gapSeconds(new int[]{4,5,8,15}[n]));
    choice(performance,"مهلة تحميل المعاينة",new String[]{"12 ثانية","20 ثانية (افتراضي)","30 ثانية","45 ثانية"},timeoutIndex(config.timeoutSeconds()),n->config.timeoutSeconds(new int[]{12,20,30,45}[n]));
    LinearLayout accuracy=card("الدقة وإعادة المحاولة","لن يُصنف الرابط غير شغال بسبب انقطاع الشبكة أو انتهاء المهلة فقط.");
    choice(accuracy,"عدد محاولات الرابط غير المحسوم",new String[]{"محاولة واحدة","محاولتان","ثلاث محاولات"},config.retries()-1,n->config.retries(n+1));
    LinearLayout safeguards=card("التقييد والاستئناف","يتوقف الفحص عند ظهور مؤشرات التقييد؛ الاستئناف مؤقت وقد يتأخر في خلفية أندرويد.");
    toggle(safeguards,"الاستئناف التلقائي بعد التهدئة",config.autoResume(),config::autoResume);
    toggle(safeguards,"إبقاء الشاشة مضاءة أثناء الفحص",config.keepAwake(),config::keepAwake);
    TextView cool=t("فترات التهدئة: 2 ← 5 ← 15 ← 30 ← 60 دقيقة. لا توجد طريقة مضمونة لإزالة تقييد واتساب.",13,false);cool.setTextColor(muted);safeguards.addView(cool);
    LinearLayout info=card("الخصوصية والتصدير","يخزن التطبيق الروابط والنتائج محليًا. لا يرسل رسائل ولا ينضم إلى مجموعات.");info.addView(t("CSV متاح حاليًا، مع اسم الرابط ونوعه ومحاولات الفحص وملاحظات النتيجة.",13,false));
    Button back=new Button(this);back.setText("العودة إلى لوحة الفحص");back.setAllCaps(false);back.setTextColor(Color.WHITE);back.setBackground(bg(green,12));back.setOnClickListener(v->finish());body.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));setContentView(scroll);
  }
  private int gapIndex(int s){return s<=4?0:s<=5?1:s<=8?2:3;}
  private int timeoutIndex(int s){return s<=12?0:s<=20?1:s<=30?2:3;}
}
