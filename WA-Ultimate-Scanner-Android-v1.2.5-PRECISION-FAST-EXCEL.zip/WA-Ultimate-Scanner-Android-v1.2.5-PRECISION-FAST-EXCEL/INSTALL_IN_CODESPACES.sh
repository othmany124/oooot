#!/usr/bin/env bash
set -euo pipefail
ZIP=$(find . -maxdepth 2 -name 'WA-Ultimate-Scanner-Android-v1.2.5-PRECISION-FAST-EXCEL.zip' -print -quit)
if [ -z "$ZIP" ]; then echo 'ارفع ملف v1.2.5 ZIP إلى المستودع أولاً'; exit 1; fi
mkdir -p /tmp/wa-scanner-v125
unzip -oq "$ZIP" -d /tmp/wa-scanner-v125
PROJECT=$(find /tmp/wa-scanner-v125 -name settings.gradle -type f -print -quit)
test -n "$PROJECT"
DIR=$(dirname "$PROJECT")
mkdir -p .github/workflows
cp "$DIR/.github/workflows/build-apk.yml" .github/workflows/build-apk.yml
cp "$DIR/setup-signing-codespaces.sh" ./setup-signing-codespaces.sh
chmod 700 ./setup-signing-codespaces.sh
# Do not silently generate a new signing key: it would prevent installing over an older build.
if command -v gh >/dev/null 2>&1 && gh secret list --json name -q '.[].name' 2>/dev/null | grep -qx WA_KEYSTORE_BASE64; then
  echo 'مفتاح التوقيع المستقر موجود. تأكد من أنه نفس مفتاح التطبيق المثبت.'
else
  echo 'تحذير: مفتاح التوقيع غير موجود أو يتعذر التحقق منه.'
  echo 'إذا سبق تثبيت التطبيق، يجب إضافة نفس مفتاح توقيعه إلى GitHub Secrets.'
  echo 'لن ننشئ مفتاحاً جديداً تلقائياً؛ راجع UPDATE_AND_SIGNING_AR.md.'
fi
git add .github/workflows/build-apk.yml "$ZIP"
if ! git diff --cached --quiet; then
  git commit -m 'Upgrade scanner v1.2.5 precision and XLSX export'
  git push
fi
printf '\nتم إعداد مسار البناء. افتح GitHub Actions وتحقق من نجاح APK وتطابق توقيعه.\n'
