#!/usr/bin/env bash
set -euo pipefail
if ! gh auth status >/dev/null 2>&1; then echo 'Run gh auth login first'; exit 1; fi
if ! command -v keytool >/dev/null; then echo 'Java keytool missing'; exit 1; fi
REPO=$(gh repo view --json nameWithOwner -q .nameWithOwner)
for name in WA_KEYSTORE_BASE64 WA_STORE_PASSWORD WA_KEY_ALIAS WA_KEY_PASSWORD; do
  if gh secret list --repo "$REPO" --json name -q '.[].name' | grep -qx "$name"; then
    echo "Signing secrets already exist: $name. Do NOT replace them if you already installed an APK."
    exit 1
  fi
done
umask 077
DIR="$HOME/.wa-scanner-signing"
mkdir -p "$DIR"
KEY="$DIR/wa-scanner.jks"
if [ -f "$KEY" ]; then echo "Existing key at $KEY: keep using it, do not regenerate"; exit 1; fi
PASSWORD=$(openssl rand -hex 20)
keytool -genkeypair -keystore "$KEY" -storetype PKCS12 -alias wa_scanner \
  -keyalg RSA -keysize 3072 -validity 10000 -storepass "$PASSWORD" \
  -keypass "$PASSWORD" -dname 'CN=WA Ultimate Scanner, O=Personal, C=US' -noprompt
base64 -w0 "$KEY" | gh secret set WA_KEYSTORE_BASE64 --repo "$REPO"
printf '%s' "$PASSWORD" | gh secret set WA_STORE_PASSWORD --repo "$REPO"
printf '%s' "$PASSWORD" | gh secret set WA_KEY_PASSWORD --repo "$REPO"
printf '%s' wa_scanner | gh secret set WA_KEY_ALIAS --repo "$REPO"
echo "Stable signing secrets configured for $REPO."
echo "BACK UP $KEY privately before Codespaces is deleted. Never commit it."
echo 'IMPORTANT: APKs already installed with a DIFFERENT key cannot be overwritten.'
