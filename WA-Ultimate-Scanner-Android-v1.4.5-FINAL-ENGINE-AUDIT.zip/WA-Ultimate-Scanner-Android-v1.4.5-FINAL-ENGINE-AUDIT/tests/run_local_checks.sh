#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
SRC="$ROOT/app/src/main/java/com/waultimate/scanner"
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" "$SRC/PreviewParser.java" "$SRC/NavigationPolicy.java" \
 "$SRC/QueuePlanner.java" "$ROOT/tests/PreviewParserTest.java" "$ROOT/tests/ClassificationModelTest.java" \
 "$ROOT/tests/NavigationEngineTest.java" "$ROOT/tests/FullFlowSimulationTest.java" \
 "$ROOT/tests/SyntaxCheck.java"
java -cp "$OUT" SyntaxCheck "$SRC"
java -cp "$OUT" com.waultimate.scanner.PreviewParserTest
java -cp "$OUT" com.waultimate.scanner.ClassificationModelTest
java -cp "$OUT" com.waultimate.scanner.NavigationEngineTest
java -cp "$OUT" com.waultimate.scanner.FullFlowSimulationTest
# Static export-contract checks: required sheets must stay separated and workflow package must match v1.4.5.
grep -q 'قروبات موافقة' "$SRC/ExcelExporter.java"
grep -q 'قروبات بدون موافقة' "$SRC/ExcelExporter.java"
grep -q 'المجتمعات' "$SRC/ExcelExporter.java"
grep -q 'القنوات' "$SRC/ExcelExporter.java"
grep -q 'com.waultimate.scanner.v145' "$ROOT/.github/workflows/build-apk.yml"
echo "PASS Excel classification contract + v1.4.5 workflow package"
