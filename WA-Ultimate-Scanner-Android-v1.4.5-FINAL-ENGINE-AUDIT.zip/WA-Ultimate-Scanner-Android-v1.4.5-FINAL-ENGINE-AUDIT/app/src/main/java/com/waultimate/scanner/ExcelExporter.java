package com.waultimate.scanner;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/** RTL XLSX v1.4.5: strict approval/direct/community/channel routing with URL de-duplication. */
public final class ExcelExporter {
  private static final String[] NAMES={"الملخص","قروبات موافقة","قروبات بدون موافقة","المجتمعات","القنوات","غير محسوم","غير شغالة"};
  private ExcelExporter(){}
  private static String esc(String s){if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
  private static String col(int n){String s="";while(n>0){n--;s=(char)('A'+n%26)+s;n/=26;}return s;}
  private static void c(StringBuilder b,int x,int y,String v,int style){b.append("<c r=\"").append(col(x)).append(y).append("\" s=\"").append(style).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(v)).append("</t></is></c>");}
  private static void row(StringBuilder b,int y,String[] v,boolean head){b.append("<row r=\"").append(y).append("\" ht=\"").append(head?28:24).append("\" customHeight=\"1\">");for(int i=0;i<v.length;i++)c(b,i+1,y,v[i],head?1:(y%2==0?2:3));b.append("</row>");}
  private static String time(long t){return t==0?"":new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(t));}
  private static String cls(JSONObject o){
    String s=o.optString("status");
    if(("PENDING".equals(s)||"RETRY".equals(s)||"UNRESOLVED".equals(s))&&!o.optString("observedStatus").isEmpty()){
      String observed=o.optString("observedStatus");
      if("DIRECT".equals(observed)||"APPROVAL".equals(observed)||"COMMUNITY".equals(observed)||"CHANNEL".equals(observed))return observed;
    }
    return s;
  }
  private static int accuracy(JSONObject o){int a=o.optInt("accuracy");return a>0?a:o.optInt("observedAccuracy");}
  private static long resultTime(JSONObject o){long t=o.optLong("scannedAt");return t>0?t:o.optLong("observedAt");}
  private static boolean group(JSONObject o){String s=cls(o);return "DIRECT".equals(s)||"APPROVAL".equals(s);}
  private static String join(JSONObject o){return "APPROVAL".equals(o.optString("joinType"))||"APPROVAL".equals(cls(o))?"موافقة":"بدون موافقة";}
  private static long exact(JSONObject o){try{return Long.parseLong(o.optString("members",""));}catch(Exception e){return -1;}}
  private static long approx(JSONObject o){try{return Long.parseLong(o.optString("approximateCount",""));}catch(Exception e){return -1;}}
  private static String exactText(JSONObject o,String expected){return expected.equals(o.optString("countType"))?o.optString("members",""):"";}
  private static String approxText(JSONObject o,String expected){return expected.equals(o.optString("countType"))?o.optString("approximateCount",""):"";}
  private static String acc(JSONObject o){int a=accuracy(o);return a>0?a+"%":"";}
  private static String displayName(JSONObject o,String fallback){String n=o.optString("name").trim();return n.isEmpty()?fallback:n;}
  private static String visibleCount(JSONObject o,String expected){String e=exactText(o,expected);if(!e.isEmpty())return e;String a=approxText(o,expected);return a.isEmpty()?"":"+"+a;}
  private static String[] groupRow(JSONObject o,int n){return new String[]{""+n,o.optString("url"),displayName(o,"الاسم غير ظاهر"),join(o),exactText(o,"MEMBERS"),approxText(o,"MEMBERS").isEmpty()?"":"+"+approxText(o,"MEMBERS"),visibleCount(o,"MEMBERS"),o.optString("creator"),o.optString("creationDate"),time(resultTime(o)),acc(o),o.optString("evidence"),o.optString("note")};}
  private static String[] communityRow(JSONObject o,int n){return new String[]{""+n,o.optString("url"),displayName(o,"اسم المجتمع غير ظاهر"),exactText(o,"SUBGROUPS"),approxText(o,"SUBGROUPS"),visibleCount(o,"SUBGROUPS"),o.optString("creator"),o.optString("creationDate"),time(resultTime(o)),acc(o),o.optString("note")};}
  private static String[] channelRow(JSONObject o,int n){return new String[]{""+n,o.optString("url"),displayName(o,"اسم القناة غير ظاهر"),exactText(o,"FOLLOWERS"),visibleCount(o,"FOLLOWERS"),o.optString("creator"),o.optString("creationDate"),time(resultTime(o)),acc(o),o.optString("note")};}
  private static String[] unresolvedRow(JSONObject o,int n){return new String[]{""+n,o.optString("url"),o.optString("name"),o.optString("status"),ScanStore.effectiveStatus(o),o.optString("joinType"),exactText(o,o.optString("countType")),approxText(o,o.optString("countType")).isEmpty()?"":"+"+approxText(o,o.optString("countType")),o.optString("countType"),o.optString("countPrecision"),o.optString("creator"),o.optString("creationDate"),""+o.optInt("attempts"),time(o.optLong("observedAt")>0?o.optLong("observedAt"):o.optLong("scannedAt")),o.optString("note"),o.optString("evidence")};}
  private static String[] invalidRow(JSONObject o,int n){return new String[]{""+n,o.optString("url"),""+o.optInt("attempts"),time(resultTime(o)),acc(o),o.optString("note")};}
  private static void cols(StringBuilder b,int[] w){b.append("<cols>");for(int i=0;i<w.length;i++)b.append("<col min=\"").append(i+1).append("\" max=\"").append(i+1).append("\" width=\"").append(w[i]).append("\" customWidth=\"1\"/>");b.append("</cols>");}
  private static List<JSONObject> select(JSONArray a,int which){
    LinkedHashMap<String,JSONObject> unique=new LinkedHashMap<>();
    for(int i=0;i<a.length();i++){
      JSONObject o=a.optJSONObject(i);if(o==null)continue;
      String finalState=o.optString("status"), c=cls(o), url=o.optString("url");
      boolean ok=(which==1&&"APPROVAL".equals(c))
          ||(which==2&&"DIRECT".equals(c))
          ||(which==3&&"COMMUNITY".equals(c))
          ||(which==4&&"CHANNEL".equals(c))
          ||(which==5&&("UNRESOLVED".equals(finalState)||"RETRY".equals(finalState))
              &&!("DIRECT".equals(c)||"APPROVAL".equals(c)||"COMMUNITY".equals(c)||"CHANNEL".equals(c)))
          ||(which==6&&"INVALID".equals(finalState));
      if(ok&&!url.isEmpty())unique.put(url,o);
    }
    List<JSONObject> out=new ArrayList<>(unique.values());
    if(which==1||which==2)out.sort((a1,b1)->{
      int e=Long.compare(exact(b1),exact(a1));if(e!=0)return e;
      int ap=Long.compare(approx(b1),approx(a1));if(ap!=0)return ap;
      return displayName(a1,"").compareToIgnoreCase(displayName(b1,""));
    });
    return out;
  }
  private static String sheet(JSONArray a,int which){
    StringBuilder b=new StringBuilder(7000+a.length()*520);
    b.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
    if(which==0){
      cols(b,new int[]{34,16});b.append("<sheetData>");
      row(b,1,new String[]{"التصنيف","العدد"},true);
      String[] names={"قروبات موافقة","قروبات بدون موافقة","المجتمعات","القنوات","غير محسوم","غير شغالة","معلق/إعادة"};
      int[] n=new int[7];
      for(int i=0;i<a.length();i++){
        JSONObject o=a.optJSONObject(i);if(o==null)continue;
        String s=o.optString("status"),c=cls(o);
        if("APPROVAL".equals(c))n[0]++;
        else if("DIRECT".equals(c))n[1]++;
        else if("COMMUNITY".equals(c))n[2]++;
        else if("CHANNEL".equals(c))n[3]++;
        else if("INVALID".equals(s))n[5]++;
        else if("UNRESOLVED".equals(s)||"RETRY".equals(s))n[4]++;
        else if("PENDING".equals(s))n[6]++;
      }
      for(int i=0;i<names.length;i++)row(b,i+2,new String[]{names[i],""+n[i]},false);
      row(b,10,new String[]{"إجمالي الروابط الفريدة",""+a.length()},true);
      b.append("</sheetData><autoFilter ref=\"A1:B8\"/>");
    } else {
      String[] head;int[] widths;
      if(which==1||which==2){
        head=new String[]{"#","الرابط","اسم القروب","نوع الانضمام","عدد الأعضاء الدقيق","+N الظاهر","العدد الظاهر","المنشئ","تاريخ الإنشاء","تاريخ الفحص","الدقة","الدليل","الملاحظات"};
        widths=new int[]{6,55,36,18,18,15,17,28,20,22,10,26,48};
      }else if(which==3){
        head=new String[]{"#","رابط المجتمع","اسم المجتمع","عدد القروبات","عدد تقريبي","العدد الظاهر","المنشئ","تاريخ الإنشاء","تاريخ الفحص","الدقة","الملاحظات"};
        widths=new int[]{6,55,36,18,15,17,28,20,22,10,48};
      }else if(which==4){
        head=new String[]{"#","رابط القناة","اسم القناة","عدد المتابعين","العدد الظاهر","المنشئ","تاريخ الإنشاء","تاريخ الفحص","الدقة","الملاحظات"};
        widths=new int[]{6,55,36,18,17,28,20,22,10,48};
      }else if(which==5){
        head=new String[]{"#","الرابط","الاسم المرصود","حالة الطابور","التصنيف المرصود","نوع الانضمام","العدد الدقيق","+N الظاهر","نوع العدد","دقة العدد","المنشئ","تاريخ الإنشاء","المحاولات","آخر رصد","السبب","الدليل"};
        widths=new int[]{6,55,32,14,18,18,16,15,16,16,26,20,12,22,48,28};
      }else{
        head=new String[]{"#","الرابط","المحاولات","تاريخ الفحص","الدقة","سبب عدم العمل"};
        widths=new int[]{6,55,12,22,10,60};
      }
      cols(b,widths);b.append("<sheetData>");row(b,1,head,true);
      List<JSONObject> rows=select(a,which);int y=2,n=1;
      for(JSONObject o:rows){
        String[] rec=(which==1||which==2)?groupRow(o,n):which==3?communityRow(o,n):which==4?channelRow(o,n):which==5?unresolvedRow(o,n):invalidRow(o,n);
        row(b,y++,rec,false);n++;
      }
      b.append("</sheetData><autoFilter ref=\"A1:").append(col(head.length)).append(Math.max(1,y-1)).append("\"/>");
    }
    return b.append("</worksheet>").toString();
  }
  private static String workbook(){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");for(int i=0;i<NAMES.length;i++)b.append("<sheet name=\"").append(esc(NAMES[i])).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");return b.append("</sheets></workbook>").toString();}
  private static String rels(){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");for(int i=0;i<NAMES.length;i++)b.append("<Relationship Id=\"rId").append(i+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i+1).append(".xml\"/>");b.append("<Relationship Id=\"rId").append(NAMES.length+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");return b.toString();}
  private static String types(){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");for(int i=1;i<=NAMES.length;i++)b.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");return b.append("</Types>").toString();}
  private static final String STYLES="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Arial\"/></font></fonts><fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF075E45\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE9F5F0\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"4\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" applyFill=\"1\" applyFont=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\" borderId=\"0\" applyFill=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellXfs></styleSheet>";
  private static void add(ZipOutputStream z,String name,String body)throws IOException{z.putNextEntry(new ZipEntry(name));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
  public static void write(OutputStream out,JSONArray a)throws IOException{try(ZipOutputStream z=new ZipOutputStream(out)){add(z,"[Content_Types].xml",types());add(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");add(z,"xl/workbook.xml",workbook());add(z,"xl/_rels/workbook.xml.rels",rels());add(z,"xl/styles.xml",STYLES);for(int i=0;i<NAMES.length;i++)add(z,"xl/worksheets/sheet"+(i+1)+".xml",sheet(a,i));z.finish();}}
}
