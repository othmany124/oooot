package com.waultimate.scanner;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * v1.4.5 structured evidence parser with aggressive Samsung/OneUI structural-label rejection.
 *
 * Rules:
 *  - INVALID is emitted ONLY when WhatsApp exposes an explicit invalid/expired/reset message.
 *  - Group/member, community/subgroup and channel/follower counts are never cross-assigned.
 *  - +N avatar overflow is stored as APPROXIMATE evidence, never as an exact member count.
 *  - Embedded URLs/description text are not allowed to replace the invitation title.
 */
public final class PreviewParser {
  static final class Result {
    String status="UNRESOLVED", name="", members="", approximateCount="", countPrecision="UNKNOWN",
        joinType="UNKNOWN", countType="UNKNOWN", creationDate="", creator="",
        note="لا تكفي معلومات المعاينة", evidence="";
    int accuracy=0;
    boolean rateLimited=false;
  }

  private static final String[] INVALID={
      "invite link has been reset","invite link is invalid","this invite link is invalid",
      "invite link has expired","invite link is no longer valid","this link is no longer valid",
      "couldn't find this group","can't find this group","group doesn't exist","group does not exist",
      "invalid invite","expired invite",
      "رابط الدعوة غير صالح","تم إعادة تعيين رابط الدعوة","تم تغيير رابط الدعوة",
      "انتهت صلاحية رابط الدعوة","تعذر العثور على المجموعة","المجموعة غير موجودة",
      "هذا الرابط لم يعد صالحا","هذا الرابط لم يعد صالحًا","رابط غير صالح"
  };
  private static final String[] LIMIT={
      "try again later","too many requests","please wait before trying",
      "حاول مرة أخرى لاحقًا","طلبات كثيرة","يرجى المحاولة لاحقاً","يرجى المحاولة لاحقا"
  };
  private static final String[] APPROVAL={
      "request to join","ask to join","request approval","approval required",
      "طلب الانضمام","طلب الموافقة","موافقة المشرف","موافقة المسؤول"
  };
  private static final String[] GROUP_ACTION={
      "join group","join","الانضمام إلى المجموعة","انضم إلى المجموعة","انضم","الانضمام"
  };
  private static final String[] COMMUNITY_ACTION={
      "join community","community invite","whatsapp community",
      "الانضمام إلى المجتمع","دعوة إلى مجتمع","مجتمع واتساب"
  };
  private static final String[] CHANNEL_ACTION={
      "join channel","follow channel","channel invite","whatsapp channel",
      "متابعة القناة","الانضمام إلى القناة","دعوة إلى قناة","قناة واتساب"
  };
  private static final String[] MEMBER_UNITS={
      "members","member","participants","participant","عضو","أعضاء","الأعضاء","عضوا","عضوًا","عضواً",
      "مشارك","مشاركون","مشاركًا","مشاركاً","المشاركون"
  };
  private static final String[] FOLLOWER_UNITS={
      "followers","follower","subscribers","subscriber","متابع","متابعون","متابعًا","متابعاً",
      "المتابعون","مشترك","مشتركون","مشتركين","المشتركون"
  };
  private static final String[] SUBGROUP_UNITS={
      "groups","group","subgroups","subgroup","قروب","قروبات","مجموعة","مجموعات"
  };
  private static final String[] CREATOR_KEYS={
      "created by","created by:","created on","created at",
      "أنشأها","انشأها","أنشأه","انشأه","أنشئت بواسطة","انشئت بواسطة","تم الإنشاء بواسطة","تم الانشاء بواسطة"
  };
  private static final String[] CREATION_KEYS={
      "created on","created at","created","تاريخ الإنشاء","تاريخ الانشاء","تم الإنشاء","تم الانشاء",
      "أُنشئت","انشئت","أنشئت","أنشأها","انشأها","أنشأه","انشأه","تأسست","تأسس"
  };
  private static final String[] IGNORE_EXACT={
      "whatsapp","cancel","إلغاء","إلغاء الأمر","close","dismiss","x","×","✕","✖","إغلاق","اغلاق","إغلاق النافذة","اغلاق النافذة","زر إغلاق","زر اغلاق","مقبض السحب","اسحب","سحب",
      "join group","join community","join channel","follow channel","request to join","ask to join","join","follow",
      "الانضمام إلى المجموعة","انضم إلى المجموعة","الانضمام إلى المجتمع","متابعة القناة","الانضمام إلى القناة",
      "طلب الانضمام","طلب الموافقة","مجموعة واتساب","دعوة للانضمام","group invite","invite to group",
      "channel invite","community invite","دعوة إلى قناة","دعوة إلى مجتمع","members","member","participants",
      "participant","followers","subscribers","مشارك","مشاركون","الأعضاء","الأعضاء:","group info","المعلومات",
      "معلومات المجموعة","back","رجوع","report","إبلاغ","ok","موافق","فتح بواسطة","open with",
      "read more","see more","more","قراءة المزيد","عرض المزيد","المزيد","مزيد","group icon","profile photo",
      "group photo","صورة المجموعة","صورة الملف الشخصي","search","search…","search...","بحث","بحث…","بحث...",
      "new chat","دردشة جديدة","chats","الدردشات","whatsapp business","whatsapp messenger","واتساب للأعمال","واتساب",
      "dialog","bottom sheet","sheet","sheet container","menu","button","image","icon","avatar","group avatar",
      "نافذة","ورقة سفلية","حاوية","زر","أيقونة","ايقونة","صورة"
  };

  private static String clean(String v){return v==null?"":v.replace('\u200f',' ').replace('\u200e',' ').trim().replaceAll("\\s+"," ");}
  private static boolean has(String haystack,String[] needles){String s=haystack.toLowerCase(Locale.ROOT);for(String n:needles)if(s.contains(n.toLowerCase(Locale.ROOT)))return true;return false;}
  private static boolean equalsAny(String value,String[] options){String s=clean(value).toLowerCase(Locale.ROOT);for(String o:options)if(s.equals(o.toLowerCase(Locale.ROOT)))return true;return false;}
  private static boolean decimal(char c){return c==','||c=='٬'||c=='،'||c=='.';}
  private static String asciiDigits(String value){StringBuilder b=new StringBuilder();for(int i=0;i<value.length();i++){int d=Character.digit(value.charAt(i),10);if(d>=0)b.append((char)('0'+d));}return b.toString();}
  private static boolean onlyNumber(String value){String s=clean(value);if(s.isEmpty())return false;boolean digit=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0){digit=true;continue;}if(decimal(c)||Character.isWhitespace(c))continue;return false;}return digit;}
  private static boolean plusNumber(String value){String s=clean(value);if(s.length()<2||s.charAt(0)!='+')return false;boolean digit=false;for(int i=1;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0){digit=true;continue;}if(Character.isWhitespace(c)||decimal(c))continue;return false;}return digit;}
  private static boolean containsUnit(String value,String[] units){String s=clean(value).toLowerCase(Locale.ROOT);for(String unit:units){String u=unit.toLowerCase(Locale.ROOT);if(s.equals(u)||s.startsWith(u+" ")||s.endsWith(" "+u)||s.contains(" "+u+" ")||s.contains("من "+u))return true;}return false;}
  private static String countTypeFor(String value){if(containsUnit(value,FOLLOWER_UNITS))return "FOLLOWERS";if(containsUnit(value,SUBGROUP_UNITS))return "SUBGROUPS";if(containsUnit(value,MEMBER_UNITS))return "MEMBERS";return "UNKNOWN";}
  private static String expectedCount(boolean channel,boolean community){return channel?"FOLLOWERS":community?"SUBGROUPS":"MEMBERS";}

  private static String[] inlineCount(String value){
    String s=clean(value).toLowerCase(Locale.ROOT);if(s.isEmpty()||plusNumber(s))return null;
    int begin=-1;for(int i=0;i<s.length();i++)if(Character.digit(s.charAt(i),10)>=0){begin=i;break;}if(begin<0)return null;
    int end=begin;while(end<s.length()){char c=s.charAt(end);if(Character.digit(c,10)>=0||decimal(c)||Character.isWhitespace(c)){end++;continue;}break;}
    String number=asciiDigits(s.substring(begin,end));if(number.isEmpty())return null;
    String unit=(clean(s.substring(0,begin))+" "+clean(s.substring(end))).trim();
    String type=countTypeFor(unit);return "UNKNOWN".equals(type)?null:new String[]{number,type};
  }

  private static boolean dateLike(String value){
    String s=clean(value);int digits=0,seps=0;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0)digits++;else if(c=='/'||c=='-'||c=='.')seps++;}
    if(digits>=6&&seps>=2)return true;
    String low=s.toLowerCase(Locale.ROOT);String[] months={"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec","يناير","فبراير","مارس","أبريل","ابريل","مايو","يونيو","يوليو","أغسطس","اغسطس","سبتمبر","أكتوبر","اكتوبر","نوفمبر","ديسمبر"};for(String m:months)if(low.contains(m)&&digits>=2)return true;return false;
  }
  private static int dateStart(String value){
    String s=clean(value);for(int start=0;start<s.length();start++){if(Character.digit(s.charAt(start),10)<0)continue;int digits=0,seps=0;for(int i=start;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0)digits++;else if(c=='/'||c=='-'||c=='.')seps++;else if(Character.isWhitespace(c)){if(digits>0)continue;}else if(digits>0)break;if(digits>=6&&seps>=2)return start;}}return -1;
  }
  private static String extractDate(String value){
    String s=clean(value);int start=dateStart(s);if(start>=0){StringBuilder b=new StringBuilder();int digits=0,seps=0;for(int i=start;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0){int d=Character.digit(c,10);b.append((char)('0'+d));digits++;}else if(c=='/'||c=='-'||c=='.'){b.append(c);seps++;}else if(Character.isWhitespace(c)){if(digits>0)b.append(' ');}else if(digits>0)break;}if(digits>=6&&seps>=2)return clean(b.toString());}return dateLike(s)?s:"";
  }
  private static String creatorFrom(String value){
    String original=clean(value), low=original.toLowerCase(Locale.ROOT);int pos=-1,len=0;
    for(String key:CREATOR_KEYS){int p=low.indexOf(key.toLowerCase(Locale.ROOT));if(p>=0&&(pos<0||p<pos)){pos=p;len=key.length();}}
    if(pos<0)return "";String after=clean(original.substring(pos+len));while(after.startsWith(":")||after.startsWith("-")||after.startsWith("،")||after.startsWith(","))after=clean(after.substring(1));
    int dpos=dateStart(after);if(dpos>=0)after=clean(after.substring(0,dpos));
    String lower=after.toLowerCase(Locale.ROOT);int on=lower.lastIndexOf(" on ");if(on>0)after=clean(after.substring(0,on));int fi=after.lastIndexOf(" في ");if(fi>0)after=clean(after.substring(0,fi));
    while(after.endsWith("،")||after.endsWith(",")||after.endsWith("-")||after.endsWith("•"))after=clean(after.substring(0,after.length()-1));return after;
  }
  private static boolean creationLine(String value){String s=clean(value).toLowerCase(Locale.ROOT);for(String k:CREATION_KEYS)if(s.contains(k.toLowerCase(Locale.ROOT)))return true;return false;}
  private static String creationDate(List<String> parts){for(String p:parts)if(creationLine(p)){String d=extractDate(p);if(!d.isEmpty())return d;}for(String p:parts)if(dateLike(p))return extractDate(p);return "";}
  private static String creator(List<String> parts){for(String p:parts){String c=creatorFrom(p);if(!c.isEmpty())return c;}return "";}

  private static boolean ignoredTitle(String value){
    String s=clean(value), low=s.toLowerCase(Locale.ROOT);if(s.length()<2||s.length()>120)return true;
    if(low.startsWith("http")||low.contains("chat.whatsapp.com")||low.contains("whatsapp.com/channel/"))return true;
    if(equalsAny(low,IGNORE_EXACT)||onlyNumber(s)||plusNumber(s)||inlineCount(s)!=null||creationLine(s)||dateLike(s))return true;
    if(low.startsWith("created by")||low.startsWith("created on")||low.startsWith("أنشأها")||low.startsWith("انشأها"))return true;
    // Samsung/OneUI exposes structural accessibility labels that are not entity titles.
    if(low.contains("مقبض السحب")||low.equals("إغلاق")||low.equals("اغلاق")||low.startsWith("زر إغلاق")||low.startsWith("زر اغلاق"))return true;
    if(low.equals("close button")||low.equals("drag handle")||low.equals("sheet handle"))return true;
    return false;
  }
  private static boolean titleCandidate(String value){if(ignoredTitle(value))return false;String s=clean(value);int letters=0;for(int i=0;i<s.length();i++)if(Character.isLetter(s.charAt(i)))letters++;return letters>=2;}
  private static boolean actionText(String value){String s=clean(value).toLowerCase(Locale.ROOT);return has(s,APPROVAL)||has(s,GROUP_ACTION)||has(s,COMMUNITY_ACTION)||has(s,CHANNEL_ACTION);}
  private static int actionIndex(List<String> parts){for(int i=0;i<parts.size();i++)if(actionText(parts.get(i)))return i;return parts.size();}
  private static int creatorIndex(List<String> parts,int before){for(int i=0;i<Math.min(before,parts.size());i++)if(creationLine(parts.get(i))||!creatorFrom(parts.get(i)).isEmpty())return i;return -1;}
  private static int metadataIndex(List<String> parts,int before){
    int limit=Math.min(before,parts.size());
    for(int i=0;i<limit;i++){
      String v=parts.get(i);
      if(creationLine(v)||dateLike(v)||plusNumber(v)||inlineCount(v)!=null||!creatorFrom(v).isEmpty())return i;
    }
    return -1;
  }
  private static int titleScore(String value,int index,int anchor,int action){
    if(!titleCandidate(value))return Integer.MIN_VALUE;
    String s=clean(value), low=s.toLowerCase(Locale.ROOT);
    int score=0;
    int len=s.length();
    if(len>=3&&len<=60)score+=24;else if(len<=90)score+=12;else score-=20;
    int letters=0,digits=0;
    for(int i=0;i<s.length();i++){if(Character.isLetter(s.charAt(i)))letters++;else if(Character.digit(s.charAt(i),10)>=0)digits++;}
    score+=Math.min(20,letters);
    if(digits>0&&letters>0)score+=3;
    if(anchor>=0){
      int distance=Math.abs(anchor-index);
      score+=Math.max(0,52-distance*11);
      if(index<anchor)score+=10;else score-=20;
    }else if(action>=0){
      int distance=Math.abs(action-index);
      score+=Math.max(0,24-distance*3);
    }
    if(low.contains("description")||low.contains("الوصف")||low.contains("نبذة"))score-=25;
    if(low.contains("إغلاق")||low.contains("اغلاق")||low.contains("مقبض السحب")||low.equals("whatsapp"))score-=100;
    return score;
  }
  private static String chooseTitle(List<String> parts,int action){
    int limit=Math.min(action,parts.size());
    int anchor=metadataIndex(parts,limit);
    String best="";int bestScore=Integer.MIN_VALUE;
    for(int i=0;i<limit;i++){
      String candidate=clean(parts.get(i));
      int score=titleScore(candidate,i,anchor,action);
      if(score>bestScore){bestScore=score;best=candidate;}
    }
    return bestScore>0?best:"";
  }
  private static void exactCount(Result r,String number,String type,String expected){if(number.isEmpty()||!expected.equals(type)||!r.members.isEmpty())return;r.members=number;r.countType=type;r.countPrecision="EXACT";}
  private static int confidence(Result r){
    if("INVALID".equals(r.status))return 100;if("UNRESOLVED".equals(r.status))return 0;
    int score=80;if(!r.name.isEmpty())score+=10;if(!r.members.isEmpty())score+=5;else if(!r.approximateCount.isEmpty())score+=3;if(!r.creationDate.isEmpty())score+=3;if(!r.creator.isEmpty())score+=2;return Math.min(100,score);
  }

  static boolean isBadTitle(String value){ return ignoredTitle(value); }
  static Result parseWithForcedTitle(List<String> input,String sourceUrl,String forcedTitle){
    if(forcedTitle==null||!titleCandidate(forcedTitle))return parse(input,sourceUrl);
    List<String> augmented=new ArrayList<>();augmented.add(clean(forcedTitle));if(input!=null)augmented.addAll(input);
    return parse(augmented,sourceUrl);
  }

  static Result parse(List<String> input){return parse(input,"");}
  static Result parse(List<String> input,String sourceUrl){
    Result r=new Result();if(input==null)return r;List<String> parts=new ArrayList<>();StringBuilder joined=new StringBuilder();
    for(String raw:input){String v=clean(raw);if(v.isEmpty())continue;if(!parts.contains(v))parts.add(v);joined.append(v.toLowerCase(Locale.ROOT)).append('\n');}
    String all=joined.toString();
    if(has(all,LIMIT)){r.rateLimited=true;r.note="رُصد تقييد/طلب تمهل من واتساب";r.evidence="RATE_LIMIT";return r;}
    if(has(all,INVALID)){r.status="INVALID";r.joinType="INVALID";r.accuracy=100;r.note="واتساب عرض رسالة صريحة بأن رابط الدعوة غير صالح أو منتهي أو تم تغييره";r.evidence="EXPLICIT_INVALID";return r;}

    String url=sourceUrl==null?"":sourceUrl.toLowerCase(Locale.ROOT);
    boolean approval=has(all,APPROVAL);
    boolean channelEvidence=has(all,CHANNEL_ACTION);
    boolean communityEvidence=has(all,COMMUNITY_ACTION);
    boolean groupEvidence=approval||has(all,GROUP_ACTION);
    boolean channelUrl=url.contains("whatsapp.com/channel/");
    boolean groupUrl=url.contains("chat.whatsapp.com/");
    boolean channel=channelEvidence&&(channelUrl||url.isEmpty());
    boolean community=!channel&&communityEvidence;
    if(groupUrl&&!community)channel=false;
    if(!channel&&!community&&!groupEvidence){r.note="لم يظهر زر دعوة أو دليل كافٍ على معاينة واتساب";r.evidence="NO_INVITE_ACTION";return r;}

    r.status=channel?"CHANNEL":community?"COMMUNITY":approval?"APPROVAL":"DIRECT";
    r.joinType=channel?"FOLLOW":community?"COMMUNITY":approval?"APPROVAL":"DIRECT";
    int action=actionIndex(parts);r.name=chooseTitle(parts,action);r.creator=creator(parts);r.creationDate=creationDate(parts);
    String expected=expectedCount(channel,community);

    for(String p:parts){String[] c=inlineCount(p);if(c!=null)exactCount(r,c[0],c[1],expected);}
    for(int i=0;i<parts.size()&&r.members.isEmpty();i++)if(onlyNumber(parts.get(i))){String n=asciiDigits(parts.get(i));for(int distance=1;distance<=3;distance++){int a=i-distance,b=i+distance;if(a>=0){String type=countTypeFor(parts.get(a));if(expected.equals(type)){exactCount(r,n,type,expected);break;}}if(b<parts.size()){String type=countTypeFor(parts.get(b));if(expected.equals(type)){exactCount(r,n,type,expected);break;}}}}
    if(r.members.isEmpty()&&!channel){for(int i=0;i<Math.min(action,parts.size());i++)if(plusNumber(parts.get(i))){String n=asciiDigits(parts.get(i));if(!n.isEmpty()){r.approximateCount=n;r.countType=expected;r.countPrecision="APPROXIMATE";break;}}}

    if(r.name.isEmpty()){
      r.status="UNRESOLVED";r.joinType="UNKNOWN";r.note="ظهرت معاينة دعوة لكن لم يمكن تثبيت اسم الكيان؛ سيعاد فحص الرابط";r.evidence="ACTION_WITHOUT_TITLE";r.accuracy=0;return r;
    }
    r.accuracy=confidence(r);
    StringBuilder ev=new StringBuilder("TITLE+ACTION");if(!r.members.isEmpty())ev.append("+EXACT_COUNT");else if(!r.approximateCount.isEmpty())ev.append("+APPROX_COUNT");if(!r.creationDate.isEmpty())ev.append("+CREATION_DATE");if(!r.creator.isEmpty())ev.append("+CREATOR");r.evidence=ev.toString();
    if(channel)r.note=r.members.isEmpty()?"قناة مؤكدة؛ عدد المتابعين غير ظاهر":"قناة مؤكدة؛ عدد المتابعين ظاهر";
    else if(community)r.note=r.members.isEmpty()?(r.approximateCount.isEmpty()?"مجتمع مؤكد؛ عدد القروبات غير ظاهر":"مجتمع مؤكد؛ العدد الظاهر تقريبي"):"مجتمع مؤكد؛ عدد القروبات ظاهر";
    else r.note=r.members.isEmpty()?(r.approximateCount.isEmpty()?"قروب مؤكد؛ عدد الأعضاء غير ظاهر":"قروب مؤكد؛ +N قيمة تقريبية وليست إجماليًا دقيقًا"):"قروب مؤكد؛ عدد الأعضاء ظاهر";
    return r;
  }
}
