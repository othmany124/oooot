#!/usr/bin/env bash
# Run only after downloading/uploading v1.3.6 ZIP into repository root.
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
BRANCH=$(git branch --show-current)
test "$BRANCH" = main || { echo "Switch to main before installing"; exit 1; }
ZIP="WA-Ultimate-Scanner-Android-v1.3.6-CLASSIFICATION-ENGINE.zip"
git pull --ff-only origin main
test -f "$ZIP" || { echo "ZIP missing in repository root: $ZIP"; exit 1; }
unzip -tq "$ZIP"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
unzip -oq "$ZIP" -d "$TMP"
SOURCE=$(find "$TMP" -path '*/.github/workflows/build-apk.yml' -type f -print -quit)
test -n "$SOURCE"
mkdir -p .github/workflows
cp "$SOURCE" .github/workflows/build-apk.yml
# Only commit the workflow: never commit logs, keys or other untracked user files.
git add .github/workflows/build-apk.yml
if git diff --cached --quiet; then
  git -c user.name='WA Scanner Builder' -c user.email='builder@users.noreply.github.com' \
    commit --allow-empty -m 'Run WA Scanner v1.3.6 build'
else
  git -c user.name='WA Scanner Builder' -c user.email='builder@users.noreply.github.com' \
    commit -m 'Build WA Scanner v1.3.6 classification engine'
fi
git push origin HEAD:main
echo 'WORKFLOW SUBMITTED: Open the GitHub Actions tab to monitor the build.'
