package com.waultimate.scanner;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * One invitation at a time: OPEN -> VERIFY -> SAVE -> DISMISS (X / Back) -> NEXT.
 * No automatic join action. An unverified UI never causes Back or an INVALID result.
 * All transition timers carry a generation; a previous link cannot finish the next link.
 */
public final class ScannerAccessibility extends AccessibilityService {
  public static ScannerAccessibility current;
  private enum Phase { IDLE, OPENING, VERIFYING, DISMISSING, WAITING_NEXT, PAUSED, COOLDOWN }
  private final Handler handler = new Handler(Looper.getMainLooper());
  private ScanStore store;
  private ScannerConfig config;
  private Phase phase = Phase.IDLE;
  private boolean running;
  private boolean intentionallyStopped;
  private int index = -1;
  private int attempt;
  private long generation;
  private long launchedAt;
  private long launchedUptime;
  private long lastRead;
  private int beforeWindow = -1;
  private String beforeFingerprint = "";
  private String targetPackage = "";
  private String candidate = "";
  private boolean sawNewWindow;
  private boolean sawWhatsAppEvent;
  private boolean previewVerified;
  private int missingStreak;
  private int stableSamples;
  private boolean stabilityGraceUsed;
  private String lastNavigation = "لم تبدأ دورة التنقل";
  private long lastWhatsAppEvent;
  private long eventCount;
  private long probeStarted;
  private int probeEvents, probeNodes;
  private String probePackage = "";
  private int dismissChecks;
  private boolean xWasTried, backWasTried;
  private static final int NO_PREVIEW_LIMIT = 4;
  private static final long[] COOLDOWN = {120000,300000,900000,1800000,3600000};

  public void beginProbe() {
    probeStarted = System.currentTimeMillis(); probeEvents = 0; probeNodes = 0; probePackage = "";
    DiagnosticsLog.add(this, "PROBE", "بدء اختبار استقبال أحداث واتساب");
  }
  public int probeEventCount() { return probeEvents; }
  public int probeNodeCount() { return probeNodes; }
  public String probeSummary() {
    return "أحداث واتساب: " + probeEvents + "\nعناصر مرئية: " + probeNodes
        + "\nالحزمة: " + (probePackage.isEmpty()?"لم ترصد":probePackage)
        + "\nنجاح معاينة الدعوة لا يُثبت بعدد الأحداث وحده.";
  }
  public boolean isScanning() { return running; }
  public boolean observedWhatsAppEvents() { return lastWhatsAppEvent > 0; }
  public String detectedWhatsAppPackage() { return selectedPackage(); }
  public String diagnostics() {
    return "حالة المحرك: " + phaseLabel() + "\nالرابط الجاري: "
        + (index < 0 ? "لا يوجد" : (index+1))
        + "\nآخر تنقل: " + lastNavigation
        + "\nالخدمة متصلة: " + (current==this?"نعم":"لا")
        + "\nأحداث واتساب: " + eventCount
        + "\nآخر حدث: " + (lastWhatsAppEvent==0?"لم يُرصد":((System.currentTimeMillis()-lastWhatsAppEvent)/1000)+" ثانية")
        + "\nمعاينة الرابط الحالي: " + (previewVerified?"تم تأكيدها":"لم تتأكد")
        + "\nمتتالية بدون معاينة: " + missingStreak;
  }
  public String phaseLabel(){
    switch(phase) {
      case OPENING: return "فتح الرابط";
      case VERIFYING: return "التحقق من المعاينة";
      case DISMISSING: return "إغلاق المعاينة";
      case WAITING_NEXT: return "الانتقال للتالي";
      case PAUSED: return "متوقف بأمان";
      case COOLDOWN: return "تهدئة واتساب";
      default: return "جاهز";
    }
  }
  public String lastNavigation(){return lastNavigation;}
  public int activeLinkNumber(){return index<0?0:index+1;}

  private String selectedPackage() {
    String p = getSharedPreferences("wa_target",MODE_PRIVATE).getString("package", "");
    if (!"com.whatsapp".equals(p) && !"com.whatsapp.w4b".equals(p)) return "";
    try { getPackageManager().getPackageInfo(p,0); return p; }
    catch (PackageManager.NameNotFoundException e) { return ""; }
  }
  private long timeoutMillis(){return (config==null?3:config.timeoutSeconds()) * 1000L;}
  private long gapMillis(){return Math.max(1000L,(config==null?1:config.gapSeconds())*1000L);}
  private void navigation(String message){lastNavigation=message;DiagnosticsLog.add(this,"NAV",message);}
  private static String fingerprint(List<String> labels){StringBuilder b=new StringBuilder();for(String s:labels)b.append(s).append('\u001f');return b.toString();}
  private boolean valid(long gen,int id){return NavigationPolicy.validCallback(running,gen,generation,id,index);}

  @Override public void onServiceConnected() {
    super.onServiceConnected();
    current=this;store=new ScanStore(this);config=new ScannerConfig(this);
    String previous=store.state();
    DiagnosticsLog.add(this,"ACCESSIBILITY","الخدمة متصلة؛ الحالة: "+previous+"؛ المعلق: "+store.pendingCount());
    if(CrashReporter.needsAcknowledgement(this)
        && ("RUNNING".equals(previous)||"RECOVERING".equals(previous))){
      phase=Phase.PAUSED;
      store.state("PAUSED","رُصد انهيار سابق؛ راجع سجل الانهيار قبل الاستئناف اليدوي");
      return;
    }
    if(("RUNNING".equals(previous)||"RECOVERING".equals(previous))&&store.pendingCount()>0){
      store.state("RECOVERING","استعادة الرابط غير المكتمل بعد اتصال Accessibility");
      safePost(950,"استعادة الجلسة",()->{
        if(current==this&&!running&&"RECOVERING".equals(store.state()))begin();
      });
    }
  }
  @Override public void onDestroy() {
    boolean owner = current==this;
    boolean interrupted = running;
    invalidateTimers();running=false;phase=Phase.IDLE;
    if(owner){
      if(interrupted&&!intentionallyStopped&&store!=null&&"RUNNING".equals(store.state()))
        store.state("RECOVERING","انقطعت الخدمة، وسيُعاد الرابط غير المكتمل");
      current=null;
    }
    super.onDestroy();
  }
  @Override public void onInterrupt() {
    DiagnosticsLog.add(this,"ACCESSIBILITY","onInterrupt؛ running="+running+"؛ الرابط="+(index<0?"—":(index+1)));
    if(running){invalidateTimers();running=false;phase=Phase.PAUSED;
      store.state("RECOVERING","انقطاع Accessibility؛ سيُستعاد الرابط نفسه عند عودة الخدمة");
    }
  }
  private void invalidateTimers(){generation++;handler.removeCallbacksAndMessages(null);}
  /** Scheduled callbacks cannot crash the app's main thread without a diagnostic. */
  private void safeRun(String stage,Runnable action){
    try{action.run();}
    catch(RuntimeException | LinkageError e){
      CrashReporter.recordHandled(this,e,stage);
      DiagnosticsLog.add(this,"ERROR",stage+": "+e.getClass().getSimpleName());
      pauseForFailure("خطأ في مرحلة "+stage+"؛ تم حفظ تقرير قابل للنسخ");
    }
  }
  private void safePost(long delay,String stage,Runnable action){
    handler.postDelayed(()->safeRun(stage,action),delay);
  }

  public void begin(){safeRun("بدء الفحص",this::startInternal);}
  private void startInternal(){
    if(store==null)store=new ScanStore(this);
    if(config==null)config=new ScannerConfig(this);
    if(running)return;
    if(store.pendingCount()==0){store.state("DONE","لا توجد روابط معلقة");return;}
    targetPackage=selectedPackage();
    if(targetPackage.isEmpty()){
      store.state("PAUSED","حدد واتساب الرسمي أو Business وثبّت التطبيق المختار");return;
    }
    intentionallyStopped=false;CrashReporter.acknowledge(this);
    if(!"RECOVERING".equals(store.state()))missingStreak=0;
    running=true;phase=Phase.IDLE;store.state("RUNNING","تم بدء فحص متسلسل؛ حفظ النتيجة قبل الرابط التالي");
    navigateNext();
  }
  public void stop(){
    DiagnosticsLog.add(this,"CONTROL","إيقاف يدوي للمحرك؛ الرابط="+(index<0?"—":(index+1))+"؛ المرحلة="+phaseLabel());
    intentionallyStopped=true;invalidateTimers();running=false;phase=Phase.PAUSED;
    if(store!=null)store.state("PAUSED","إيقاف يدوي؛ الرابط غير المكتمل محفوظ للاستكمال");
  }
  public void clear(){
    intentionallyStopped=true;invalidateTimers();running=false;phase=Phase.IDLE;index=-1;
    if(store!=null)store.clear();
  }

  private void navigateNext(){
    if(!running)return;
    int next=store.next();
    if(next<0){invalidateTimers();running=false;phase=Phase.IDLE;index=-1;
      store.state("DONE","اكتملت الروابط القابلة للمعالجة");return;}
    index=next;
    long wait=store.cooldownUntil()-System.currentTimeMillis();
    if(wait>0){phase=Phase.COOLDOWN;store.state("COOLDOWN","واتساب في فترة تهدئة");
      final long gen=generation;final int id=index;
      safePost(Math.max(1000L,wait),"نهاية التهدئة",()->{
        if(gen==generation&&running&&id==index){store.state("RUNNING","انتهت التهدئة");openCurrent();}
      });return;
    }
    openCurrent();
  }

  private void openCurrent(){
    if(!running||index<0)return;
    invalidateTimers();
    final long gen=generation;
    final int id=index;
    phase=Phase.OPENING;candidate="";stableSamples=0;stabilityGraceUsed=false;previewVerified=false;
    sawNewWindow=false;sawWhatsAppEvent=false;lastRead=0L;
    xWasTried=false;backWasTried=false;dismissChecks=0;
    launchedAt=System.currentTimeMillis();launchedUptime=SystemClock.uptimeMillis();
    beforeWindow=-1;beforeFingerprint="";
    AccessibilityNodeInfo prior=getRootInActiveWindow();
    if(prior!=null){
      try{beforeWindow=prior.getWindowId();List<String> labels=new ArrayList<>();collect(prior,labels,0);beforeFingerprint=fingerprint(labels);}
      finally{prior.recycle();}
    }
    org.json.JSONObject data=store.at(id);
    if(data==null){pauseForFailure("رابط غير موجود في قائمة الانتظار");return;}
    String url=data.optString("url","");
    // Persist attempt + in-flight ownership in ONE transaction before opening WhatsApp.
    attempt=store.claim(id);
    if(attempt<0){pauseForFailure("تعذر تثبيت نقطة استكمال الرابط قبل فتح واتساب");return;}
    store.state("RUNNING","فتح "+(id+1)+" / "+store.size()+"؛ مرحلة: التحقق من المعاينة");
    DiagnosticsLog.add(this,"OPEN","الرابط "+(id+1)+" / "+store.size()+"؛ مهلة "+(timeoutMillis()/1000)+" ثوانٍ");
    try {
      Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
      intent.setPackage(targetPackage);
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
      if(intent.resolveActivity(getPackageManager())==null){
        finishResult("INVALID","","","UNKNOWN","INVALID","",60,"الرابط لم يفتح في واتساب المختار");return;
      }
      startActivity(intent);
    }catch(RuntimeException e){
      DiagnosticsLog.add(this,"ERROR","فتح الرابط: "+e.getClass().getSimpleName());
      finishResult("INVALID","","","UNKNOWN","INVALID","",55,"تعذر فتح الرابط/المعاينة في واتساب");return;
    }
    phase=Phase.VERIFYING;
    for(long delay:new long[]{650,1250,2100}){
      safePost(delay,"قراءة المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)capture();});
    }
    safePost(timeoutMillis(),"مهلة المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)onTimeout();});
  }

  @Override public void onAccessibilityEvent(AccessibilityEvent event){
    if(event==null||event.getPackageName()==null)return;
    String pkg=event.getPackageName().toString();
    if(!"com.whatsapp".equals(pkg)&&!"com.whatsapp.w4b".equals(pkg))return;
    long now=System.currentTimeMillis();lastWhatsAppEvent=now;eventCount++;
    if(probeStarted>0&&now-probeStarted<=15000){
      probeEvents++;probePackage=pkg;
      AccessibilityNodeInfo root=getRootInActiveWindow();
      if(root!=null){try{
        if(root.getPackageName()!=null&&pkg.contentEquals(root.getPackageName())){
          List<String> l=new ArrayList<>();collect(root,l,0);probeNodes=Math.max(probeNodes,l.size());
        }
      }finally{root.recycle();}}
    }
    if(!running||!pkg.equals(targetPackage)||event.getEventTime()<launchedUptime)return;
    sawWhatsAppEvent=true;
    if(event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.getWindowId()!=beforeWindow)
      sawNewWindow=true;
    try{
      if(phase==Phase.VERIFYING)capture();
      else if(phase==Phase.DISMISSING)checkDismissed(generation,index);
    }catch(RuntimeException | LinkageError failure){
      CrashReporter.recordHandled(this,failure,"أحداث واتساب");
      DiagnosticsLog.add(this,"ERROR","واجهة واتساب: "+failure.getClass().getSimpleName());
      pauseForFailure("خطأ في قراءة/إغلاق المعاينة؛ افتح سجل الانهيار أو التشخيص");
    }
  }

  private void collect(AccessibilityNodeInfo node,List<String> labels,int depth){
    if(node==null||depth>25||labels.size()>=160)return;
    CharSequence text=node.getText(), description=node.getContentDescription();
    if(text!=null&&!text.toString().trim().isEmpty())labels.add(text.toString().trim());
    if(description!=null&&!description.toString().trim().isEmpty()
        &&(text==null||!description.toString().equals(text.toString())))labels.add(description.toString().trim());
    for(int i=0;i<node.getChildCount()&&labels.size()<160;i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){try{collect(child,labels,depth+1);}finally{child.recycle();}}
    }
  }
  private static String label(AccessibilityNodeInfo node){
    String text=node.getText()==null?"":node.getText().toString();
    String description=node.getContentDescription()==null?"":node.getContentDescription().toString();
    return (text+" "+description).trim().toLowerCase(Locale.ROOT);
  }
  private static boolean invitationAction(String text){
    return text.equals("join group")||text.equals("request to join")||text.equals("ask to join")
        ||text.equals("join community")||text.equals("follow channel")||text.equals("join channel")
        ||text.equals("انضم إلى المجموعة")||text.equals("الانضمام إلى المجموعة")
        ||text.equals("طلب الانضمام")||text.equals("الانضمام إلى المجتمع")
        ||text.equals("متابعة القناة")||text.equals("الانضمام إلى القناة");
  }
  private static boolean clickableNodeOrParent(AccessibilityNodeInfo node){
    if(node.isClickable())return true;
    AccessibilityNodeInfo parent=node.getParent();
    if(parent==null)return false;
    try{return parent.isClickable();}finally{parent.recycle();}
  }
  private boolean hasActionButton(AccessibilityNodeInfo node,int depth){
    if(node==null||depth>19)return false;
    String text=node.getText()==null?"":node.getText().toString().trim().toLowerCase(Locale.ROOT);
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString().trim().toLowerCase(Locale.ROOT);
    if((invitationAction(text)||invitationAction(desc))&&clickableNodeOrParent(node))return true;
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){boolean found;
        try{found=hasActionButton(child,depth+1);}finally{child.recycle();}
        if(found)return true;
      }
    }
    return false;
  }
  private boolean isPreview(AccessibilityNodeInfo root,List<String> labels){
    PreviewParser.Result parsed=PreviewParser.parse(labels);
    return ("INVALID".equals(parsed.status)&&labels.size()<=24)||hasActionButton(root,0);
  }
  private void capture(){
    if(!running||phase!=Phase.VERIFYING||index<0)return;
    long now=System.currentTimeMillis();
    if(now-launchedAt<550||now-lastRead<180||!sawWhatsAppEvent)return;
    lastRead=now;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    try{
      if(root.getPackageName()==null||!targetPackage.contentEquals(root.getPackageName()))return;
      List<String> labels=new ArrayList<>();collect(root,labels,0);
      String fp=fingerprint(labels);
      // Require a fresh event AND either a different window or changed visible content.
      if(!sawNewWindow&&fp.equals(beforeFingerprint))return;
      PreviewParser.Result parsed=PreviewParser.parse(labels);
      if(parsed.rateLimited){
        if(labels.size()<=24)onLimit();
        return;
      }
      if(!isPreview(root,labels))return;
      previewVerified=true;missingStreak=0;
      if("UNRESOLVED".equals(parsed.status))return;
      String signature=parsed.status+"|"+parsed.name+"|"+parsed.members+"|"+parsed.joinType;
      if(!signature.equals(candidate)){
        candidate=signature;stableSamples=1;
        long gen=generation;int id=index;
        safePost(360,"تأكيد ثبات المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)capture();});
      }else if(++stableSamples>=2){
        finishResult(parsed);
      }
    }finally{root.recycle();}
  }

  private void onTimeout(){
    if(!running||phase!=Phase.VERIFYING||index<0)return;
    if(previewVerified && !candidate.isEmpty() && stableSamples==1 && !stabilityGraceUsed){
      stabilityGraceUsed=true;
      final long gen=generation;final int id=index;
      safePost(650,"تمديد مهلة المعاينة",()->{if(valid(gen,id)&&phase==Phase.VERIFYING)onTimeout();});
      DiagnosticsLog.add(this,"PREVIEW","تمديد قصير لتأكيد ثبات المعاينة الظاهرة");
      return;
    }
    DiagnosticsLog.add(this,"PREVIEW","الرابط "+(index+1)+": معاينة مؤكدة="+previewVerified+"؛ أحداث="+sawWhatsAppEvent
        +"؛ المدة="+(System.currentTimeMillis()-launchedAt)+"ms");
    if(!previewVerified){
      missingStreak++;
      if(NavigationPolicy.shouldCircuitBreak(missingStreak,NO_PREVIEW_LIMIT))
        DiagnosticsLog.add(this,"GUARD","لم تظهر "+missingStreak+" معاينات متتالية؛ سيستمر المحرك مع إعادة المحاولة وتصنيف الرابط النهائي وفق النتيجة");
    }
    if(attempt<(config==null?2:config.retries())){
      if(!store.defer(index,"لم تثبت معاينة الدعوة؛ أُجّلت المحاولة دون اعتباره رابطًا غير صالح")){
        pauseForFailure("تعذر حفظ محاولة الرابط المؤجل");return;
      }
      DiagnosticsLog.add(this,"FLOW","حُفظ التأجيل؛ متابعة الرابط التالي");
      dismissThenNext();
    }else{
      finishResult("INVALID","","","UNKNOWN","INVALID","",55,"لم تظهر نتيجة/معاينة موثوقة بعد جميع المحاولات");
    }
  }
  private void finishResult(PreviewParser.Result parsed){
    finishResult(parsed.status,parsed.name,parsed.members,parsed.countType,parsed.joinType,parsed.creationDate,parsed.accuracy,parsed.note);
  }
  private void finishResult(String status,String name,String members,String countType,String joinType,String note){
    int accuracy="INVALID".equals(status)?60:((name!=null&&!name.isEmpty())?90:70);
    finishResult(status,name,members,countType,joinType,"",accuracy,note);
  }
  private void finishResult(String status,String name,String members,String countType,String joinType,String creationDate,int accuracy,String note){
    if(!running||index<0)return;
    if(!store.complete(index,status,name,members,countType,joinType,creationDate,accuracy,note)){
      pauseForFailure("تعذر حفظ النتيجة؛ لن نفتح الرابط التالي قبل حفظها");return;
    }
    if(!"UNRESOLVED".equals(status))missingStreak=0;
    DiagnosticsLog.add(this,"FLOW","حُفظت نتيجة الرابط "+(index+1)+"؛ الدقة="+accuracy+"%؛ المدة="
        +(System.currentTimeMillis()-launchedAt)+"ms؛ الانتقال لمرحلة الإغلاق");
    dismissThenNext();
  }

  private static boolean closeLabel(String text,boolean strictX){
    if(text==null)return false;
    String s=text.trim().toLowerCase(Locale.ROOT);
    if(s.equals("×")||s.equals("✕")||s.equals("✖")||s.equals("x")||s.equals("close")
        ||s.equals("dismiss")||s.equals("إغلاق")||s.equals("اغلاق"))return true;
    return !strictX&&(s.equals("cancel")||s.equals("إلغاء")||s.equals("الغاء"));
  }
  private boolean tapClose(AccessibilityNodeInfo node,int depth,boolean strictX){
    if(node==null||depth>19)return false;
    String text=node.getText()==null?"":node.getText().toString();
    String desc=node.getContentDescription()==null?"":node.getContentDescription().toString();
    if(closeLabel(text,strictX)||closeLabel(desc,strictX)){
      if(node.isClickable()&&node.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
      AccessibilityNodeInfo parent=node.getParent();
      if(parent!=null){try{
        if(parent.isClickable()&&parent.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
      }finally{parent.recycle();}}
    }
    for(int i=0;i<node.getChildCount();i++){
      AccessibilityNodeInfo child=node.getChild(i);
      if(child!=null){boolean clicked;
        try{clicked=tapClose(child,depth+1,strictX);}finally{child.recycle();}
        if(clicked)return true;
      }
    }
    return false;
  }
  private boolean tryX(AccessibilityNodeInfo root){return tapClose(root,0,true)||tapClose(root,0,false);}
  private void dismissThenNext(){
    if(!running)return;
    invalidateTimers();phase=Phase.DISMISSING;dismissChecks=0;xWasTried=false;backWasTried=false;
    final long gen=generation;final int id=index;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null){navigation("لا توجد نافذة معاينة نشطة؛ الانتقال دون Back");queueNext(gen,id);return;}
    try{
      boolean same=root.getPackageName()!=null&&targetPackage.contentEquals(root.getPackageName());
      List<String> labels=new ArrayList<>();if(same)collect(root,labels,0);
      boolean visible=same&&previewVerified&&isPreview(root,labels);
      boolean possibleX=visible; // Enumerate action only in an explicitly verified invitation.
      NavigationPolicy.Action plan=NavigationPolicy.nextDismissAction(same,visible,possibleX,false,false);
      if(plan==NavigationPolicy.Action.NO_ACTION){
        navigation("لا توجد معاينة مؤكدة؛ لا يُضغط Back خارج الدعوة");queueNext(gen,id);return;
      }
      xWasTried=true;
      if(plan==NavigationPolicy.Action.CLICK_CLOSE && tryX(root)){
        navigation("نُقر زر X/إغلاق داخل معاينة واتساب؛ انتظار تأكيد الإغلاق");
      }else{
        backWasTried=true;
        boolean ok=performGlobalAction(GLOBAL_ACTION_BACK);
        navigation(ok?"لا يوجد X صالح؛ استخدام Back داخل المعاينة":"تعذر إجراء Back؛ التحقق من النافذة");
      }
    }finally{root.recycle();}
    safePost(340,"تأكيد إغلاق X",()->checkDismissed(gen,id));
    safePost(900,"Back احتياطي",()->checkDismissed(gen,id));
    safePost(1850,"مهلة إغلاق المعاينة",()->checkDismissed(gen,id));
  }
  private void checkDismissed(long gen,int id){
    if(!valid(gen,id)||phase!=Phase.DISMISSING)return;
    dismissChecks++;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null){
      // A successful close can briefly leave no accessible root; verify again once.
      if(dismissChecks>=2){navigation("اختفت نافذة المعاينة؛ الانتقال للرابط التالي");queueNext(gen,id);}return;
    }
    try{
      boolean same=root.getPackageName()!=null&&targetPackage.contentEquals(root.getPackageName());
      List<String> labels=new ArrayList<>();if(same)collect(root,labels,0);
      if(!same||!isPreview(root,labels)){
        navigation("تأكيد اختفاء المعاينة؛ الرابط التالي");queueNext(gen,id);return;
      }
      NavigationPolicy.Action action=NavigationPolicy.nextDismissAction(same,true,false,xWasTried,backWasTried);
      if(action==NavigationPolicy.Action.BACK && dismissChecks>=2){
        backWasTried=true;boolean ok=performGlobalAction(GLOBAL_ACTION_BACK);
        navigation(ok?"بقيت المعاينة بعد X؛ Back احتياطي واحد":"تعذر Back الاحتياطي");
      }else if(dismissChecks>=3){
        pauseForFailure("تعذر تأكيد إغلاق المعاينة؛ توقف آمن لحماية نتائج الروابط");
      }
    }finally{root.recycle();}
  }
  private void queueNext(long gen,int id){
    if(!valid(gen,id))return;
    phase=Phase.WAITING_NEXT;
    final long newGeneration=++generation;
    handler.removeCallbacksAndMessages(null);
    navigation("حُفظت معالجة الرابط "+(id+1)+"؛ بدء التالي بعد الفاصل المحدد");
    safePost(gapMillis(),"الرابط التالي",()->{
      if(running&&phase==Phase.WAITING_NEXT&&newGeneration==generation){
        index=-1;previewVerified=false;navigateNext();
      }
    });
  }
  private void pauseForFailure(String message){
    invalidateTimers();running=false;phase=Phase.PAUSED;
    if(store!=null)store.state("PAUSED",message);
    DiagnosticsLog.add(this,"GUARD",message);
  }
  private void onLimit(){
    if(!running)return;
    invalidateTimers();running=false;phase=Phase.COOLDOWN;
    int step=Math.min(store.cooldownStep(),COOLDOWN.length-1);
    long wait=COOLDOWN[step];store.cooldown(Math.min(step+1,COOLDOWN.length-1),System.currentTimeMillis()+wait);
    store.state("COOLDOWN","واتساب طلب التمهل؛ لا نتابع الفحص أثناء التقييد");
    DiagnosticsLog.add(this,"LIMIT","حماية التقييد: توقف الفحص؛ الانتظار "+(wait/60000)+" دقيقة");
    // Deliberately no hidden hourly retries after a restriction without user confirmation.
  }
}
