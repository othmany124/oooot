package com.waultimate.scanner;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Evidence-only parser for WhatsApp invitation previews.
 *
 * Final classification model:
 * - DIRECT / APPROVAL = WhatsApp group (join type stored separately)
 * - COMMUNITY = WhatsApp community
 * - CHANNEL = WhatsApp channel
 * - INVALID = non-working link according to an explicit error OR a final incomplete result
 *
 * Creation date is NEVER guessed. It is stored only when WhatsApp exposes a visible date label.
 */
public final class PreviewParser {
  static final class Result {
    String status="UNRESOLVED", name="", members="", joinType="UNKNOWN", countType="UNKNOWN",
        creationDate="", note="لا تكفي معلومات المعاينة";
    int accuracy=0;
    boolean rateLimited=false;
  }

  private static final String[] INVALID={
      "invite link has been reset","invite link is invalid","this invite link is invalid",
      "invite link has expired","invite link is no longer valid","this link is no longer valid",
      "couldn't find this group","can't find this group","group doesn't exist","group does not exist",
      "رابط الدعوة غير صالح","تم إعادة تعيين رابط الدعوة","تم تغيير رابط الدعوة",
      "انتهت صلاحية رابط الدعوة","تعذر العثور على المجموعة","المجموعة غير موجودة",
      "هذا الرابط لم يعد صالحا","هذا الرابط لم يعد صالحًا"
  };
  private static final String[] LIMIT={
      "try again later","too many requests","please wait before trying",
      "حاول مرة أخرى لاحقًا","طلبات كثيرة","يرجى المحاولة لاحقاً","يرجى المحاولة لاحقا"
  };
  private static final String[] APPROVAL={
      "request to join","ask to join","request approval","approval required",
      "طلب الانضمام","طلب الموافقة","موافقة المشرف","موافقة المسؤول"
  };
  private static final String[] JOIN={
      "join group","join community","join channel","follow channel",
      "الانضمام إلى المجموعة","انضم إلى المجموعة","الانضمام إلى المجتمع",
      "متابعة القناة","الانضمام إلى القناة"
  };
  private static final String[] CHANNEL={
      "channel invite","join channel","follow channel","whatsapp channel",
      "دعوة إلى قناة","متابعة القناة","الانضمام إلى القناة"
  };
  private static final String[] COMMUNITY={
      "community invite","join community","whatsapp community",
      "دعوة إلى مجتمع","الانضمام إلى المجتمع"
  };
  private static final String[] CREATION_KEYS={
      "created on","created at","group created","community created","created",
      "تاريخ الإنشاء","تاريخ الانشاء","تم الإنشاء","تم الانشاء","أُنشئت","انشئت","أنشئت","تأسست","تأسس"
  };
  private static final String[] MONTHS={
      "january","february","march","april","may","june","july","august","september","october","november","december",
      "jan","feb","mar","apr","jun","jul","aug","sep","sept","oct","nov","dec",
      "يناير","فبراير","مارس","أبريل","ابريل","مايو","يونيو","يوليو","أغسطس","اغسطس","سبتمبر","أكتوبر","اكتوبر","نوفمبر","ديسمبر"
  };

  private static final String[] IGNORE={
      "whatsapp","cancel","إلغاء","إلغاء الأمر","close","dismiss","x","×","✕","✖",
      "join group","join community","join channel","follow channel","request to join","ask to join",
      "الانضمام إلى المجموعة","انضم إلى المجموعة","الانضمام إلى المجتمع","متابعة القناة",
      "طلب الانضمام","طلب الموافقة","مجموعة واتساب","دعوة للانضمام","group invite",
      "invite to group","channel invite","community invite","دعوة إلى قناة","دعوة إلى مجتمع",
      "members","member","participants","participant","followers","subscribers",
      "مشارك","مشاركون","الأعضاء","الأعضاء:","group info","المعلومات","معلومات المجموعة",
      "back","رجوع","report","إبلاغ","ok","موافق","فتح بواسطة","open with",
      "read more","see more","more","قراءة المزيد","عرض المزيد","المزيد","مزيد",
      "group icon","profile photo","group photo","صورة المجموعة","صورة الملف الشخصي"
  };

  private static final String[] MEMBER_UNITS={
      "members","member","participants","participant",
      "عضو","أعضاء","عضوا","عضوًا","عضواً","مشارك","مشاركون","مشاركًا","مشاركاً","المشاركون"
  };
  private static final String[] FOLLOWER_UNITS={
      "followers","follower","subscribers","subscriber",
      "متابع","متابعون","متابعًا","متابعاً","المتابعون","مشترك","مشتركون","مشتركين","المشتركون"
  };
  private static final String[] SUBGROUP_UNITS={
      "groups","group","subgroups","subgroup","قروب","قروبات","مجموعة","مجموعات"
  };
  private static final String[] NUM_PREFIX={
      "الأعضاء","المشاركون","المتابعون","المشتركون","عدد الأعضاء","عدد المشاركين",
      "عدد المتابعين","عدد المشتركين","عدد القروبات","عدد المجموعات"
  };

  private static boolean decimalSeparator(char c){return c==','||c=='٬'||c=='،'||c=='.';}
  private static String clean(String text){return text==null?"":text.trim().replace('\u200f',' ').replace('\u200e',' ').trim();}
  private static boolean has(String s,String[] needles){for(String n:needles)if(s.contains(n))return true;return false;}
  private static String digits(String input){StringBuilder s=new StringBuilder();for(int i=0;i<input.length();i++){int d=Character.digit(input.charAt(i),10);if(d>=0)s.append((char)('0'+d));}return s.toString();}
  private static boolean onlyNumber(String text){
    String s=clean(text);if(s.isEmpty())return false;boolean hasDigit=false;
    for(int i=0;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0){hasDigit=true;continue;}if(decimalSeparator(c)||Character.isWhitespace(c))continue;return false;}return hasDigit;
  }
  private static boolean plusNumber(String text){
    String s=clean(text);if(s.length()<2||s.charAt(0)!='+')return false;boolean digit=false;
    for(int i=1;i<s.length();i++){char c=s.charAt(i);if(Character.digit(c,10)>=0){digit=true;continue;}if(Character.isWhitespace(c)||c=='-'||c=='('||c==')'||decimalSeparator(c))continue;return false;}return digit;
  }
  private static boolean exact(String value,String[] options){String s=clean(value).toLowerCase(Locale.ROOT);for(String option:options)if(s.equals(option))return true;return false;}
  private static String countTypeForUnit(String unit){if(exact(unit,FOLLOWER_UNITS))return "FOLLOWERS";if(exact(unit,SUBGROUP_UNITS))return "SUBGROUPS";if(exact(unit,MEMBER_UNITS))return "MEMBERS";return "UNKNOWN";}

  private static String[] visibleCount(String text){
    if(text==null)return null;String s=clean(text).toLowerCase(Locale.ROOT);if(s.isEmpty()||plusNumber(s))return null;
    int begin=-1;for(int i=0;i<s.length();i++)if(Character.digit(s.charAt(i),10)>=0){begin=i;break;}if(begin<0)return null;
    int end=begin;while(end<s.length()&&(Character.digit(s.charAt(end),10)>=0||decimalSeparator(s.charAt(end))||Character.isWhitespace(s.charAt(end))))end++;
    while(end>begin&&(decimalSeparator(s.charAt(end-1))||Character.isWhitespace(s.charAt(end-1))))end--;
    String number=digits(s.substring(begin,end));if(number.isEmpty())return null;
    String before=clean(s.substring(0,begin)).replace(":","").replace("：","").trim();String after=clean(s.substring(end));
    if(before.isEmpty()){String type=countTypeForUnit(after);if(!"UNKNOWN".equals(type))return new String[]{number,type};}
    else if(after.isEmpty())for(String prefix:NUM_PREFIX)if(before.equals(prefix)){
      String type=(prefix.contains("متابع")||prefix.contains("مشترك"))?"FOLLOWERS":(prefix.contains("قروب")||prefix.contains("مجموع"))?"SUBGROUPS":"MEMBERS";
      return new String[]{number,type};
    }
    return null;
  }

  private static boolean ignored(String value){
    String t=clean(value).toLowerCase(Locale.ROOT);
    if(t.length()<2||t.length()>140||t.startsWith("http")||t.contains("chat.whatsapp.com")||t.contains("whatsapp.com/channel/"))return true;
    if(onlyNumber(t)||plusNumber(t)||visibleCount(t)!=null)return true;for(String n:IGNORE)if(t.equals(n))return true;return false;
  }
  private static boolean titleCandidate(String value){
    String s=clean(value);if(ignored(s))return false;int letters=0,digits=0;
    for(int i=0;i<s.length();i++){char c=s.charAt(i);if(Character.isLetter(c))letters++;else if(Character.digit(c,10)>=0)digits++;}
    if(letters==0||s.length()>96)return false;if(letters<2&&digits>letters*2)return false;return true;
  }
  private static void setCount(Result r,String number,String type,boolean channel,boolean community){
    if(number==null||number.isEmpty()||"UNKNOWN".equals(type))return;
    boolean preferred=(channel&&"FOLLOWERS".equals(type))||(community&&"SUBGROUPS".equals(type));
    if(r.members.isEmpty()||preferred){r.members=number;r.countType=type;}
  }
  private static boolean dateLike(String value){
    String s=clean(value).toLowerCase(Locale.ROOT);int digits=0;for(int i=0;i<s.length();i++)if(Character.digit(s.charAt(i),10)>=0)digits++;
    if(digits>=4)return true;for(String m:MONTHS)if(s.contains(m))return true;return false;
  }
  private static String trimDatePrefix(String value){
    String s=clean(value);String low=s.toLowerCase(Locale.ROOT);
    for(String key:CREATION_KEYS){int pos=low.indexOf(key);if(pos>=0){String out=clean(s.substring(pos+key.length()));while(out.startsWith(":")||out.startsWith("-")||out.startsWith("–"))out=clean(out.substring(1));String l=out.toLowerCase(Locale.ROOT);if(l.startsWith("on "))out=clean(out.substring(3));if(out.startsWith("في "))out=clean(out.substring(3));return out;}}
    return "";
  }
  private static String creationDate(List<String> parts){
    for(int i=0;i<parts.size();i++){
      String item=clean(parts.get(i)), low=item.toLowerCase(Locale.ROOT);boolean key=false;for(String k:CREATION_KEYS)if(low.contains(k)){key=true;break;}
      if(key){String same=trimDatePrefix(item);if(dateLike(same))return same;if(i+1<parts.size()&&dateLike(parts.get(i+1)))return clean(parts.get(i+1));}
    }
    return "";
  }
  private static int confidence(boolean channel,boolean community,String count,String creation){
    int score=90;if(!count.isEmpty())score+=5;if(!creation.isEmpty())score+=5;if(channel&&!count.isEmpty())score=100;if(score>100)score=100;return score;
  }

  static Result parse(List<String> input){
    Result r=new Result();if(input==null)return r;List<String> parts=new ArrayList<>();StringBuilder allText=new StringBuilder();
    for(String entry:input){if(entry==null)continue;String item=clean(entry);if(item.isEmpty())continue;if(!parts.contains(item))parts.add(item);allText.append(item.toLowerCase(Locale.ROOT)).append('\n');}
    String all=allText.toString();
    if(has(all,LIMIT)){r.rateLimited=true;r.note="رُصد حد الطلبات؛ يُعاد فحص الرابط بعد التهدئة";return r;}
    if(has(all,INVALID)){r.status="INVALID";r.joinType="INVALID";r.accuracy=100;r.note="واتساب عرض رسالة صريحة بأن رابط الدعوة غير صالح/منتهي/متغير";return r;}

    boolean approval=has(all,APPROVAL),join=has(all,JOIN);if(!approval&&!join){r.note="لم تظهر معاينة دعوة مؤكدة";return r;}
    boolean channel=has(all,CHANNEL),community=has(all,COMMUNITY);if(channel&&community){r.note="ظهرت إشارات متعارضة للقناة والمجتمع";return r;}
    if(channel)r.status="CHANNEL";else if(community)r.status="COMMUNITY";else r.status=approval?"APPROVAL":"DIRECT";
    r.joinType=approval?"APPROVAL":channel?"FOLLOW":community?"COMMUNITY":"DIRECT";

    int firstAction=parts.size();for(int i=0;i<parts.size();i++){String t=parts.get(i).toLowerCase(Locale.ROOT);if(has(t,JOIN)||has(t,APPROVAL)){firstAction=i;break;}}
    for(int i=0;i<firstAction;i++){String candidate=parts.get(i);if(titleCandidate(candidate)){r.name=candidate;break;}}
    if(r.name.isEmpty())for(int i=firstAction-1;i>=0;i--){String candidate=parts.get(i);if(titleCandidate(candidate)){r.name=candidate;break;}}

    // User rule: a group/community whose name never appears is classified as non-working.
    // Channels remain classifiable by their explicit channel action + follower count even if a title is not exposed.
    if(r.name.isEmpty()&&!channel){r.status="INVALID";r.joinType="INVALID";r.accuracy=75;r.note="لم يظهر اسم القروب/المجتمع في معاينة واتساب";return r;}

    for(String item:parts){String[] count=visibleCount(item);if(count!=null)setCount(r,count[0],count[1],channel,community);}
    for(int i=0;i+1<parts.size();i++){
      String a=clean(parts.get(i)),b=clean(parts.get(i+1));if(onlyNumber(a))setCount(r,digits(a),countTypeForUnit(b),channel,community);
      if(onlyNumber(b)){String prefix=a.toLowerCase(Locale.ROOT).replace(":","").replace("：","").trim();for(String x:NUM_PREFIX)if(prefix.equals(x)){
        String type=(x.contains("متابع")||x.contains("مشترك"))?"FOLLOWERS":(x.contains("قروب")||x.contains("مجموع"))?"SUBGROUPS":"MEMBERS";setCount(r,digits(b),type,channel,community);break;}}
    }

    r.creationDate=creationDate(parts);r.accuracy=confidence(channel,community,r.members,r.creationDate);
    if(channel)r.note=r.members.isEmpty()?"قناة مؤكدة؛ عدد المتابعين غير ظاهر":"قناة مؤكدة؛ تم التقاط عدد المتابعين";
    else if(community)r.note=r.members.isEmpty()?"مجتمع مؤكد؛ عدد القروبات غير ظاهر":"مجتمع مؤكد؛ تم التقاط عدد القروبات";
    else r.note=r.members.isEmpty()?"قروب مؤكد؛ عدد الأعضاء غير ظاهر":"قروب مؤكد؛ تم التقاط عدد الأعضاء";
    if(r.creationDate.isEmpty())r.note+="؛ تاريخ الإنشاء غير ظاهر";
    return r;
  }
}
