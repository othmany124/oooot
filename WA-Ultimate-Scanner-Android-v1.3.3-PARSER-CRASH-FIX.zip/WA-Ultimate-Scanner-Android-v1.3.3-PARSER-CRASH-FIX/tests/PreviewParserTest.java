package com.waultimate.scanner;
import java.util.Arrays;
public final class PreviewParserTest {
  static void check(String label,String actual,String expected){if(!expected.equals(actual))throw new AssertionError(label+": "+actual+" != "+expected);System.out.println("PASS "+label);}
  public static void main(String[] args){
    check("direct",PreviewParser.parse(Arrays.asList("Study Group","121 members","Join group")).status,"DIRECT");
    check("approval",PreviewParser.parse(Arrays.asList("Research Group","Request to join")).status,"APPROVAL");
    check("invalid",PreviewParser.parse(Arrays.asList("This invite link is invalid")).status,"INVALID");
    check("no-name not invalid",PreviewParser.parse(Arrays.asList("WhatsApp","Join group")).status,"UNRESOLVED");
    check("rate-limited not invalid",PreviewParser.parse(Arrays.asList("Try again later")).status,"UNRESOLVED");
    check("channel",PreviewParser.parse(Arrays.asList("News","Channel invite","Join channel")).status,"CHANNEL");
    check("community",PreviewParser.parse(Arrays.asList("Research","Community invite","Join community")).status,"COMMUNITY");
    check("channel-name",PreviewParser.parse(Arrays.asList("News", "Channel invite", "Join channel")).name,"News");
    check("community-name",PreviewParser.parse(Arrays.asList("Research", "Community invite", "Join community")).name,"Research");
    check("arabic-channel-name",PreviewParser.parse(Arrays.asList("أخبار التقنية", "دعوة إلى قناة", "متابعة القناة")).name,"أخبار التقنية");
    check("arabic-community-name",PreviewParser.parse(Arrays.asList("مجتمع المطورين", "دعوة إلى مجتمع", "الانضمام إلى المجتمع")).name,"مجتمع المطورين");
    check("arabic-prefix-count",PreviewParser.parse(Arrays.asList("فريق", "الأعضاء: ٢٣٤", "الانضمام إلى المجموعة")).members,"234");
    check("member-title-not-count",PreviewParser.parse(Arrays.asList("Class 2026 members", "Join group")).members,"");
    check("direct-count",PreviewParser.parse(Arrays.asList("Study Group","1,234 members","Join group")).members,"1234");
    check("approval-kind",PreviewParser.parse(Arrays.asList("Research Group","Request to join")).joinType,"APPROVAL");
    check("channel-followers",PreviewParser.parse(Arrays.asList("أخبار التقنية","١٢٬٣٤٥ متابع","متابعة القناة")).members,"12345");
    check("followers-kind",PreviewParser.parse(Arrays.asList("News","482K followers","Join channel")).countType,"UNKNOWN"); // abbreviated counts never invented
    check("ambiguous-no-count",PreviewParser.parse(Arrays.asList("Study Group","Join group")).members,"");
    check("no-button",PreviewParser.parse(Arrays.asList("WhatsApp", "Unknown group")).status,"UNRESOLVED");
  }
}
