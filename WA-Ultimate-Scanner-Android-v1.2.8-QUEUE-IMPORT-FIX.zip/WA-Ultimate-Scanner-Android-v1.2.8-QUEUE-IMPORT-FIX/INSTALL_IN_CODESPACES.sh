#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
git pull --ff-only origin "$(git branch --show-current)"
ZIP='WA-Ultimate-Scanner-Android-v1.2.8-QUEUE-IMPORT-FIX.zip'
if [ ! -f "$ZIP" ]; then echo "ERROR: Upload $ZIP to the repository root first";exit 1;fi
unzip -tq "$ZIP"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
unzip -oq "$ZIP" -d "$TMP"
PROJECT=$(find "$TMP" -name settings.gradle -type f -print -quit)
test -n "$PROJECT"
mkdir -p .github/workflows
cp "$(dirname "$PROJECT")/.github/workflows/build-apk.yml" .github/workflows/build-apk.yml
git add .github/workflows/build-apk.yml "$ZIP"
if ! git diff --cached --quiet; then
 git commit -m 'Build v1.2.8 queued links import fix preview'
 git push origin "$(git branch --show-current)"
else
 gh workflow run build-apk.yml --ref "$(git branch --show-current)"
fi
echo 'Submitted v1.2.8 preview build; Android debug key is automatically generated.'
